# PATH-OOM (S3.3 OOM Crash)

> Entry condition: TiDB or TiKV process killed / restarted

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm Process Restart

```
metrics:
  uptime: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}"}

check: within [start, end], is there an instance with uptime dropping sharply (= restart)
identify: RESTARTED_INSTANCES + job (tidb/tikv)

No restart → "No restart detected" → END
Restart found → branch by job
```

### Branch A: TiDB OOM

**A1: Confirm OOM**
```
metrics:
  rss: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb", instance="{inst}"}
  quota: tidb_server_memory_quota_bytes{tidb_cluster_id="{cluster_id}", instance="{inst}"}

RSS before restart > quota x 90% → confirm OOM → A2
RSS not approaching → not OOM (crash/manual) → END
```

**A1.5: Loki Log Search (Dedicated/Premium)**
```
If loki_available:
  Search keywords:
    {component="tidb"} |~ "(?i)OOM|killed|memory exceed|expensive_query"
    {component="tidb"} |~ "TTL manager has timed out"
    {component="tidb"} |~ "GC safe point|safepoint blocked"

  Typical findings (TCOC-4900 case):
    - expensive_query logs → long-running uncommitted large transactions
    - GC safepoint blocked by a running session → long transaction blocking GC
    - TTL manager has timed out → pessimistic lock timeout, transaction not properly ended
  → If long transaction found → PATH-TXN-CONFLICT
```

**A2: Find High-Memory SQL**
→ [MODULE-SQL](../../performance-optimization/modules/sql-diagnosis.md)
```sql
SELECT digest, digest_text, MAX(mem_max) AS max_mem, COUNT(*) AS cnt
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text ORDER BY max_mem DESC LIMIT 10
```

**A3: Check Memory Configuration**
- `tidb_mem_quota_query{tidb_cluster_id="{cluster_id}"}` whether configured
- `tidb_server_memory_limit{tidb_cluster_id="{cluster_id}"}` whether enabled
- `oom-action` whether set to "cancel"

→ DIAGNOSIS + recommendations: optimize high-memory SQL / configure memory protection / scale up

### Branch B: TiKV OOM

**B1: Confirm Memory Increase**
```
metrics:
  rss: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv", instance="{inst}"}
RSS continuously increasing before restart → B2
```

**B2: Block Cache**
```
metrics:
  block_cache: tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}", instance="{inst}"}
block cache > 45% of total memory → "Block cache configured too large" (default = system memory x 45%; Cloud 4c16g actual limit ~13GB, 8c32g actual limit ~28GB)
```

**B3: Region Count**
```
metrics:
  regions: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", instance="{inst}"}
regions > 50K → "Too many Regions (per-region metadata memory 30–50KB — 经验估值，不同来源 30–50KB/个; 50K ~ 1.5–2.5GB)"
```

**B4: Write Buffer**
```
metrics:
  write_buf: tikv_engine_write_buffer_manager_memory_usage_bytes{tidb_cluster_id="{cluster_id}"}
Abnormally high → Memtable accumulation → MODULE-TIKV S2_WRITE_STALL
```

→ DIAGNOSIS + recommendations: adjust block cache / merge Regions / scale up

---

## Data Source Call Templates

### Instance Uptime (Detect Restarts)
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}"}
```

### TiDB Memory RSS
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"} by (instance)
```

### TiDB Memory Quota
```
query: tidb_server_memory_quota_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Memory RSS
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"} by (instance)
```

### TiKV Block Cache Size
```
query: tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Region Count
```
query: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Write Buffer Memory
```
query: tikv_engine_write_buffer_manager_memory_usage_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### High-Memory SQL (Slow Queries)
```sql
SELECT digest, digest_text, MAX(mem_max) AS max_mem, COUNT(*) AS cnt
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text ORDER BY max_mem DESC LIMIT 10
```
