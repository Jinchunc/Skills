{{DOMAIN_INDEX}}

# Skill Dispatch

MUST check for matching skills BEFORE any response or action. 1% chance of relevance → invoke.

**Cap:** max 3 skills per message. Priority: (1) user-named, (2) highest relevance, (3) process before domain.

**Flow:** scan index below → load matching SKILL.md (max 3) → announce → follow. Subagents skip dispatch but SHOULD still respect agent behavioral rules.

{{SKILL_INDEX}}

**Pre-flight:** For skills with 3+ MUST rules, extract and state top 3-5 constraints before executing. MUST NOT paraphrase skill content beyond the constraint summary.

**Rigid skills** (TDD, debugging): follow exactly. **Flexible skills** (patterns): adapt to context.

**Frontmatter:** `clearance` (shadow → supervised → audited → autonomous), `scope` (individual → project → org). Constraint priority follows rule #30.

User instructions say WHAT, not HOW. "Add X" or "Fix Y" does not mean skip skill workflows.
