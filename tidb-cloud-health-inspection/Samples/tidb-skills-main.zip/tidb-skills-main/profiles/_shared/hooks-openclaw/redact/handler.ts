// Redact Hook — strips sensitive data from agent outputs before delivery
//
// Defense-in-depth: even if the agent fails to self-mask (Rule 6),
// this hook catches credentials, tokens, and PII in outbound content.
//
// Designed to be generic (no org-specific patterns). Deployments can
// extend REDACT_PATTERNS for internal URLs, domains, etc.

interface RedactionPattern {
  name: string;
  regex: RegExp;
  replace: string;
}

const REDACT_PATTERNS: RedactionPattern[] = [
  // --- Credentials ---
  {
    name: 'password',
    regex: /(?:password|passwd|pwd)\s*[:=]\s*\S+/gi,
    replace: '***REDACTED_PASSWORD***',
  },
  {
    name: 'connection_string_password',
    regex: /:\/\/[^:]+:([^@]+)@/g,
    replace: '://***:***REDACTED***@',
  },
  {
    name: 'aws_access_key',
    regex: /(?:AKIA|ASIA)[A-Z0-9]{16}/g,
    replace: '***REDACTED_AWS_KEY***',
  },
  {
    name: 'aws_secret_key',
    regex: /(?:aws_secret_access_key|aws_secret|SK)[A-Za-z0-9/+=]{20,}/gi,
    replace: '***REDACTED_SECRET***',
  },
  {
    name: 'bearer_token',
    regex: /Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi,
    replace: 'Bearer ***REDACTED_TOKEN***',
  },
  {
    name: 'api_token',
    regex: /(?:ghp_|gho_|ghu_|ghs_|ghr_|sk-|pk-|xoxb-|xoxp-|ATATT)\S+/gi,
    replace: '***REDACTED_TOKEN***',
  },
  {
    name: 'generic_secret',
    regex: /(?:api[_-]?key|api[_-]?secret|secret[_-]?key|access[_-]?token|auth[_-]?token)\s*[:=]\s*["']?\S+["']?/gi,
    replace: '***REDACTED_SECRET***',
  },
  {
    name: 'base64_jwt',
    regex: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,
    replace: '***REDACTED_JWT***',
  },
  {
    name: 'url_query_token',
    regex: /[?&](?:token|key|secret|api_key|access_token)=[^&\s]+/gi,
    replace: '?***REDACTED_PARAM***',
  },
  // --- PII ---
  {
    name: 'email',
    regex: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g,
    replace: '***REDACTED_EMAIL***',
  },
  {
    name: 'private_key_block',
    regex: /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g,
    replace: '***REDACTED_PRIVATE_KEY***',
  },
];

function redactText(text: string): { redacted: string; fields: string[] } {
  let redacted = text;
  const fields: string[] = [];

  for (const pattern of REDACT_PATTERNS) {
    const replaced = redacted.replace(pattern.regex, pattern.replace);
    if (replaced !== redacted) {
      redacted = replaced;
      fields.push(pattern.name);
    }
  }

  return { redacted, fields };
}

export default {
  name: 'redact-hook',
  version: '1.0.0',

  hooks: {
    message: async (context: Record<string, unknown>) => {
      if (context.direction === 'out' && context.text) {
        const { redacted, fields } = redactText(context.text as string);
        if (fields.length > 0) {
          console.log(`[redact-hook] Redacted fields: ${fields.join(', ')}`);
          context.text = redacted;
        }
      }
    },

    after_tool_call: async (context: Record<string, unknown>) => {
      const result = context.result as Record<string, unknown> | undefined;
      if (result?.output) {
        const { redacted, fields } = redactText(result.output as string);
        if (fields.length > 0) {
          console.log(`[redact-hook] Redacted tool output: ${fields.join(', ')}`);
          result.output = redacted;
        }
      }
    },
  },
};
