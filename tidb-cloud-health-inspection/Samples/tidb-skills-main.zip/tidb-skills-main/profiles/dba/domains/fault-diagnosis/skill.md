# Fault Diagnosis — Domain Methodology

> Engine-agnostic methodology for database fault diagnosis and recovery.
> **Priority: restore service first, then find root cause.**

## Activation

User reports: down, unavailable, crash, OOM, connection refused, error spike, replication lag, data inconsistency.

## Engine Detection and Provider Loading

Follow the canonical procedure in `INDEX.md#engine-detection-and-provider-loading` (engine detection 3-step, conditional engine skill loading, DISPATCH Layer 3 provider loading).

---

## Step 1: Severity Assessment

Classify immediately upon receiving fault report:

| Level | Criteria | Response |
|-------|----------|----------|
| **P0** | Full outage, data at risk, all users impacted | Immediate — service recovery is the ONLY priority |
| **P1** | Partial outage, significant user impact | Urgent — recovery first, parallel investigation |
| **P2** | Degraded service, limited user impact | Important — investigate with recovery readiness |
| **P3** | Minor issue, no user impact | Normal — investigate at regular pace |

## Step 2: Service Recovery Priority

For P0/P1: execute recovery BEFORE root cause analysis.

**Recovery decision tree:**
1. Is the service completely down? → Attempt restart/failover
2. Is it partially available? → Isolate failed component, route traffic away
3. Is data at risk? → Prioritize data protection (stop writes if needed)
4. Was there a recent change? → Consider rollback

→ Engine: provides specific restart procedures, failover commands, component-level recovery steps.

## Step 3: Fault Classification

Classify the fault type to route to the correct investigation path:

| Category | Signals | Examples |
|----------|---------|---------|
| **Node failure** | Process exit, unreachable, restart loop | Single DB/storage node down |
| **Cluster failure** | All nodes unreachable, consensus/quorum lost | Entire cluster unavailable |
| **Partition/shard failure** | Specific data range unavailable | Storage partition/shard offline |
| **OOM** | Process killed, memory limit hit | Memory exhaustion crash |
| **Connection failure** | Refused, timeout, pool exhausted | Cannot establish connections |
| **Query error** | Server busy, timeout, unexpected error | Queries failing with errors |
| **DDL stuck** | Schema change not completing | Metadata lock, long-running DDL |
| **Replication lag** | Sync delay, consumer lag | CDC/replication falling behind |
| **Data inconsistency** | Wrong results, checksum mismatch | Data correctness issue |
| **Coordinator issues** | Metadata service degraded | Coordinator/catalog latency |
| **Storage failure** | Store disconnected, offline | Storage node permanently down |
| **Scaling failure** | New nodes not taking load | Scale-out/in stuck |

→ Engine: SKILL.md routing table maps each fault type to engine-specific diagnostic files.

## Step 4: Timeline Correlation

Establish what happened and when:

1. **Onset** — exact time the fault started (from metrics, logs, or user report)
2. **Preceding events** — what changed in the 30 min before onset?
   - Deployment / config change
   - Traffic pattern change
   - Infrastructure event (network, disk, cloud provider)
   - Schema change (DDL)
3. **Progression** — did the fault escalate? Cascade to other components?
4. **Recovery attempts** — what was already tried? Did it help?

## Step 5: Log Analysis Framework

Logs are the primary evidence source for fault diagnosis:

1. **Error pattern search** — search for error, panic, fatal, killed, OOM patterns around onset time
2. **Frequency analysis** — which errors are most frequent? New errors vs pre-existing?
3. **Correlation** — do errors appear across multiple components simultaneously?
4. **Stack trace analysis** — identify the code path that failed
5. **Rate of change** — sudden spike in errors vs gradual increase?

→ Engine: provides specific log locations, error pattern dictionaries, and component-specific log analysis.
→ Provider: follow DISPATCH.md Layer 3 data-access loading (Step A data source API) for log retrieval.

## Step 6: Root Cause Analysis Workflow

After service is restored (or for P2/P3 where recovery isn't urgent):

### Evidence Collection
Gather all evidence from the diagnosis session:
- Metrics queried and their values at anomaly time
- Log entries (error/panic/fatal patterns)
- User-reported symptoms and timeline
- Configuration state at time of incident
- Actions taken during recovery

### Timeline Reconstruction
Build chronological event sequence:
1. Start from earliest anomaly signal, not first user report
2. Use exact timestamps when available
3. Group under phases: TRIGGER → DETECTION → DIAGNOSIS → MITIGATION → RECOVERY → FOLLOW-UP
4. Format: `[HH:MM UTC] {phase} — {description} [CONFIRMED|INFERRED|REPORTED]`

### Root Cause Determination
- Identify the initiating event (trigger)
- Trace the causal chain: trigger → intermediate failures → observed symptoms
- Distinguish root cause from contributing factors
- State confidence: HIGH/MEDIUM/LOW with evidence basis

### Output Format
```
Fault: {description}
Severity: P0/P1/P2/P3
Impact: {scope and duration}
Root Cause: {single sentence} [confidence: HIGH/MEDIUM/LOW]
Evidence: {numbered list of supporting observations}
Timeline: {chronological events}
Recovery: {what was done to restore service}
Prevention: {recommended actions to prevent recurrence}
```

## Step 7: Remediation

Apply a structured permanent fix after root cause is identified.

- **P0/P1:** Apply this step after emergency recovery (Step 2) has stabilized the service. The goal is a permanent fix to replace the temporary recovery.
- **P2/P3:** Apply directly after root cause identification (Step 6).

### 7.1 Fix Selection — Least Disruptive First

Apply fixes in this order; stop at the first level that resolves the root cause:

| Priority | Strategy | When |
|----------|----------|------|
| 0 | **Rollback recent change** | Root cause is a recent deployment, config change, or DDL — revert it |
| 1 | **Configuration adjustment** | Tunable parameter was wrong (timeout, threshold, pool size) |
| 2 | **Resource scaling** | Capacity insufficient for workload (add nodes, increase limits) |
| 3 | **Workaround / mitigation** | Known bug without immediate patch — disable feature or avoid buggy code path |
| 4 | **Component restart** | Transient corruption or leaked state (restart single component) |
| 5 | **Version upgrade / patch** | Known bug with available fix |
| 6 | **Architecture change** | Structural issue (replication topology, placement rules, data distribution) |

→ Engine: provides specific commands, configuration parameters, and upgrade procedures for each strategy.

### 7.2 Similar Case Search

Before applying the selected fix, validate against engine knowledge base precedent:

1. Load the engine SKILL.md "Knowledge Base" section to get the case index
2. **Match by fault type** — search oncall-experiences files for similar error patterns (grep for error messages, panic signatures)
3. **Match by component** — search by component name and failure mode (grep for component name + failure keyword, e.g., "storage node unavailable")
4. **Match by fix pattern** — search for cases where the same fix strategy was applied

A matched precedent with a verified fix is stronger than a novel suggestion.

→ Engine: load knowledge base from engine SKILL.md for case matching.

### 7.3 Fix Verification

After applying the fix:

1. Confirm the fault condition no longer reproduces
2. Verify metrics return to baseline (error rate, availability, latency)
3. Monitor for recurrence over an appropriate window (1h for transient, 24h for structural)
4. If no improvement → revert fix, return to Step 6 for deeper root cause analysis
5. If partial improvement → keep fix, re-diagnose for compound issue (Step 3 classification)

→ Engine: provides health check commands and resolution verification metrics.

## Step 8: Post-Incident

After P0/P1 resolution, MUST offer:
1. Formal RCA document generation (using Step 6 workflow)
2. Preventive measure recommendations
3. Monitoring/alerting improvements

## Cross-Domain

If fault investigation reveals a performance root cause:
- OOM caused by expensive query → load performance-optimization domain for SQL analysis
- Connection exhaustion from slow queries → load performance-optimization domain

Load the other domain's methodology first: `Read domains/performance-optimization/skill.md`
