#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Usage:
  aws_plan.sh [--create-billing-alarm]

Prints the AWS account, region, resource bill of materials, cost ceiling, TTL,
and cleanup plan. The optional billing alarm step is the only mutating action
and requires BILLING_EMAIL.
USAGE
}

create_billing_alarm=0
if [ "${1:-}" = "--create-billing-alarm" ]; then
  create_billing_alarm=1
elif [ "${1:-}" = "--help" ]; then
  usage
  exit 0
elif [ "${1:-}" != "" ]; then
  usage
  exit 1
fi

need_cmd aws
require_env \
  PROFILE REGION AZ CLUSTER_NAME OWNER EXPIRES_AT COST_CEILING_USD \
  CONTROL_COUNT CONTROL_TYPE PD_COUNT PD_TYPE TIDB_COUNT TIDB_TYPE \
  TIKV_COUNT TIKV_TYPE MONITOR_COUNT MONITOR_TYPE MINIO_SIZE_GB \
  MINIO_IOPS MINIO_THROUGHPUT_MBPS

expected_account="${EXPECTED_AWS_ACCOUNT_ID:-}"
account_id="$(aws --profile "$PROFILE" sts get-caller-identity --query Account --output text)"
configured_region="$(aws configure get region --profile "$PROFILE" || true)"
pressure_count="${PRESSURE_COUNT:-0}"
pressure_type="${PRESSURE_TYPE:-none}"
network_extras="${NETWORK_EXTRAS:-NAT=no, EIP=no, LB=no, cross-AZ=no}"

if [ -n "$expected_account" ] && [ "$account_id" != "$expected_account" ]; then
  account_check="fail expected=$expected_account"
else
  account_check="pass"
fi

cat <<EOF
AWS account: $account_id (expected-account-id check: $account_check)
Configured region: ${configured_region:-unset}
Target region/AZ: $REGION/$AZ
Cluster: $CLUSTER_NAME
Owner: $OWNER
TTL/ExpiresAt: $EXPIRES_AT
Approved cost ceiling: $COST_CEILING_USD USD
Estimated burn rate: ${ESTIMATED_BURN_RATE_USD_PER_HOUR:-unknown} hourly, ${ESTIMATED_BURN_RATE_USD_PER_DAY:-unknown} daily
Resources:
  control=${CONTROL_COUNT}x${CONTROL_TYPE}, pd=${PD_COUNT}x${PD_TYPE}, tidb=${TIDB_COUNT}x${TIDB_TYPE},
  tikv=${TIKV_COUNT}x${TIKV_TYPE}, monitor=${MONITOR_COUNT}x${MONITOR_TYPE}, pressure=${pressure_count}x${pressure_type}
Storage:
  root EBS=${ROOT_EBS_SUMMARY:-set per role}, MinIO gp3=${MINIO_SIZE_GB}GiB/${MINIO_IOPS}IOPS/${MINIO_THROUGHPUT_MBPS}MBps
Network extras:
  $network_extras
Cleanup plan:
  scripts/cleanup_aws.sh --apply after final inventory review
EOF

if [ "$account_check" != "pass" ]; then
  die "AWS account does not match EXPECTED_AWS_ACCOUNT_ID"
fi

if [ "$create_billing_alarm" -eq 0 ]; then
  log "Billing alarm not created. Re-run with --create-billing-alarm if permitted."
  exit 0
fi

require_env BILLING_EMAIL

billing_region="${BILLING_REGION:-us-east-1}"
topic_arn="$(aws --profile "$PROFILE" --region "$billing_region" sns create-topic \
  --name "tidbx-cost-$CLUSTER_NAME" --query TopicArn --output text)"
aws --profile "$PROFILE" --region "$billing_region" sns subscribe \
  --topic-arn "$topic_arn" --protocol email --notification-endpoint "$BILLING_EMAIL"
aws --profile "$PROFILE" --region "$billing_region" cloudwatch put-metric-alarm \
  --alarm-name "tidbx-cost-$CLUSTER_NAME" \
  --namespace AWS/Billing --metric-name EstimatedCharges \
  --dimensions Name=Currency,Value=USD \
  --statistic Maximum --period 21600 --evaluation-periods 1 \
  --threshold "$COST_CEILING_USD" \
  --comparison-operator GreaterThanThreshold \
  --alarm-actions "$topic_arn"

log "Billing alarm created. The SNS email subscription must be confirmed by the recipient."
