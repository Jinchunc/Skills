# SQL & Schema Management — Domain Methodology (Partial)

> version: 0.1.0 (partial coverage)
> Engine-agnostic methodology for SQL review and schema design.

## Activation

User requests: SQL review, DDL planning, index recommendation, schema design, table structure optimization.

## Engine Detection and Provider Loading

Follow the canonical procedure in `INDEX.md#engine-detection-and-provider-loading` (engine detection 3-step, conditional engine skill loading, DISPATCH Layer 3 provider loading).

---

## Step 1: DDL Impact Assessment

Before any schema change:
1. **Table size** — row count, data size, index size
2. **Lock behavior** — will this DDL block reads/writes?
3. **Duration estimate** — how long based on table size and operation type
4. **Online DDL** — can this be done without downtime? Engine-specific capabilities
5. **Dependency check** — foreign keys, views, triggers affected

## Step 2: Index Recommendation Framework

When evaluating indexes:
1. **Workload analysis** — what queries run against this table (read/write ratio)
2. **Access pattern** — point lookup, range scan, sort, group by
3. **Selectivity** — how many distinct values does the column have
4. **Composite index order** — equality columns first, then range, then sort
5. **Redundancy check** — does a new index overlap with existing ones

## Step 3: Schema Review Checklist

| Check | What to Verify |
|-------|---------------|
| Primary key | Appropriate type and distribution |
| Data types | Correct size, no implicit conversions |
| Null handling | Nullable only when business requires it |
| Index coverage | Common query patterns have supporting indexes |
| Naming convention | Consistent naming across tables |
| Partitioning | Appropriate strategy for data volume and access pattern |

## Step 4: Pre-Deployment SQL Review

For SQL going to production:
1. Explain/analyze the execution plan
2. Check for full table scans on large tables
3. Verify parameter binding (no SQL injection risk)
4. Estimate resource consumption
5. Test with production-like data volume

## Step 5: Synthesis & Output

Combine findings into a structured recommendation:

1. **Summary** — what was reviewed (DDL, index, schema, SQL) and overall assessment
2. **Findings** — each issue with severity (CRITICAL / WARNING / NOTICE / OK)
3. **Recommendations** — specific changes with before/after SQL examples
4. **Risk assessment** — deployment risk level and mitigation steps
5. **Execution plan** — ordered steps for applying changes safely
