<!-- Rules: 19 (Interaction), 28-30 (Meta-Rules) -->
### Interaction

19. **Announce skill activation.** When activating a skill, SHOULD inform the user which skill is being used and why.

### Meta-Rules

28. **Instruction priority.** User's explicit instructions (highest) > Skill instructions > Default system behavior (lowest).

29. **MUST vs SHOULD.** MUST / MUST NOT = non-negotiable, follow exactly. SHOULD / SHOULD NOT = best practice, follow unless there is explicit justification.

30. **Scope conflict resolution.** When two rules conflict: org-scope MUST > project-scope MUST > individual-scope MUST. If two MUSTs at the same scope conflict, stop and report to the user.
