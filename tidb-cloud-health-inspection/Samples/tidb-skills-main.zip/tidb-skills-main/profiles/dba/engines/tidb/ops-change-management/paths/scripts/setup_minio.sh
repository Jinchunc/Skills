#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Usage:
  setup_minio.sh [--plan|--apply]

Runs on the control host. Formats and mounts a dedicated MinIO EBS volume,
installs minio and mc, writes /etc/default/minio.env, starts minio.service, and
creates the bucket. Defaults to --plan.
USAGE
}

action="${1:---plan}"
case "$action" in
  --plan) apply=0 ;;
  --apply) apply=1 ;;
  --help) usage; exit 0 ;;
  *) usage; exit 1 ;;
esac

MINIO_BUCKET="${MINIO_BUCKET:-${CLUSTER_NAME:-}}"
MINIO_ACCESS_KEY="${MINIO_ACCESS_KEY:-cseaccess}"
MINIO_ENV_FILE="${MINIO_ENV_FILE:-/etc/default/minio.env}"
MINIO_MOUNT="${MINIO_MOUNT:-/minio}"

require_env MINIO_BUCKET MINIO_ACCESS_KEY MINIO_DEVICE

if [ "$apply" -eq 0 ]; then
  cat <<EOF
PLAN ONLY: no local disk or systemd changes will be made.
To apply on the control host, rerun: $0 --apply

Will configure:
  device: $MINIO_DEVICE
  mount: $MINIO_MOUNT
  bucket: $MINIO_BUCKET
  access key: $MINIO_ACCESS_KEY
  env file: $MINIO_ENV_FILE
EOF
  exit 0
fi

need_cmd curl
need_cmd openssl
need_cmd lsblk
need_cmd sudo

MINIO_SECRET_KEY="${MINIO_SECRET_KEY:-$(openssl rand -hex 16)}"

test -b "$MINIO_DEVICE" || die "$MINIO_DEVICE is not a block device"
if lsblk -nro MOUNTPOINT "$MINIO_DEVICE" | grep -q .; then
  die "$MINIO_DEVICE is already mounted"
fi

sudo mkfs.ext4 -q -F "$MINIO_DEVICE"
sudo mkdir -p "$MINIO_MOUNT"
sudo mount "$MINIO_DEVICE" "$MINIO_MOUNT"
minio_uuid="$(sudo blkid -s UUID -o value "$MINIO_DEVICE")"
if ! grep -q "UUID=$minio_uuid $MINIO_MOUNT" /etc/fstab; then
  echo "UUID=$minio_uuid $MINIO_MOUNT ext4 defaults,noatime 0 2" | sudo tee -a /etc/fstab >/dev/null
fi
sudo mkdir -p "$MINIO_MOUNT/data"
sudo chown admin:admin "$MINIO_MOUNT" "$MINIO_MOUNT/data"

if ! command -v minio >/dev/null 2>&1; then
  curl -fsSL https://dl.min.io/server/minio/release/linux-amd64/minio -o /tmp/minio
  chmod +x /tmp/minio
  sudo mv /tmp/minio /usr/local/bin/minio
fi

if ! command -v mc >/dev/null 2>&1; then
  curl -fsSL https://dl.min.io/client/mc/release/linux-amd64/mc -o /tmp/mc
  chmod +x /tmp/mc
  sudo mv /tmp/mc /usr/local/bin/mc
fi

printf 'ACCESS_KEY=%s\nSECRET_KEY=%s\nBUCKET=%s\n' \
  "$MINIO_ACCESS_KEY" "$MINIO_SECRET_KEY" "$MINIO_BUCKET" | \
  sudo tee "$MINIO_ENV_FILE" >/dev/null
sudo chmod 600 "$MINIO_ENV_FILE"

sudo tee /etc/systemd/system/minio.service >/dev/null <<UNIT
[Unit]
Description=MinIO server (TiDB X shared DFS)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=admin
Group=admin
WorkingDirectory=$MINIO_MOUNT
Environment="MINIO_ROOT_USER=$MINIO_ACCESS_KEY"
Environment="MINIO_ROOT_PASSWORD=$MINIO_SECRET_KEY"
ExecStart=/usr/local/bin/minio server $MINIO_MOUNT/data --address :9000 --console-address :9001
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now minio

for _ in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:9000/minio/health/live >/dev/null; then
    break
  fi
  sleep 1
done
curl -f http://127.0.0.1:9000/minio/health/live

mc alias set local http://127.0.0.1:9000 "$MINIO_ACCESS_KEY" "$MINIO_SECRET_KEY"
mc mb "local/$MINIO_BUCKET" 2>/dev/null || true

log "MinIO is ready at http://<control-private-ip>:9000 bucket=$MINIO_BUCKET"
