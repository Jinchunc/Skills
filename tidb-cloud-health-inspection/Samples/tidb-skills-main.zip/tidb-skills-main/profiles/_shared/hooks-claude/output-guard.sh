#!/usr/bin/env bash
# Output-guard hook — detects garbled output and warns on excessive length.
# Claude Code PostToolUse hook: reads JSON from stdin.
# Exit 0 = pass, exit 2 + stderr = block.
#
# Two checks:
#   1. Garbled text (>15% unexpected Unicode) → block
#   2. Long output (>30 lines) → warn via stderr (non-blocking)
set -euo pipefail

INPUT=$(cat)

# Extract tool output for scanning
OUTPUT=$(python3 -c "
import sys, json
d = json.load(sys.stdin)
out = d.get('tool_output', d.get('result', ''))
if isinstance(out, dict):
    out = json.dumps(out)
print(out[:10000] if out else '')
" <<< "$INPUT" 2>/dev/null || echo "")

if [ -z "$OUTPUT" ]; then
  exit 0
fi

# Run checks
RESULT=$(python3 -c "
import re, sys

text = sys.stdin.read()

# --- Check 1: Garbled text detection ---
# Sample middle 500 chars, count unexpected Unicode ratio
if len(text) >= 50:
    start = max(0, len(text) // 2 - 250)
    sample = text[start:start+500]
    expected = re.compile(r'[\u0000-\u024F\u0400-\u04FF\u2000-\u206F\u2E80-\u9FFF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\U00020000-\U0002FA1F]')
    total = 0
    unexpected = 0
    for ch in sample:
        if ch.isspace():
            continue
        total += 1
        if not expected.match(ch):
            unexpected += 1
    if total > 0 and (unexpected / total) > 0.15:
        print('garbled')
        sys.exit(0)

# --- Check 2: Long output warning ---
line_count = text.count('\n') + 1
if line_count > 30:
    print(f'long:{line_count}')
    sys.exit(0)

print('ok')
" <<< "$OUTPUT" 2>/dev/null || echo "ok")

case "$RESULT" in
  garbled)
    echo "[output-guard] BLOCKED — garbled/corrupted output detected" >&2
    # Log to audit
    AUDIT_DIR="${AUDIT_DIR:-${HOME}/.claude/audit}"
    if [ -d "$AUDIT_DIR" ] || mkdir -p "$AUDIT_DIR" 2>/dev/null; then
      TODAY=$(date -u +%Y-%m-%d)
      TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
      TS="$TS" python3 -c "
import json, os
print(json.dumps({'ts': os.environ['TS'], 'event': 'output_guard_garbled'}, ensure_ascii=False))
" >> "${AUDIT_DIR}/audit-${TODAY}.jsonl" 2>/dev/null || true
    fi
    exit 2
    ;;
  long:*)
    LINES="${RESULT#long:}"
    echo "[output-guard] Long output (${LINES} lines) — consider writing to a file first (Rule #39)" >&2
    exit 0
    ;;
  *)
    exit 0
    ;;
esac
