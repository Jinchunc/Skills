# MODULE-PD: PD Layer Decision Tree

> Source: A1 tidb-perf-diagnosis PD section refactored
> Purpose: PD layer performance diagnosis (TSO, scheduling, metadata management)

---

## Input
- cluster_id, metrics_endpoint
- time_range
- hint: Clues from upstream (e.g., "tso_wait high")

## Output
- root_cause
- confidence: HIGH / MEDIUM / LOW
- recommendation

---

## Decision Tree

```
Node 1: Is TSO latency abnormal?
  metrics:
    tso_handle_p99: histogram_quantile(0.99,
      sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[2m])) by (le))
    tso_wait_p99: histogram_quantile(0.99,
      sum(rate(pd_client_cmd_handle_cmds_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="wait"}[2m])) by (le))
  condition: tso_handle_p99 > 5ms or tso_wait_p99 > 2ms
  YES -> Node 1a
  NO -> Node 2

Node 1a: TSO Latency Root Cause
  checks (parallel):
    a. PD leader CPU:
       rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m])
       CPU > 80% -> "PD leader CPU overloaded"

    b. etcd latency:
       histogram_quantile(0.99, sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
       > 10ms -> "etcd WAL fsync slow (disk performance)"

    c. PD leader switching:
       pd_tso_events{tidb_cluster_id="{cluster_id}", type="save"} changes
       Frequent switching -> "PD leader unstable"

    d. Network latency (TiDB<->PD):
       TiDB-side tso_wait >> PD-side tso_handle
       Large gap -> "Network latency between TiDB and PD"
       -> PATH-NET-LATENCY

  -> DIAGNOSIS (based on matched check)

Node 2: Is Region Heartbeat backlogged?
  metrics:
    hb_pending: histogram_quantile(0.99, sum(rate(pd_scheduler_region_heartbeat_latency_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
    region_count: pd_cluster_status{tidb_cluster_id="{cluster_id}", type="region_count"}
  condition: hb_pending > 1s or region_count > 500000
  YES ->
    -> root_cause: "Region heartbeat backlog"
    -> region_count too high -> "Too many Regions causing PD pressure"
      - Check for large number of small Regions -> Recommend merging
      - Check if split is too aggressive
    -> PD CPU high -> "PD insufficient capacity for heartbeat processing"
    -> confidence: HIGH
  NO -> Node 3

Node 3: Scheduling anomaly?
  metrics:
    sched_ops: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
    store_limit: pd_schedule_store_limit{tidb_cluster_id="{cluster_id}"}
  checks:
    a. balance-leader operations frequent -> Hotspot migrating back and forth between instances
    b. balance-region operations frequent -> Uneven Region distribution
    c. Scheduling operations at 0 but load is uneven -> Scheduling disabled or store limit too low
  -> DIAGNOSIS (based on check results)
  -> confidence: MEDIUM

Node 4: PD Overall Health
  metrics:
    pd_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m])
    pd_mem{tidb_cluster_id="{cluster_id}"}: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="pd"}
    pd_goroutines{tidb_cluster_id="{cluster_id}"}: go_goroutines{tidb_cluster_id="{cluster_id}", job="pd"}
  condition: No anomaly
  -> root_cause: "No clear issue found at PD layer"
  -> confidence: LOW
```

---

## Data Source Call Templates

### TSO Latency
```
query: histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[2m])) by (le))
```

### Region Count
```
query: pd_cluster_status{tidb_cluster_id="{cluster_id}", type="region_count"}
```

### Heartbeat Latency
```
query: histogram_quantile(0.99, sum(rate(pd_scheduler_region_heartbeat_latency_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Scheduling Operations
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### etcd WAL fsync
```
query: histogram_quantile(0.99, sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```
