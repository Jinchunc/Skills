# Serverless SQL User

Base command: `ticloud serverless sql-user`

Manage cluster SQL users

## Direct Subcommands

- `ticloud serverless sql-user create` - Create a SQL user
- `ticloud serverless sql-user delete` - Delete a SQL user (dangerous)
- `ticloud serverless sql-user list` - List all accessible SQL users (human-output)
- `ticloud serverless sql-user update` - Update a SQL user (sensitive)

## Confirmation Required

- `ticloud serverless sql-user delete`
