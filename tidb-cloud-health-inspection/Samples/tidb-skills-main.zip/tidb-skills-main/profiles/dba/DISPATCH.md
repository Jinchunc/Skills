# DBA Dispatch Protocol

Three-layer dispatch: Domain (WHAT methodology) -> Engine (HOW for specific DB) -> Provider (WHERE to get data).

## Layer 1: Domain Dispatch

- Entry point: `domains/INDEX.md` Route table
- Input: user symptom/request (Chinese or English)
- Output: load `domains/<domain>/skill.md`
- Disambiguation: when intent matches multiple domains, use the Disambiguate table in INDEX.md -- ask user before proceeding
- Gap domains: inform user, offer best-effort with general knowledge

## Layer 2: Engine Detection & Loading

Domain skill.md runs the canonical 3-step detection:

1. **Explicit** -- user mentions engine name -> use that engine
2. **Inferred** -- cluster metadata available -> derive engine from cluster info
3. **Unknown** -- ask user which database engine

Load: `engines/<engine>/<domain>/SKILL.md`

Engine SKILL.md is a routing table only. It maps domain bottleneck classifications to engine-specific diagnostic files (paths/, modules/, playbooks/).

## Layer 3: Provider Detection & Loading

After engine is resolved, determine data access layer:

1. **Managed service** -- cluster is TiDB Cloud, AWS RDS, etc. -> use corresponding provider
2. **Environment hint** -- env vars or config indicate provider (e.g., API tokens for cloud o11y)
3. **Self-hosted** -- no managed provider detected (no cloud API tokens, no clinic endpoints in env, user confirms self-hosted). Skip Steps A/B/C entirely — use engine-native tools only (SQL system tables, CLI, local Prometheus/Grafana). The engine SKILL.md provides all necessary queries and thresholds without provider assistance.
4. **Unknown** -- ask user: "Is this a managed cloud database or self-hosted?"

### Provider Loading Protocol

Load provider files progressively -- not all at once. Each file is loaded when its data is first needed:

**Step A: Data source API (load when first metric/log query is needed)**

| Condition | Load | Lines |
|-----------|------|:-----:|
| Default (Clinic API available) | `providers/<provider>/ops/clinic-api.md` + `providers/<provider>/ops/SUBSKILLS_INDEX.md` | ~190 |
| Clinic unavailable or advanced access needed | `providers/<provider>/o11y/o11y-data.md` | ~720 |
| O11Y auth required | `providers/<provider>/o11y/o11y-auth.md` | ~130 |
| Legacy `/clinic/api/v1` endpoint details needed | `providers/<provider>/o11y/clinic-api.md` — legacy compatibility reference only | ~950 |

Load `ops/clinic-api.md` + `ops/SUBSKILLS_INDEX.md` first — the Clinic sub-skill system under `ops/` is the current authority; `o11y/clinic-api.md` is its previous-generation snapshot kept for legacy endpoint details only. Fall back to `o11y-data.md` if Clinic returns errors or if direct S3/Prometheus access is needed. `o11y-auth.md` is the additive auth layer — load it when O11Y API authentication is needed (e.g., generating tokens for direct Prometheus/Loki access); it supplements clinic-api.md or o11y-data.md, not replaces them.

**Step B: Product line docs (load after product line is determined)**

| Product Line | Load | Lines |
|-------------|------|:-----:|
| Dedicated | `engines/tidb/knowledge/product-lines/dedicated.md` | ~610 |
| Premium | `engines/tidb/knowledge/product-lines/premium.md` | ~770 |
| Essential | `engines/tidb/knowledge/product-lines/essential.md` | ~180 |
| Starter | `engines/tidb/knowledge/product-lines/starter.md` | ~170 |
| TiDB X common architecture (all tiers) | `engines/tidb/knowledge/product-lines/tidb-x.md` | ~100 |

Load order:
1. If the product line is TiDB X, first load `tidb-x.md` for the shared two-layer model.
2. Then load the tier-specific doc (`premium.md` / `essential.md` / `starter.md`) matching the cluster's `deployType`.
3. For Dedicated, load `dedicated.md` only.

Only load AFTER cluster metadata confirms the product line.

**Step C: Billing module (load only when throttling is suspected)**

| Condition | Load | Lines |
|-----------|------|:-----:|
| TiDB X cluster + latency/QPS symptom | `engines/tidb/knowledge/rcu-check.md` | ~175 |

Skip for Dedicated clusters (no RCU limits).

**Step D: Management-plane API (load when cluster enumeration or management operations are needed)**

| Condition | Load |
|-----------|------|
| Enumerate clusters in an org/project, or manage clusters via public API | `providers/<provider>/api/tidbcloud-api.md` |
| Prefer CLI for management operations | `providers/<provider>/api/tidbcloud-cli.md` |
| Ops context needed (tickets, oncall, release tasks) | `providers/<provider>/ops/` corresponding file |

Note: the public management API is project-scoped and does not cover Dedicated clusters. For org-wide enumeration with full product-line coverage, prefer the Clinic cluster-metadata sub-skill (`ops/SUBSKILLS_INDEX.md`, requires an internal-user token); legacy endpoint details remain in `o11y/clinic-api.md` §2.

### Provider File Organization

| Concern | Files | Purpose |
|---------|-------|---------|
| Observability | `o11y/clinic-api.md` (legacy), `o11y/o11y-data.md`, `o11y/o11y-auth.md` | Metric/log/slowlog retrieval APIs and data schemas |
| Management API | `api/tidbcloud-api.md`, `api/tidbcloud-cli.md` | Public cloud API / CLI for cluster enumeration and management (project-scoped, no Dedicated) |
| Ops systems | `ops/clinic-api.md`, `ops/devops-api.md`, `ops/jira-api.md`, `ops/oncall-*.md` | Internal ops portals, tickets, oncall workflows |
| HTTP access | `http/request-protocol.md` | Serverless HTTP SQL endpoint protocol |

Note: RCU throttling checks (`rcu-check.md`) and product-line capability docs (`product-lines/`) are TiDB-specific diagnostic knowledge and live under `engines/tidb/knowledge/`, not in the provider layer.

## Cross-Domain Handoff

When domain X discovers issues belonging to domain Y:

1. Load the OTHER domain's methodology: `domains/<other-domain>/skill.md`
2. Re-enter at Layer 1 -- never bypass domain to go directly to engine
3. Engine and provider context from the current session carries over

## File Layout

```
profiles/dba/
  DISPATCH.md                          # this file
  domains/
    INDEX.md                           # route table + disambiguate
    <domain>/skill.md                  # engine-agnostic methodology
    <domain>/description.md            # domain overview; Gap domains
                                       # (backup-recovery, compliance-audit,
                                       # resource-cost-manager, data-migration-sync)
                                       # have description.md only, no skill.md
  engines/
    <engine>/
      <domain>/SKILL.md               # symptom->path routing table
      <domain>/paths/                  # engine-specific diagnostic paths
      <domain>/modules/                # engine-specific component modules
      <domain>/playbooks/              # multi-step diagnostic playbooks
      knowledge/                       # dashboards, field corrections,
                                       # product-lines/, rcu-check.md
      references/                      # PromQL templates, patterns
  providers/
    <provider>/
      o11y/                            # observability API specs
      api/                             # public management API / CLI
      ops/                             # internal ops systems (tickets, oncall)
      http/                            # serverless HTTP endpoint protocol
```

## Contract

1. **Domain skill.md** MUST be engine-agnostic -- zero engine-specific terms, metrics, or tool names
2. **Engine SKILL.md** MUST be thin routing -- maps classifications to diagnostic files, contains no methodology
3. **Provider files** MUST be engine-independent -- API specs and data schemas, not diagnostic logic
4. **Cross-domain** MUST go through domain layer (Layer 1) -- never dispatch directly to another engine skill
5. **Detection order** is fixed: Domain -> Engine -> Provider. No layer may be skipped
6. **Session context** carries forward -- once engine/provider are resolved, they persist until user changes context
7. **Global safety guardrails** -- operation tiers, data handling, and network identity rules live in `GUARDRAILS.md` and apply to every domain, not only ops-change-management
