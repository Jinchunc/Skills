# Field Corrections — User-Validated Knowledge

> Source: Production user feedback from TiDBClaw/TiDBAgent sessions (2026-03-23 ~ 2026-03-30)
> These corrections address recurring diagnostic errors identified by experienced DBAs.

---

## 1. Region Count: Use leader_count, Not region_count

**Metric:** `pd_cluster_status{type="leader_count"}` for unique region count.

`pd_cluster_status{type="region_count"}` reports **total replicas across all stores** (typically 3x the actual unique region count). Using it directly will overcount by ~3x.

**Display:** Region counts use W (万/10K) as the unit. Example: 663W, not 6,630,000. Do not show ranges unless asked.

---

## 2. TiKV CPU Core Count: Use the Quota Metric

**Metric:** `tikv_server_cpu_cores_quota` gives the actual CPU core allocation per TiKV node.

Do NOT estimate CPU core counts from utilization percentages. The quota metric is the authoritative source.

---

## 3. DDL Parameter Dependency: tidb_enable_dist_task

When advising on disabling `tidb_ddl_enable_fast_reorg`:

**CRITICAL:** `tidb_enable_dist_task` MUST be disabled FIRST. If `tidb_ddl_enable_fast_reorg` is disabled while `tidb_enable_dist_task` is still ON, DDL operations will hang indefinitely.

Sequence: `SET GLOBAL tidb_enable_dist_task = OFF;` → then `SET GLOBAL tidb_ddl_enable_fast_reorg = OFF;`

---

## 4. TiCDC Prerequisites

When discussing upgrade options or data replication involving TiCDC:

- **Schema requirement:** Every table MUST have a Primary Key or NOT NULL Unique Key. Tables without PK/UK cannot be replicated.
- **Excluded indexes:** Indexes on VIRTUAL GENERATED COLUMNS do not satisfy the PK/UK requirement.
- **SEQUENCE limitation:** TiCDC does NOT synchronize SEQUENCE DDL operations. SEQUENCE objects must be manually recreated on the target cluster.

Always mention these when planning Blue-Green upgrades with TiCDC.

---

## 5. BATCH ON (Non-Transactional DML) Progress Tracking

BATCH ON statements in slow query logs contain SQL comments indicating progress:
- `/*job 1/N */` — first job (start of batch)
- `/*job N/N */` — last job (end of batch)

**To track progress:**
1. Filter slow query for `job 1/{total}` → batch start time
2. Filter for `job {total}/{total}` → batch end time
3. Difference = total execution duration

**To monitor in-flight batches:** query incrementally (only the time range since last check), merge with previous results. Output format: previous state → new data → merged result (for user verification).

---

## 6. SELECT Does Not Acquire Pessimistic Locks

In TiDB, **plain SELECT (without FOR UPDATE) NEVER acquires pessimistic locks.** Only SELECT ... FOR UPDATE, INSERT, UPDATE, DELETE acquire locks.

When analyzing lock contention:
- Always check the execution plan's `lock_keys` field for the exact number of keys locked
- Unique index point-get locks exactly 2 keys (index key + primary key row)
- Do not speculate about range locking when the execution plan shows point-get on a unique index
- Different unique key values CANNOT cause lock contention with each other

---

## 7. Cross-Database Transaction Lock Pattern

When multiple tables in **different databases** show simultaneous lock blocking with identical timeout durations (e.g., both blocked for exactly 50s):

**Suspect:** A cross-database transaction — common in JPA/Hibernate applications using `@Transactional` that operates across schemas.

**Investigation:**
1. Compare start/end times of blocking events across tables — matching end times strongly suggest a single transaction
2. The blocker may be invisible in slow query logs if individual SQL statements complete quickly but the transaction stays open while the application does non-DB work (API calls, message queue operations)
3. Look for Connection IDs that appear across both databases
4. Use `INFORMATION_SCHEMA.CLUSTER_TIDB_TRX` to find long-running transactions

---

## 8. Source Code Analysis Rigor

When analyzing TiDB/TiKV source code:

- **Verify visibility claims:** Do not assume one component cannot see another's data without reading the actual iterator/reader implementation. Example: LOCK_CF iterator may merge txn_files before memtables/SSTs.
- **Trace full call chains:** When asserting what code "cannot" do, trace the full call path including any merge/overlay logic.
- **Distinguish success from effectiveness:** "DDL completes without error" does NOT mean "subsequent behavior changes." Verify both independently.
- **Show complete state transitions:** In technical reports, trace every intermediate state change step by step. Do not skip steps in causal chains.
- **Cite exact locations:** Every claim about code behavior must reference file:line and include the relevant code snippet.
