# HEARTBEAT.md

# Periodic checks (uncomment and customize; keep small to limit token burn):
# - Slow queries in last 24h; pending migrations; replication lag; last successful backup time
