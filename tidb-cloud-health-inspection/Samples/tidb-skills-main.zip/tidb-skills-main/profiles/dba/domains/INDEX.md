# DBA Problem Domains

Classify user's DBA problem and communicate capabilities.

**When user asks about capabilities** ("你能做什么", "能力", "支持哪些", "what can you do"):
Present the Route table below — show Covered, Partial, and Gap domains with their capabilities.

**When user presents a DBA problem:**
1. Match intent to domain using Signal column
2. Covered/Partial → proceed to Skill Dispatch below; domain classification narrows the skill's scenario
3. Gap → inform user this domain lacks specialized capability, offer best-effort with general knowledge
4. Ambiguous → use Disambiguate table, ask user before proceeding

## Route

| Domain | Signal | Capabilities | Status |
|---|---|---|---|
| performance-optimization | 性能 延迟 慢 QPS P99 P999 P9999 调优 | 慢 SQL 诊断、执行计划分析、DB Time 分解、资源瓶颈定位、批量慢查询分析、热点诊断、优化修复 | Covered |
| fault-diagnosis | 故障 宕机 不可用 OOM 节点异常 | 根因定位、服务恢复、故障修复、节点/集群/分片故障、OOM、连接异常、CDC 延迟排障 | Covered |
| instance-inspection | 巡检 健康检查 报告 org 全部集群 整体情况 总览 盘点 fleet 多集群 | 全栈健康检查(6类30项)、4级评分、性能基线对比、安全快扫、巡检报告、org 级集群总览(fleet overview) | Covered |
| ops-change-management | 扩缩容 升级 改参数 变更 | 扩缩容评估、参数调优、版本升级路径、配置变更影响评估、回滚方案 | Partial |
| sql-schema-management | SQL审核 DDL 表结构 索引 | 表结构设计、索引策略、SQL规范审核、DDL影响评估、执行计划预评估 | Partial |
| backup-recovery | 备份 恢复 RPO RTO 容灾 | 备份策略评估、RPO/RTO验证、PITR覆盖检查、恢复演练评估 | Gap |
| compliance-audit | 权限 合规 加密 审计 | 权限矩阵审计、合规基线检查、加密状态验证、审计日志分析 | Gap |
| resource-cost-manager | 成本 容量 归档 闲置 | 成本分析、容量规划、闲置资源检测、归档策略、计费单元优化 | Gap |
| data-migration-sync | 迁移 同步 CDC 复制 | 迁移方案设计、同步拓扑规划、CDC链路规划、数据校验 | Gap |

**Status:** Covered = full engine skill. Partial = limited coverage. Gap = no engine skill, best-effort only.

## Disambiguate

| Ambiguous Signal | A | B | Ask |
|---|---|---|---|
| CDC 延迟 | fault-diagnosis | data-migration-sync | 排障还是建设? |
| 慢 SQL | performance-optimization | sql-schema-management | 事后还是事前? |
| 安全项 | instance-inspection | compliance-audit | 快扫还是深审? |
| DDL 变更 | sql-schema-management | ops-change-management | 评估还是执行? |
| 大表/归档 | resource-cost-manager | sql-schema-management | 容量还是结构? |
| 巡检/报告 | 单集群巡检 | org 级 fleet 总览 | 单个集群还是整个 org? |

## Engine Coverage

| Engine | Covered Domains | Status |
|--------|----------------|--------|
| TiDB | performance-optimization, fault-diagnosis, instance-inspection, ops-change-management | Full |
| PostgreSQL | performance-optimization, fault-diagnosis | Partial (2/9) |

Engine skills live in `engines/<engine>/<domain>/SKILL.md`. When a domain has engine coverage, the engine skill provides database-specific diagnostic paths, queries, and tuning parameters. When coverage is missing, fall back to domain-level general methodology.

Details per domain: `domains/<domain>/description.md`

## Engine Detection and Provider Loading

All domain skills use the same engine detection and provider loading procedure:

**Engine Detection**

1. User mentions engine name → use that engine
2. Cluster metadata available → infer engine from cluster info
3. Unknown → ask user which database engine

**Load engine:** Read `engines/<engine>/<domain>/SKILL.md` if it exists. If the engine has no skill for this domain, continue with the domain's general methodology only.

**Load provider:** follow DISPATCH.md Layer 3 Provider Loading Protocol (progressive: data API → product line → billing).
