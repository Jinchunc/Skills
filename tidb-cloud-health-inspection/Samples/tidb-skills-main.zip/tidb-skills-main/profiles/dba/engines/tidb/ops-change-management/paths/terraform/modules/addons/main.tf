# ── AWS EKS add-ons ───────────────────────────────────────────────────────────

# EBS CSI driver — required for gp3 PersistentVolumes used by TiDB components.
resource "aws_eks_addon" "ebs_csi" {
  cluster_name                = var.cluster_name
  addon_name                  = "aws-ebs-csi-driver"
  service_account_role_arn    = var.ebs_csi_role_arn
  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"
  tags                        = var.tags
}

# ── StorageClass ──────────────────────────────────────────────────────────────

# Creates a gp3 StorageClass and marks it as the cluster default for new PVCs,
# providing better price/performance than the legacy gp2 default on many EKS
# clusters. volumeBindingMode=WaitForFirstConsumer avoids cross-AZ scheduling
# issues.
#
# Uses the typed kubernetes_storage_class_v1 resource (not kubernetes_manifest)
# so Terraform does not pre-validate against the EKS OpenAPI schema during
# `plan`. That validation requires a live EKS API endpoint and would otherwise
# break a single-phase apply on a fresh workspace.
resource "kubernetes_storage_class_v1" "gp3" {
  metadata {
    name = "gp3"
    annotations = {
      # Mark gp3 as the cluster default so all PVCs without an explicit
      # storageClassName get the encrypted gp3 volume.
      "storageclass.kubernetes.io/is-default-class" = "true"
    }
  }

  storage_provisioner    = "ebs.csi.aws.com"
  reclaim_policy         = "Delete"
  volume_binding_mode    = "WaitForFirstConsumer"
  allow_volume_expansion = true
  parameters = {
    type      = "gp3"
    fsType    = "ext4"
    encrypted = "true"
  }

  depends_on = [aws_eks_addon.ebs_csi]
}

# ── Helm add-ons ──────────────────────────────────────────────────────────────

# metrics-server — provides CPU/memory metrics consumed by HPA and kubectl top.
resource "helm_release" "metrics_server" {
  count = var.enable_metrics_server ? 1 : 0

  name       = "metrics-server"
  repository = "https://kubernetes-sigs.github.io/metrics-server/"
  chart      = "metrics-server"
  version    = var.metrics_server_chart_version
  namespace  = "kube-system"

  # Minimal default values — the upstream chart defaults are sufficient for
  # most clusters; override via var.metrics_server_values if needed.
  values = var.metrics_server_values
}

# ingress-nginx — optional NLB-based ingress controller.
# Disabled by default; enable when exposing TiDB or other services externally.
resource "helm_release" "ingress_nginx" {
  count = var.enable_ingress_nginx ? 1 : 0

  name             = "ingress-nginx"
  repository       = "https://kubernetes.github.io/ingress-nginx"
  chart            = "ingress-nginx"
  version          = var.ingress_nginx_chart_version
  namespace        = "ingress-nginx"
  create_namespace = true

  # Route traffic through an AWS NLB (Network Load Balancer) with IP-mode
  # targets so pods receive real client IPs.
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/aws-load-balancer-type"
    value = "external"
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/aws-load-balancer-nlb-target-type"
    value = "ip"
  }

  values = var.ingress_nginx_values
}

