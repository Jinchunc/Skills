#!/usr/bin/env bash
# Redact hook — detects sensitive data in tool output and blocks if found.
# Claude Code PostToolUse hook: reads JSON from stdin.
# Exit 0 = pass, exit 2 + stderr = block.
#
# Defense-in-depth: catches credentials even if the model leaks them.
set -euo pipefail

INPUT=$(cat)

# Extract tool output for scanning
OUTPUT=$(python3 -c "
import sys, json
d = json.load(sys.stdin)
# PostToolUse: tool output is in tool_output or result
out = d.get('tool_output', d.get('result', ''))
if isinstance(out, dict):
    out = json.dumps(out)
print(out[:10000] if out else '')
" <<< "$INPUT" 2>/dev/null || echo "")

if [ -z "$OUTPUT" ]; then
  exit 0
fi

# Check for sensitive patterns
FOUND=$(python3 -c "
import re, sys

text = sys.stdin.read()
patterns = [
    ('aws_key', r'(?:AKIA|ASIA)[A-Z0-9]{16}'),
    ('bearer_token', r'Bearer\s+[A-Za-z0-9\-._~+/]+=*'),
    ('api_token', r'(?:ghp_|gho_|ghu_|ghs_|ghr_|sk-|pk-|xoxb-|xoxp-|ATATT)\S+'),
    ('private_key', r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----'),
    ('jwt', r'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'),
    ('generic_secret', r'(?:api[_-]?key|api[_-]?secret|secret[_-]?key|access[_-]?token|auth[_-]?token)\s*[:=]\s*[\"'\''']?\S+'),
    ('password', r'(?:password|passwd|pwd)\s*[:=]\s*\S+'),
    ('conn_string_pw', r'://[^:]+:([^@]+)@'),
]

found = []
for name, pat in patterns:
    if re.search(pat, text, re.IGNORECASE):
        found.append(name)

if found:
    print(','.join(found))
" <<< "$OUTPUT" 2>/dev/null || echo "")

if [ -n "$FOUND" ]; then
  echo "[redact-hook] Sensitive data detected in tool output: ${FOUND}" >&2
  # Log to audit if AUDIT_DIR is set
  AUDIT_DIR="${AUDIT_DIR:-${HOME}/.claude/audit}"
  if [ -d "$AUDIT_DIR" ] || mkdir -p "$AUDIT_DIR" 2>/dev/null; then
    TODAY=$(date -u +%Y-%m-%d)
    TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    TS="$TS" FOUND="$FOUND" python3 -c "
import json, os
print(json.dumps({'ts': os.environ['TS'], 'event': 'redact_block', 'patterns': os.environ['FOUND']}, ensure_ascii=False))
" >> "${AUDIT_DIR}/audit-${TODAY}.jsonl" 2>/dev/null || true
  fi
  exit 2
fi

exit 0
