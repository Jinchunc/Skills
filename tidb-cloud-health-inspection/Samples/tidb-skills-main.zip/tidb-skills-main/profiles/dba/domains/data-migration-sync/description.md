# Domain 9: 数据迁移与同步 (Data Migration & Sync)

> Status: **Gap**
> Tier: B (Engine-weak; 工具链部分偏 C)

## Core

一次性迁移方案 + 持续同步方案设计。

## Scenarios

- 迁移工具选型（DM/Lightning/Dumpling/Debezium/pg_dump/mongodump）
- 同步拓扑设计
- 一致性保证方案
- 迁移进度监控与数据校验
- CDC 链路规划与管理
- 源/目标兼容性评估

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | — | Not yet built |
| MySQL | — | Not yet built |
| PostgreSQL | — | Not yet built |
| MongoDB | — | Not yet built |

## Key Checks (to build)

- 源/目标兼容性矩阵
- 工具推荐（基于引擎/数据量/停机容忍度）
- 数据量估算
- 停机窗口计算
- 校验工作流设计
- 同步拓扑设计
- 一致性保证级别选择

## Routing Note

- CDC 链路方案设计 → 本域
- CDC 延迟作为故障症状排查 → 域1 (fault-diagnosis)
