# PATH-SCALING (Scale-Out / Scale-In Issues)

> Entry condition: Scaling operation stuck / new nodes not taking load / rebalance too slow or too aggressive

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range
3. Scaling direction: scale-out or scale-in

---

## Decision Tree

### Step 1: Identify Scaling State

```
metrics:
  store_status: pd_cluster_status{tidb_cluster_id="{cluster_id}", type=~"store_.*"}
  sched_ops: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[1m])) by (type, event)

New stores appearing → scale-out in progress
Stores going offline → scale-in in progress
No scheduling activity → scaling may be stuck
```

### Branch A: Scale-Out (New Nodes Not Taking Load)

**A1: Check Region Migration**
```
metrics:
  region_per_store: sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="region"}) by (instance)
  leader_per_store: sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="leader"}) by (instance)

New store region count << average → rebalance in progress or stuck
New store leader count = 0 → leader transfer not started
```

**A2: Check PD Scheduling Rate**
```
metrics:
  balance_region: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}", type="balance-region"}[1m]))
  balance_leader: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}", type="balance-leader"}[1m]))

Both zero → scheduler may be paused or store-limit = 0
Active but slow → check store-limit config (default 15 ops/min per store)
```

**A3: Check Snapshot Throughput**
```
metrics:
  snapshot_sending: tikv_raftstore_snapshot_traffic_total{tidb_cluster_id="{cluster_id}", type="sending"}
  snapshot_receiving: tikv_raftstore_snapshot_traffic_total{tidb_cluster_id="{cluster_id}", type="receiving"}

Large snapshot volume → normal during rebalance, but may saturate disk/network
→ If impacting production latency: reduce store-limit temporarily
```

### Branch B: Scale-In (Store Offline Stuck)

- Check target store state: `pd_cluster_status` → is it `offline` or already `tombstone`?
- If offline for extended time → check remaining regions:
  ```
  tikv_raftstore_region_count{instance="{offline_store}"} → still has regions?
  ```
- Regions stuck → may have placement rules preventing migration
- Check if other stores have capacity to absorb regions

→ [PATH-STORE-FAILURE](store-failure.md) if store went down during scale-in

### Step 2: Impact on Production

```
metrics:
  p99_latency: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))
  disk_io: rate(node_disk_io_time_seconds_total{tidb_cluster_id="{cluster_id}"}[1m]) by (instance)

Latency spike during scaling → snapshot I/O competing with production
→ Recommendations: lower store-limit, schedule during off-peak, increase snapshot speed limit
```

→ DIAGNOSIS + recommendations: adjust scheduling parameters / wait for rebalance / investigate placement rules

---

## Data Source Call Templates

### Region Distribution per Store
```
query: sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="region"}) by (instance)
```

### Leader Distribution per Store
```
query: sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="leader"}) by (instance)
```

### PD Balance Scheduling Rate
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}", type=~"balance-.*"}[1m])) by (type, event)
```

### Snapshot Traffic
```
query: sum(rate(tikv_raftstore_snapshot_traffic_total{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, type)
```

### Store Status
```
query: pd_cluster_status{tidb_cluster_id="{cluster_id}", type=~"store_.*"}
```
