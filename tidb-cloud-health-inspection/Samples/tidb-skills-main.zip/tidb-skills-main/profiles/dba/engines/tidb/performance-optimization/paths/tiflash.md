# PATH-TIFLASH (TiFlash Analytical Engine Issues)

> Entry condition: TiFlash query slow / replica lag / TiFlash node resource issues / TiFlash not used when expected

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range
3. Symptom: query performance / replica sync / resource / query routing

---

## Decision Tree

### Step 1: Classify Problem Type

| Symptom | Branch |
|---------|--------|
| TiFlash query slow | Branch A |
| TiFlash replica not up-to-date | Branch B |
| TiFlash node OOM / high CPU | Branch C |
| Query not routed to TiFlash | Branch D |

### Branch A: TiFlash Query Slow

**A1: Check Coprocessor Latency**
```
metrics:
  cop_p99: histogram_quantile(0.99, sum(rate(tiflash_coprocessor_request_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))

< 500ms → normal for analytical queries
> 1s → A2
```

**A2: Check Query Queue**
```
metrics:
  queue_size: tiflash_system_current_metric_QueryQueueSize{tidb_cluster_id="{cluster_id}"}

Queue > 0 sustained → TiFlash overloaded → check CPU / concurrent queries
Queue = 0 → single query bottleneck → check data volume / scan range
```

**A3: Check TiFlash CPU**
```
metrics:
  cpu: rate(tiflash_proxy_process_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])
  logical_cores: tiflash_system_current_metric_LogicalCPUCores{tidb_cluster_id="{cluster_id}"}

CPU / logical_cores > 80% → CPU saturated → scale TiFlash or reduce concurrent queries
```

### Branch B: TiFlash Replica Lag

**B1: Check Replica Progress**
```sql
SELECT TABLE_SCHEMA, TABLE_NAME, AVAILABLE, PROGRESS
FROM information_schema.tiflash_replica
WHERE AVAILABLE = 0 OR PROGRESS < 1
```

**B2: Check Raft Learner Lag**
```
metrics:
  learner_read_index: histogram_quantile(0.99, sum(rate(tiflash_proxy_tikv_raftstore_commit_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))

High learner lag → check:
  - TiFlash disk I/O → is snapshot apply bottlenecked
  - Network between TiKV and TiFlash → [PATH-NET-LATENCY](net-latency.md)
  - TiKV source store under pressure → [PATH-CPU-HIGH](cpu-high.md)
```

### Branch C: TiFlash Resource Issues

**C1: Memory**
```
metrics:
  rss: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tiflash"}

Approaching container limit → OOM risk
→ Check concurrent analytical queries, reduce parallelism or scale up
```

**C2: Disk**
```
metrics:
  disk_used: tiflash_system_current_metric_StoreSizeUsed{tidb_cluster_id="{cluster_id}"}
  disk_capacity: tiflash_system_current_metric_StoreSizeCapacity{tidb_cluster_id="{cluster_id}"}

Used / capacity > 80% → [PATH-DISK-SPACE](disk-space.md)
```

### Branch D: Query Not Routed to TiFlash

- Check `tidb_isolation_read_engines` session variable: must include `tiflash`
- Check TiFlash replica status: `AVAILABLE = 1` in `information_schema.tiflash_replica`
- Check if optimizer chose TiKV: use `EXPLAIN` to verify execution plan
- If table small → optimizer may prefer TiKV (cost-based decision)
- Force with hint: `/*+ READ_FROM_STORAGE(TIFLASH[table_name]) */`

→ DIAGNOSIS + recommendations: adjust isolation read engines / check replica availability / use hints

---

## Data Source Call Templates

### TiFlash Coprocessor P99 Latency
```
query: histogram_quantile(0.99, sum(rate(tiflash_coprocessor_request_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))
```

### TiFlash Query Queue Size
```
query: tiflash_system_current_metric_QueryQueueSize{tidb_cluster_id="{cluster_id}"}
```

### TiFlash CPU Usage
```
query: rate(tiflash_proxy_process_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])
```

### TiFlash Logical CPU Cores
```
query: tiflash_system_current_metric_LogicalCPUCores{tidb_cluster_id="{cluster_id}"}
```

### TiFlash Memory RSS
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tiflash"} by (instance)
```

### TiFlash Disk Usage
```
query: tiflash_system_current_metric_StoreSizeUsed{tidb_cluster_id="{cluster_id}"} / tiflash_system_current_metric_StoreSizeCapacity{tidb_cluster_id="{cluster_id}"}
```

---

## Remediation References

When query routing or TiFlash performance needs tuning:
- Session variables (tidb_isolation_read_engines, TiFlash concurrency): [../references/session-variables.md](../references/session-variables.md)
- Optimizer hints (READ_FROM_STORAGE): [../references/optimizer-controls.md](../references/optimizer-controls.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
