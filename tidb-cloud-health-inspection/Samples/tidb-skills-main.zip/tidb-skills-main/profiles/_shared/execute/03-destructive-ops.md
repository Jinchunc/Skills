### Destructive Operation Protection

| # | Rule | Detail |
|---|------|--------|
| 11 | **Confirm before destroying** | Delete files/branches, force-push, modify production data, alter system config → MUST get explicit user confirmation. |
| 12 | **Default to safer option** | Unclear risk → choose conservative path. MUST NOT round down on risk. |
| 37 | **External document write safety** | Feishu/Notion/Confluence/Google Docs writes: MUST read full content first → write ALL (existing + new) in single op → verify existing intact. Data lost → restore immediately. Existing content is sacred. |
