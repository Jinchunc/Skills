#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Usage:
  validate_cluster.sh [--plan|--apply]

Runs post-deploy validation from the control host. It checks TiUP display,
MinIO health, cse-worker health/logs, remote TiKV config, SQL smoke, ANALYZE,
DFS config consistency, and absence of the PD keyspace GC API mismatch.
Defaults to --plan.
USAGE
}

action="${1:---plan}"
case "$action" in
  --plan) apply=0 ;;
  --apply) apply=1 ;;
  --help) usage; exit 0 ;;
  *) usage; exit 1 ;;
esac

TIDB_PORT="${TIDB_PORT:-4000}"
MYSQL_USER="${MYSQL_USER:-root}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-}"
CONTROL_PRIVATE_IP="${CONTROL_PRIVATE_IP:-}"
MINIO_ENDPOINT="${MINIO_ENDPOINT:-}"
VALIDATE_RG="${VALIDATE_RG:-0}"
PROMETHEUS_URL="${PROMETHEUS_URL:-}"
SSH_USER="${SSH_USER:-admin}"
SSH_OPTS_DEFAULT="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
SSH_OPTS="${SSH_OPTS:-$SSH_OPTS_DEFAULT}"

require_env CLUSTER_NAME TIDB_HOST TIKV_HOST

if [ -z "$MINIO_ENDPOINT" ]; then
  require_env CONTROL_PRIVATE_IP
  MINIO_ENDPOINT="http://$CONTROL_PRIVATE_IP:9000"
fi

if [ "$apply" -eq 0 ]; then
  cat <<EOF
PLAN ONLY: validation commands will not be executed.
To validate, rerun: $0 --apply

Will validate:
  cluster: $CLUSTER_NAME
  TiDB: $TIDB_HOST:$TIDB_PORT
  TiKV sample host: $TIKV_HOST
  MinIO endpoint: $MINIO_ENDPOINT
  Resource Group validation: $VALIDATE_RG
EOF
  exit 0
fi

need_cmd tiup
need_cmd mysql
need_cmd curl
need_cmd ssh

ssh_args=()
if [ -n "$SSH_OPTS" ]; then
  # shellcheck disable=SC2206
  ssh_args=($SSH_OPTS)
fi
if [ -n "${SSH_KEY_PATH:-}" ]; then
  [ -f "$SSH_KEY_PATH" ] || die "missing SSH key: $SSH_KEY_PATH"
  ssh_args+=(-i "$SSH_KEY_PATH")
fi

mysql_cmd=(mysql -h "$TIDB_HOST" -P "$TIDB_PORT" -u "$MYSQL_USER")
if [ -n "$MYSQL_PASSWORD" ]; then
  mysql_cmd+=("-p$MYSQL_PASSWORD")
fi

run_sql() {
  local sql="$1"
  "${mysql_cmd[@]}" -e "$sql"
}

tiup cluster display "$CLUSTER_NAME"

tiup cluster exec "$CLUSTER_NAME" -R tikv --command 'systemctl is-active cse-worker'
tiup cluster exec "$CLUSTER_NAME" -R tikv --command 'curl -sf http://127.0.0.1:9500/healthz'
tiup cluster exec "$CLUSTER_NAME" -R tikv --command 'tail -n 80 /home/admin/cse-worker.log'

curl -f "$MINIO_ENDPOINT/minio/health/live"

run_sql "CREATE DATABASE IF NOT EXISTS smoke; CREATE TABLE IF NOT EXISTS smoke.t(a INT PRIMARY KEY); INSERT INTO smoke.t VALUES (1) ON DUPLICATE KEY UPDATE a=a; SELECT * FROM smoke.t;"
run_sql "SHOW CONFIG WHERE type='tikv' AND name LIKE 'kvengine.remote-%addr';"
run_sql "CREATE DATABASE IF NOT EXISTS rc_debug; CREATE TABLE IF NOT EXISTS rc_debug.analyze_smoke (id INT PRIMARY KEY, v VARCHAR(32)); INSERT INTO rc_debug.analyze_smoke VALUES (1, 'ok') ON DUPLICATE KEY UPDATE v='ok'; ANALYZE TABLE rc_debug.analyze_smoke; SHOW STATS_META WHERE db_name='rc_debug' AND table_name='analyze_smoke';"

grep -E 'dfs\.s3-|dfs\.prefix' "${TOPOLOGY_FILE:-$HOME/topo.yaml}" || true
ssh "${ssh_args[@]}" "$SSH_USER@$TIKV_HOST" "grep -A8 '^\[dfs\]' /home/admin/cse-worker.toml"

tiup cluster exec "$CLUSTER_NAME" -R tikv --command \
  'grep -q "GetAllKeyspacesGCStates.*UNIMPLEMENTED" /tidb-deploy/tikv-30160/log/tikv.log
   rc=$?
   if [ "$rc" -eq 0 ]; then
     grep "GetAllKeyspacesGCStates.*UNIMPLEMENTED" /tidb-deploy/tikv-30160/log/tikv.log | tail
     exit 1
   elif [ "$rc" -gt 1 ]; then
     exit "$rc"
   fi'

ssh "${ssh_args[@]}" "$SSH_USER@$TIKV_HOST" \
  'grep -Ei "remote_dispatcher|is remote true|remote compactor" /tidb-deploy/tikv-30160/log/tikv.log | tail -40' || true

if [ "$VALIDATE_RG" = "1" ]; then
  run_sql "CREATE RESOURCE GROUP IF NOT EXISTS test_rg RU_PER_SEC=5000 PRIORITY=MEDIUM; DROP USER IF EXISTS 'test_user'@'%'; CREATE USER 'test_user'@'%' IDENTIFIED BY 'test_pass'; GRANT ALL ON *.* TO 'test_user'@'%'; ALTER USER 'test_user'@'%' RESOURCE GROUP test_rg; SELECT user_attributes FROM mysql.user WHERE user='test_user';"
  mysql -h "$TIDB_HOST" -P "$TIDB_PORT" -u test_user -ptest_pass -e \
    'SELECT CURRENT_RESOURCE_GROUP(); SELECT * FROM smoke.t;'
  if [ -n "$PROMETHEUS_URL" ]; then
    curl -G "$PROMETHEUS_URL/api/v1/query" \
      --data-urlencode 'query=sum(rate(resource_manager_resource_unit_read_request_unit_sum[5m])) by (name)'
  else
    log "PROMETHEUS_URL not set; manually verify Resource Group RU series."
  fi
fi

log "Validation completed"
