# Authentication

Base command: `ticloud auth`

Login and logout via TiDB Cloud API

## Direct Subcommands

- `ticloud auth login` - Authenticate with TiDB Cloud
- `ticloud auth logout` - Log out of TiDB Cloud (sensitive)
- `ticloud auth whoami` - Display information about the current user
