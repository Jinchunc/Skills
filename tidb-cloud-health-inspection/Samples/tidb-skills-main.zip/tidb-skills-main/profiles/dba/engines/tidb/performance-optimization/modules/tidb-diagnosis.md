# MODULE-TIDB: TiDB Layer Decision Tree

> Source: A1 tidb-perf-diagnosis TiDB section refactored
> Purpose: When MODULE-DBTIME identifies the bottleneck at the TiDB layer, perform further diagnosis

---

## Input
- cluster_id, metrics_endpoint
- time_range
- hint: Clues from upstream path (optional)

## Output
- root_cause: Specific root cause
- confidence: HIGH / MEDIUM / LOW
- recommendation: Optimization suggestions

---

## Decision Tree

```
Node 1: Is load balanced across TiDB instances?
  metrics:
    per_instance_qps: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
    per_instance_cpu: rate(process_cpu_seconds_total{job="tidb", tidb_cluster_id="{cluster_id}"}[1m]) by (instance)
  condition: Some instance QPS or CPU > mean x 2
  YES (imbalanced) ->
    -> root_cause: "TiDB instance load imbalance"
    -> Related: Load Balancer / TiProxy configuration, connection pinning
    -> See also: ../references/promql-templates.md (instance-level QPS/CPU)
    -> confidence: HIGH
  NO -> Node 2

Node 2: Is Parse/Compile overhead high?
  metrics:
    parse_p99:   histogram_quantile(0.99, sum(rate(tidb_session_parse_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
    compile_p99: histogram_quantile(0.99, sum(rate(tidb_session_compile_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
    plan_cache_hit: sum(rate(tidb_server_plan_cache_total{tidb_cluster_id="{cluster_id}", type="hit"}[2m])) / sum(rate(tidb_server_plan_cache_total{tidb_cluster_id="{cluster_id}"}[2m]))
  condition: parse_p99 > 5ms or compile_p99 > 10ms or plan_cache_hit < 0.8
  YES ->
    -> root_cause: "High Parse/Compile overhead"
    -> plan_cache_hit low -> "Low Plan Cache hit rate, many SQL statements need recompilation"
      - Related: Prepared Statement usage, `tidb_enable_prepared_plan_cache` setting
    -> SQL itself complex -> "SQL too complex (many JOINs / subqueries)"
    -> confidence: HIGH
  NO -> Node 3

Node 3: Is TSO wait high?
  metrics:
    tso_wait_p99: histogram_quantile(0.99,
      sum(rate(tidb_tikvclient_ts_future_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
    tso_rpc_p99: histogram_quantile(0.99,
      sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[2m])) by (le))
  condition: tso_wait_p99 > 5ms
  YES ->
    -> Delegate to pd-diagnosis.md (TSO issue root cause is in PD layer)
    -> confidence: HIGH
  NO -> Node 4

Node 4: Connection/Goroutine pressure
  metrics:
    connections: tidb_server_connections{tidb_cluster_id="{cluster_id}"}
    goroutines: go_goroutines{tidb_cluster_id="{cluster_id}", job="tidb"}
    active_conn: tidb_server_tokens{tidb_cluster_id="{cluster_id}", type="active"}
  condition: goroutines > 10000 or active_conn approaching token-limit
  YES ->
    -> root_cause: "TiDB connection/goroutine pressure high"
    -> Related: slow query accumulation (sql-diagnosis.md), connection pool config (max idle / max open)
    -> confidence: MEDIUM
  NO -> Node 5

Node 5: Memory pressure
  metrics:
    heap_inuse: go_memstats_heap_inuse_bytes{tidb_cluster_id="{cluster_id}", job="tidb"}
    mem_quota:  tidb_server_memory_quota_bytes{tidb_cluster_id="{cluster_id}"}
  condition: heap_inuse > mem_quota * 0.8
  YES ->
    -> root_cause: "TiDB memory approaching quota"
    -> Memory pressure may cause frequent GC, OOM Kill
    -> Related: top memory-consuming SQL (sql-diagnosis.md)
    -> confidence: MEDIUM
  NO ->
    -> root_cause: "No clear bottleneck found at TiDB layer"
    -> confidence: LOW
    -> Return to domain methodology for cross-component analysis
```

---

---

## TopSQL — TiDB CPU Attribution Tool

The domain methodology's "CPU Attribution Cross-Verification" uses TopSQL as the TiDB-specific implementation:

- **Tool:** TopSQL, filter `component='tikv'` + specific instance + event time window
- **Top-N threshold:** Top 20 by `topsql_cpu_time_ms`
- **Coprocessor P99 caveat:** `tikv_coprocessor_request_handle_seconds` P99 shows latency, not CPU contribution — use TopSQL instead
- **Known false positive:** `analyze_full_sampling` shows high P99 but is IO-bound; verify with `sum(rate(tikv_coprocessor_request_handle_seconds_sum)) by type`

### "Slow vs Hot" TiDB-Specific Metrics

| Concept | TiDB Metric |
|---------|-------------|
| Slow (single-request latency) | `tikv_coprocessor_request_handle_seconds` P99 |
| Hot (total CPU consumption) | `sum(rate(tikv_coprocessor_request_handle_seconds_sum))` or TopSQL `topsql_cpu_time_ms` |

---

## TiKV Thread Pool Analysis

**Entry criteria:** Use when MODULE-DBTIME identifies bottleneck at TiKV layer (kv_read or kv_write) and per-instance TiKV CPU is elevated.

When TiKV instances show high latency, check thread pool utilization:

```
metrics:
  thread_cpu: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, name)
```

**Analysis:**
- Thread usage highly unbalanced across instances → hotspot/imbalance issue
- Thread usage relatively balanced:
  - A thread > 80% AND TiKV CPU high → scale-out/up needed
  - A thread > 80% AND TiKV CPU low → increase that thread pool size

---

## Dedicated Cluster Disk Precheck

Dedicated clusters have separate metric UUIDs for application and infrastructure:

| UUID Type | Metrics Scope | Examples |
|-----------|--------------|---------|
| **Application UUID** | TiDB/TiKV/PD process metrics | `tidb_*`, `tikv_*`, `pd_*` |
| **Infrastructure UUID** | Node-level OS metrics | `node_*`, `kube_*`, `aws_ebs_csi_*` |

**Procedure:**
1. Parse application UUID from `tidb_*/tikv_*` metrics
2. Parse infrastructure UUID from `node_*/kube_*` metrics
3. If `node_disk_io_time_seconds_total` returns empty on the application UUID — this is the WRONG metrics source, not "disk metrics don't exist"
4. Only after confirming infra UUID: use Disk I/O Util, bandwidth, EBS IOPS, wait latency as evidence

---

## TiDB X/TiDB-X RCU Analysis

Applicable to Starter/Essential/Premium/BYOC clusters.

### RCU Cost Model

| Operation | RU Cost |
|-----------|---------|
| Read: 1 request | 0.475 RU |
| Read: 64 KiB payload | 1 RU |
| Write: 1 request | 2.55 RU |
| Write: 2 KiB payload | 1 RU |

### RCU Throttling Detection

| Product Line | Throttling Signal |
|-------------|-------------------|
| Premium/BYOC | `kv client request wait duration` P90 > 10ms |
| Starter/Essential | Available RU < 1000 |
| All TiDB X | Slow query log: `total time queued by RC` dominates total time |

### Common TiDB X Issues

| Issue | Signal | Resolution |
|-------|--------|------------|
| TiProxy gateway bottleneck (Essential) | TiProxy CPU high | Scale TiProxy horizontally |
| Cop worker cannot auto-scale (Premium/BYOC) | Concurrency Limiter Waiting Length high, TiKV does not expand cop worker | Adjust TiKV cop worker pool config |

---

## Data Source Call Templates

### TiDB Instance-level QPS
```
query: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
```

### Parse/Compile P99
```
query: histogram_quantile(0.99, sum(rate(tidb_session_parse_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
query: histogram_quantile(0.99, sum(rate(tidb_session_compile_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Plan Cache Hit Rate
```
query: sum(rate(tidb_server_plan_cache_total{tidb_cluster_id="{cluster_id}", type="hit"}[2m])) / sum(rate(tidb_server_plan_cache_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Connection Count
```
query: tidb_server_connections{tidb_cluster_id="{cluster_id}"}
```

### TopSQL CPU Attribution (TiKV instance-level)
```
query: topn(20, sum(topsql_cpu_time_ms{tidb_cluster_id="{cluster_id}", component="tikv", instance="{instance}"}) by (sql_digest), 1, "sum")
```

### Thread Pool CPU Usage
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, name)
```
