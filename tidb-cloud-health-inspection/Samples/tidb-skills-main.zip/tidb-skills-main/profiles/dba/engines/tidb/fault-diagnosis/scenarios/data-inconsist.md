# FAULT-DATA-INCONSIST (F10 Data Anomaly)

> Entry condition: Data inconsistency / Incorrect query results / Primary-secondary data mismatch
> Severity level: P0 (Data integrity)
> Data source: Clinic API + User-side SQL, all PromQL filtered with `tidb_cluster_id="{cluster_id}"`

**Important**: This is the most sensitive fault type. Unless evidence is sufficient, all conclusions default to LOW confidence.
Most diagnostics require user-executed SQL, marked as "Suggest user action".

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Specific anomaly description (which table, what data, expected vs actual)
3. Whether stale read / follower read is used
4. Time range (first discovery time, whether reproducible)

---

## Decision Tree

### Step 1: Distinguish True Data Inconsistency vs Query Behavior Differences

> Many "data inconsistencies" are actually query behavior differences, not true data corruption

```
Investigation directions:

1. Stale Read / Follower Read causing stale data reads:
   - Did the user set tidb_read_staleness{tidb_cluster_id="{cluster_id}"} or AS OF TIMESTAMP
   - Did the user use tidb_replica_read{tidb_cluster_id="{cluster_id}"} = "follower" / "closest-replicas"
   - → If yes: Check if resolved-ts is normal (see Step 3)

2. Inaccurate statistics causing wrong execution plans:
   - Query results themselves are correct, but a wrong index selection makes them "appear" incorrect
   - Example: Optimizer chose wrong index lookup, causing timeout and returning partial results

   Suggest user action:
     EXPLAIN ANALYZE SELECT ... ;   -- Compare against expected execution plan
     SHOW STATS_HEALTHY WHERE db_name='<db>' AND table_name='<table>';

   condition:
     stats_healthy < 80 → Statistics outdated, suggest ANALYZE TABLE
     Execution plan differs from expected → Not data inconsistency, redirect to execution plan issue

3. Transaction isolation level differences:
   - Under RC vs RR, the same query may return different results; this is expected behavior

   Suggest user action:
     SELECT @@tx_isolation;
     SELECT @@tidb_read_staleness{tidb_cluster_id="{cluster_id}"};
```

- Confirmed as query behavior difference → Not data inconsistency, output explanation → END
- Confirmed as true data inconsistency → Step 2

### Step 2: Index Consistency Check

> Index-row data inconsistency is the most common type of true data inconsistency

```
Suggest user action (Note: Large tables take a long time; recommended during off-peak hours):

  ADMIN CHECK TABLE <table_name>;
  ADMIN CHECK INDEX <table_name> <index_name>;

Result interpretation:
  Returns empty (no error) → Index data is consistent, go to Step 3
  Error "inconsistency" → Index data is inconsistent, go to Step 5 (Data Recovery)
```

- If the user cannot execute ADMIN CHECK (permissions, table too large, etc.):

```
Suggest user action (lightweight verification):

  -- Compare row counts between index scan vs full table scan
  SELECT COUNT(*) FROM <table> USE INDEX(PRIMARY);
  SELECT COUNT(*) FROM <table> USE INDEX(<index_name>);

  -- If row count difference is significant, highly suspect index inconsistency
```

### Step 3: Replica Consistency Check

> Check if data between leader and follower is consistent

```
metrics:
  resolved_ts_gap:  pd_regions_status{tidb_cluster_id="{cluster_id}", type="min-resolved-ts-gap"}
  pending_peer:     pd_regions_status{tidb_cluster_id="{cluster_id}", type="pending-peer-region-count"}
  missing_peer:     pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"}
  leader_changes:   sum(rate(tikv_raftstore_leader_changes{tidb_cluster_id="{cluster_id}"}[5m])) by (instance)

condition:
  resolved_ts_gap > 60s → resolved-ts advancement anomaly, stale read may read outdated data
  pending_peer > 0 persisting → Replica synchronization delay
  missing_peer > 0 persisting > 5min → Replica missing, data may be incomplete
```

Suggest user action (compare leader vs follower reads):

```
Suggest user action:

  -- Force leader read
  SET SESSION tidb_replica_read{tidb_cluster_id="{cluster_id}"} = 'leader';
  SELECT ... ;   -- User's query

  -- Force follower read
  SET SESSION tidb_replica_read{tidb_cluster_id="{cluster_id}"} = 'follower';
  SELECT ... ;   -- Same query

  -- Compare results: If different, replica data is inconsistent
```

- Leader / follower results consistent → Not a replica inconsistency issue, revisit Step 1
- Leader / follower results inconsistent → Replica inconsistency, go to Step 4 + Step 5

### Step 4: Known Bug Matching

> Match symptoms against known data inconsistency bugs

```
Bug 1: tikv#16706 — "default value not found"
  Symptoms:
    - TiKV log shows "default value not found" error
    - Leader read errors, but follower read is normal
    - Specific region's leader continuously errors
  Confirmation:
    - Loki search: {job="tikv"} |= "default value not found"
    - If only a specific TiKV instance errors → That instance's region replica data is corrupted
  Fix: → Step 5 (transfer leader + remove corrupted peer)
  Confidence: HIGH (if logs match)

Bug 2: Async Commit correctness issue under unstable network (UNCONFIRMED)
  Symptoms:
    - Transactions using async commit
    - Writes during network partition or high latency
    - Reading old values after writes
  Status: Unconfirmed known risk, no official fix
  Confirmation:
    - Check if async commit is enabled: tidb_enable_async_commit{tidb_cluster_id="{cluster_id}"} = ON
    - Check if transactions were committed during network anomaly
  Confidence: LOW (even if symptoms match)

Bug 3: Secondary Key min_commit_ts anomaly (UNCONFIRMED)
  Symptoms:
    - Secondary index query returns data inconsistent with primary key query
    - secondary key's min_commit_ts > pk.commit_ts
  Status: Unconfirmed
  Confidence: LOW
```

- Matched a known bug → Record bug number, go to Step 5
- No match → Collect more information for escalation

### Step 5: Data Recovery

> Choose recovery plan based on different types of data inconsistency

```
Plan A: Index inconsistency fix
  Suggest user action:
    -- Rebuild index (recommended during off-peak hours)
    ALTER TABLE <table_name> DROP INDEX <index_name>;
    ALTER TABLE <table_name> ADD INDEX <index_name>(<columns>);

    -- Verify after rebuild
    ADMIN CHECK INDEX <table_name> <index_name>;

Plan B: tikv#16706 — Leader replica data corruption
  Steps:
    1. Locate the corrupted region and TiKV instance
    2. Transfer leader to a healthy replica:
       pd-ctl operator add transfer-leader <region_id> <healthy_store_id>
    3. Confirm reads are normal after leader migration
    4. Remove the corrupted peer:
       pd-ctl operator add remove-peer <region_id> <corrupted_store_id>
    5. Wait for PD to automatically add replicas

  Note: This operation requires confirming at least one healthy replica exists; otherwise it may cause data loss
  Permission: Requires PD management access; Cloud environments may require internal operations

Plan C: Stale Read / Resolved-TS issue
  - If resolved_ts_gap is too large, check if TiKV has GC safe point advancement anomaly
  - Suggest temporarily disabling stale read:
    SET SESSION tidb_read_staleness{tidb_cluster_id="{cluster_id}"} = 0;
    SET SESSION tidb_replica_read{tidb_cluster_id="{cluster_id}"} = 'leader';
```

---

## Data Source Call Templates

### Region Health Status
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type="pending-peer-region-count"}
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"}
```

### Resolved-TS Gap
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type="min-resolved-ts-gap"}
```

### Leader Change Frequency
```
query: sum(rate(tikv_raftstore_leader_changes{tidb_cluster_id="{cluster_id}"}[5m])) by (instance)
```

### Raft Log Apply Latency
```
query: histogram_quantile(0.99, sum(rate(tikv_raftstore_apply_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, instance))
```

### TiKV Instance Uptime
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
```

### TiKV Error Logs (Loki)
```
loki: {job="tikv", tidb_cluster_id="{cluster_id}"} |= "default value not found"
loki: {job="tikv", tidb_cluster_id="{cluster_id}"} |= "inconsistency"
```

---

## Confidence Guide

| Scenario | Confidence | Description |
|----------|------------|-------------|
| ADMIN CHECK TABLE error | HIGH | Direct evidence |
| tikv#16706 log match | HIGH | Known bug + log confirmation |
| Leader/Follower read results differ | MEDIUM | Need to rule out time window factors |
| Async commit suspicion | LOW | UNCONFIRMED, only as an investigation direction |
| Secondary key ts anomaly | LOW | UNCONFIRMED |
| Statistics-caused "perceived inconsistency" | HIGH | But not actually data inconsistency |

**Default**: Always use LOW confidence when evidence is insufficient, to avoid misjudgment leading to inappropriate actions.
