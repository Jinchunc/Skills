# Serverless Audit Log Filter Rules

Base command: `ticloud serverless audit-log filter-rule`

Manage TiDB Cloud Serverless database audit logging filter rules

## Direct Subcommands

- `ticloud serverless audit-log filter-rule create` - Create an audit log filter rule
- `ticloud serverless audit-log filter-rule delete` - Delete an audit log filter rule (dangerous)
- `ticloud serverless audit-log filter-rule describe` - Describe an audit log filter rule
- `ticloud serverless audit-log filter-rule disable` - Disable an audit log filter rule (dangerous)
- `ticloud serverless audit-log filter-rule enable` - Enable an audit log filter rule (sensitive)
- `ticloud serverless audit-log filter-rule list` - List audit log filter rules (human-output)
- `ticloud serverless audit-log filter-rule template` - Show audit log filter rule templates
- `ticloud serverless audit-log filter-rule update` - Update an audit log filter rule (sensitive)

## Confirmation Required

- `ticloud serverless audit-log filter-rule delete`
- `ticloud serverless audit-log filter-rule disable`
