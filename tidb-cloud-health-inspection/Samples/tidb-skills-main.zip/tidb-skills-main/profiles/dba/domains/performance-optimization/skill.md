# Performance Optimization — Domain Methodology

> Engine-agnostic diagnostic methodology for database performance issues.
> This skill drives the investigation; engine skills provide execution details.

## Activation

User reports: slow queries, latency increase, QPS drop, resource anomaly, throughput ceiling, jitter, hotspot.

## Engine Detection and Provider Loading

Follow the canonical procedure in `INDEX.md#engine-detection-and-provider-loading` (engine detection 3-step, conditional engine skill loading, DISPATCH Layer 3 provider loading).

---

## Step 1: Symptom Confirmation

Before diagnosis, quantify the problem:

1. **What** — which metric is abnormal (latency, QPS, CPU, memory, I/O, disk, network)
2. **Scope** — single query, single node, entire cluster, specific component
3. **When** — onset time, duration, pattern (constant, periodic, spike)
4. **Impact** — user-facing? business impact severity? (P0-P3)
5. **Baseline** — what is normal? compare same time window in previous week

Output: confirmed symptom statement with metric, scope, time window, and severity.

## Step 2: Top-Down Decomposition

Decompose total response time into phases to locate the bottleneck layer:

```
Total Response Time (DB Time)
├── Parse / Compile time
├── Execution time
│   ├── Read path (point get, range scan, index lookup)
│   ├── Write path (prepare, commit, async write)
│   └── Wait time (lock wait, backoff, scheduling)
├── Network time (client ↔ DB, DB ↔ storage, DB ↔ coordinator)
└── Queue / scheduling time
```

**Method:** Query phase-level duration metrics → identify which phase dominates → drill into that phase.

**Percentage thresholds:**
- One phase > 60% of total DB Time → **single bottleneck**, follow that path directly
- Multiple phases each 20-40% → **compound issue**, address largest contributor first, then re-measure
- All phases roughly proportional → not a phase bottleneck; check concurrency, throughput limits, or external dependencies

**Decision logic:**
- Parse/compile dominates → SQL complexity or plan cache miss
- Read path dominates → index efficiency, scan volume, storage read latency
- Write path dominates → write conflict, storage write stall, replication lag
- Wait time dominates → lock contention, transaction conflict, resource throttling
- Network dominates → cross-zone latency, packet loss, connection pool exhaustion

→ Engine: provides phase-specific metrics and thresholds for this decomposition.

## Step 3: Bottleneck Classification

Based on decomposition, classify into one of these categories:

| Category | Signal | Investigation Direction |
|----------|--------|----------------------|
| **sql-level** | Single query slow, plan regression, full scan | SQL analysis framework (Step 6) |
| **resource-level** | CPU/memory/IO/disk/network anomaly | Resource-specific diagnosis path |
| **throughput-level** | QPS drop or ceiling despite available resources | Concurrency, lock, scheduling bottleneck |
| **transaction-level** | Lock wait, conflict rate, long transactions | Transaction and conflict analysis |
| **stability-level** | Jitter, cold start, periodic spikes | Temporal pattern analysis |

→ Engine: SKILL.md routing table maps each classification to engine-specific diagnostic files.

## Step 4: Investigation Patterns

Apply one or more patterns based on the bottleneck type:

| Pattern | When to Use | Method |
|---------|-------------|--------|
| **Timeline** | Onset-correlated issues | Overlay metric timelines to find trigger event |
| **Comparative** | Regression from baseline | Compare anomaly vs normal window, same metrics |
| **Top-N** | Resource or query dominance | Rank by consumption, focus on top contributors |
| **Multi-signal** | Ambiguous single metric | Correlate 2-3 related signals to confirm hypothesis |
| **Elimination** | Multiple plausible causes | Test and eliminate hypotheses one by one |

**Multi-signal correlation rule:** Never diagnose from a single metric. Always correlate with at least one related signal.

### 4.1 CPU Attribution Cross-Verification

When a database node is identified as a CPU hotspot or performance outlier, cross-verify with CPU attribution data before concluding:

1. **Query CPU attribution** — use the engine's CPU attribution tool for the specific instance + time window
2. **Check suspect SQL** — is the suspected SQL among the top CPU consumers?
3. **If NOT among top consumers** — the conclusion is WRONG. Use CPU attribution data to find the actual CPU consumer.
4. **Record evidence** — document the root-cause SQL's CPU percentage as evidence.

Do NOT rely on P99 latency or slow query logs alone for CPU attribution — they show latency, not CPU contribution.

→ Engine: provides the specific CPU attribution tool and query syntax.

### 4.2 "Slow vs Hot" Distinction

Critical principle when analyzing CPU-related issues in the storage or execution layer:

| Concept | Definition | Metric |
|---------|-----------|--------|
| **Slow** | Single request latency high | P99 latency |
| **Hot** | Total CPU consumption high | Total CPU time (sum of rate × duration) or CPU attribution tool |

**P99 high ≠ CPU hotspot.** A SQL with P99=10s running once contributes far less CPU than a SQL with P99=200ms running 100 times/second.

**Diagnostic rule:** Always use total CPU time (sum of rate × duration, or CPU attribution), never P99 latency, to determine CPU hotspot root cause. P99 tells you which requests are slow; hotspot root cause is determined by which SQL consumes the most total CPU time.

→ Engine: provides specific metrics and thresholds for slow-vs-hot comparison.

## Step 5: Metrics Query Methodology

When diagnosis requires metric evidence:

1. **Context** — confirm cluster ID, time window, observed symptom
2. **Resolution** — match query resolution to time window (short window = high resolution, long window = lower resolution)
3. **Layer** — query in layers: cluster overview → component → specific metric
4. **Correlate** — check related metrics for each finding (see multi-signal rule)
5. **Baseline** — compare anomaly window against same time in previous period; deviations > 2x are significant

→ Engine: provides specific metric names, query syntax, and normal ranges.
→ Provider: follow DISPATCH.md Layer 3 for metric retrieval (data API first, then product line doc if not already loaded).

## Step 6: SQL Analysis Framework

When bottleneck is sql-level:

### 6.1 Locate Problem SQL — Multi-Dimension Top-N

Rank candidate SQL across four dimensions; a query ranking high on multiple dimensions is the strongest suspect:

| Dimension | Metric | Why It Matters |
|-----------|--------|----------------|
| **Time impact** | execution_time × frequency | Total DB Time consumed — top contributor hurts everyone |
| **Peak latency** | max / P99 execution time | Worst user experience — even low-frequency outliers matter |
| **Frequency** | execution count per window | High-frequency moderate-slow often hurts more than rare-slow |
| **Resource consumption** | memory / disk I/O per execution | Memory-heavy queries risk OOM; I/O-heavy causes contention |

→ Engine: provides slow query log access and ranking queries.
→ Provider: use data source API (follow DISPATCH.md Layer 3) to retrieve slow query data for the target time window.

### 6.2 Execution Plan Analysis

Check items by priority:
1. Full table scan → missing index
2. Actual rows vs estimated rows divergence > 10x → stale statistics
3. High distributed query execution volume → large range scan, consider partitioning or index narrowing
4. Abnormal memory usage → join/sort spill to disk
5. High lookback volume → missing covering index

→ Engine: provides plan operators, statistics commands, hint syntax.

### 6.3 Root Cause Decision Tree

Follow this sequence — each node is checked and either confirmed or ruled out before moving to the next:

```
Statistics stale?
  └─ yes → rebuild statistics, re-check plan
  └─ no ↓
Missing / wrong index?
  └─ yes → add index or fix index choice
  └─ no ↓
Distributed query execution bottleneck?
  └─ yes → reduce scan range, push predicates closer to storage, adjust execution parallelism
  └─ no ↓
Lock contention?
  └─ yes → reduce transaction scope, adjust isolation level
  └─ no ↓
Large query memory pressure?
  └─ yes → limit result set, add pagination, optimize join
  └─ no ↓
Multi-version overhead? (excessive historical versions slowing reads)
  └─ yes → tune version cleanup policy, check long-running transactions
  └─ no ↓
Implicit type conversion?
  └─ yes → fix column/parameter type mismatch
  └─ no → no clear SQL-level root cause → check infrastructure layer
```

### 6.4 Batch Slow Query Analysis (4-Phase)

When multiple slow queries exist, do NOT analyze one at a time. Use this structured batch approach:

**Phase 1 — Harvest:**
- Pull multi-dimension Top-N across all four dimensions (6.1)
- Deduplicate by query digest (normalized fingerprint)
- Rank P0-P3 by combined severity:
  - **P0**: regression from known-good baseline (plan changed, new slow pattern)
  - **P1**: missing index / full scan on large table
  - **P2**: data volume growth exceeding previous patterns
  - **P3**: inherently complex query (acceptable if within SLA)

**Phase 2 — Pattern Detection:**
- Classify temporal distribution of each digest:
  - **Spike** — sudden onset, short burst (deployment? config change?)
  - **Steady** — consistently slow across the window (structural issue)
  - **Periodic** — recurring at intervals (scheduled job, maintenance window, statistics rebuild)
  - **Escalating** — gradually worsening over hours/days (data growth, version accumulation)
- Cross-digest correlation: if multiple digests spike simultaneously → systemic cause (not individual SQL)

**Phase 3 — Deep Dive:**
- For top 5 digests (by P-rank): run execution plan analysis (6.2) + root cause tree (6.3)
- Record per-digest: root cause, confidence, evidence

**Phase 4 — Report:**
- Summary: total digests analyzed, P0/P1/P2/P3 distribution
- P0 findings with root cause and recommended action
- Systemic observations (cross-digest patterns, infrastructure signals)
- Data gaps: what could not be determined and what additional data is needed

### 6.5 Execution Plan Comparison (4-Phase)

When a query was fast before and slow now, compare plans systematically:

**Phase 1 — Collect:**
- Gather execution plans from the baseline period (known-good)
- Gather execution plans from the current period (degraded)

**Phase 2 — Diff:**
- **Structural comparison:** access method changed? join order changed? join type changed? operator distribution changed?
- **Quantitative comparison:** query_time, scan volume, memory usage, distributed query execution metrics

**Phase 3 — Classify:**
- Plan changed → likely cause: statistics drift, index added/dropped, optimizer behavior change
- Plan unchanged → likely cause: data growth, multi-version overhead, infrastructure degradation

**Phase 4 — Report:**
- Regression factor (quantitative: e.g., "3.2x slower")
- Structural diff summary (what changed in the plan)
- Root cause + confidence level
- Recommended action and verification method

## Step 7: Remediation Strategy

After root cause is identified, select and apply the fix. This step transitions from diagnosis to action.

### 7.1 Fix Selection — Least Invasive First

Apply fixes in this order; stop at the first level that resolves the issue:

| Priority | Strategy | Invasiveness | Reversibility |
|----------|----------|-------------|---------------|
| 1 | **Refresh statistics** | None — maintenance operation | Fully reversible |
| 2 | **Add missing index** | Low — additive, no existing behavior changes | Drop index to revert |
| 3 | **Plan pinning / baseline** | Low — locks plan without code changes | Drop pinning to revert |
| 4 | **Optimizer hints** (per-query) | Medium — requires SQL change | Remove hint to revert |
| 5 | **Session/global variables** | Medium — affects workload patterns | Reset variable to revert |
| 6 | **Query rewrite** | High — changes SQL logic | Requires code rollback |
| 7 | **Schema change** | High — alters table structure, may require data migration | Requires migration to revert |
| 8 | **Configuration change** | High — affects entire cluster, not scoped to one query | Requires config rollback + restart |

→ Engine: provides the specific commands, hint syntax, variable names, and binding mechanisms for each strategy.
→ Engine: load tuning references from engine SKILL.md "Query Tuning References" section for detailed guidance per strategy.

### 7.2 Similar Case Search

Same procedure as fault-diagnosis — see `../fault-diagnosis/skill.md` §7.2 (match engine knowledge-base precedent by symptom / root cause / fix pattern before applying the fix).

### 7.3 Fix Verification

Same procedure as fault-diagnosis — see `../fault-diagnosis/skill.md` §7.3 (re-run the Step 5-6 diagnostic checks, require >20% improvement, otherwise revert or re-diagnose).

## Step 8: Synthesize

After diagnosis AND remediation:

1. **Root cause** — single sentence, specific and actionable
2. **Confidence** — HIGH (metric proof + reproduction) / MEDIUM (metric correlation) / LOW (inference only)
3. **Evidence chain** — list each metric/observation that supports the conclusion
4. **Fix applied** — what was done, which strategy level (7.1), link to relevant engine reference
5. **Verification result** — before/after comparison, quantified improvement
6. **Preventive recommendation** — how to avoid recurrence, labeled "recommended for user execution"

## Step 9: Dead-End Handling

When all investigation paths are exhausted without identifying root cause:

1. Summarize what was checked and ruled out
2. List remaining hypotheses with confidence levels
3. Suggest data collection for further investigation
4. Offer to pivot: "Should I check a different angle, or would you like to escalate?"

## Cross-Domain

If investigation points to a different domain:
- Performance issue caused by fault (OOM, node crash) → load fault-diagnosis domain
- Performance issue caused by schema problem → load sql-schema-management if available
- Resource exhaustion related to cost/capacity → inform user about resource-cost-manager domain

Load the other domain's methodology first: `Read domains/<other-domain>/skill.md`
