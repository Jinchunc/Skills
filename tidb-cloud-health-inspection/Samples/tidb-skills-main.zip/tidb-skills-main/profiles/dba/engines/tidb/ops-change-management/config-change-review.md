# PLAYBOOK: Configuration Change Review

> Structured review of TiDB/TiKV/PD configuration changes before execution.
> Core principle: Every config change is a potential incident — review before apply.

---

## When to Use

- User plans to change TiDB/TiKV/PD configuration
- Post-incident review: "What config changed before the issue?"
- Cluster inspection: audit current config against best practices
- Version upgrade: check deprecated/renamed parameters

## Prerequisites

1. **MODULE-CLUSTER-ID** completed (tier, version, topology)
2. Proposed change(s) — parameter name, current value, target value
3. Reason for change

---

## Phase 1: Change Classification

### Step 1.1: Identify Component and Scope

| Component | Config Source | Hot Reload |
|-----------|-------------|------------|
| TiDB | `SET GLOBAL` / config file | Most session/global vars: YES |
| TiKV | tikv.toml / PD config API | Some: YES (via pd-ctl), some: requires restart |
| PD | pd.toml / pd-ctl config | Most: YES (via pd-ctl) |
| TiFlash | tiflash.toml | Most: requires restart |

### Step 1.2: Risk Tier

| Tier | Criteria | Examples | Review Depth |
|------|----------|---------|-------------|
| **T1 — Critical** | Affects data safety, availability, or cluster stability | `raft-store.*`, `gc-life-time`, `placement-rules`, replication config | Full review + staging test recommended |
| **T2 — High** | Affects performance significantly | `tidb_mem_quota_query`, `tidb_distsql_scan_concurrency`, TiKV thread pool sizes, compaction config | Full review |
| **T3 — Medium** | Affects behavior but limited blast radius | `tidb_slow_log_threshold`, log levels, backoff config | Quick review |
| **T4 — Low** | Cosmetic or monitoring only | Display settings, metric collection interval | Ack only |

---

## Phase 2: Compatibility Check

### Step 2.1: Version Compatibility

```
Check:
1. Parameter exists in current TiDB version ({version})?
2. Parameter renamed or deprecated?
3. Default value changed between versions?
4. New constraints added (min/max range)?
```

**Common version pitfalls:**

| Version | Breaking Change |
|---------|----------------|
| v6.5+ | `tikv.raftstore.hibernate-regions` default changed to true |
| v7.0+ | `tidb_enable_mutation_checker` default changed |
| v7.1+ | Resource Control GA — new `tidb_enable_resource_control` |
| v7.5+ | TiKV `region-split-size` default 96MB→256MB (affects hotspot) |
| v8.0+ | Multiple deprecated parameters removed |

### Step 2.2: Product Line Constraints

| Parameter | Dedicated | Premium | Starter/Essential |
|-----------|-----------|---------|------------------|
| TiKV thread pool sizes | User adjustable | Managed | Managed |
| PD scheduling limits | User adjustable | Managed | Managed |
| Memory quotas | User adjustable | Bounded by RCU | Bounded by RCU |
| GC life time | User adjustable | User adjustable | User adjustable |

> For managed parameters on Premium/Starter: recommend user to submit a support ticket.

---

## Phase 3: Impact Analysis

### Step 3.1: Performance Impact Assessment

For each proposed change, evaluate:

| Dimension | Question | Risk Signal |
|-----------|----------|-------------|
| **Latency** | Will this increase query latency? | Memory reduction → more spills; concurrency reduction → slower scans |
| **Throughput** | Will this limit QPS? | Thread pool reduction; flow control tightening |
| **Resource** | Will this increase CPU/memory/IO? | Concurrency increase; cache size increase |
| **Stability** | Could this cause OOM/Write Stall? | Memory increase without bound; compaction config change |

### Step 3.2: Interaction Effects

Config parameters don't exist in isolation. Check for known interactions:

| Change | Interacts With | Risk |
|--------|---------------|------|
| Increase `tidb_distsql_scan_concurrency` | `tidb_mem_quota_query` | Higher concurrency × memory per task → OOM |
| Decrease `tikv.raftstore.region-split-size` | PD scheduling load | More regions → higher PD pressure |
| Increase `gc-life-time` | Disk space, MVCC scan cost | Old versions accumulate → slower reads |
| Decrease `tidb_mem_quota_query` | Complex queries | Previously working queries may fail with OOM error |
| Enable `tidb_enable_resource_control` | All workloads | Adds overhead; misconfigured RU can throttle production |

### Step 3.3: Rollback Assessment

| Question | Answer |
|----------|--------|
| Can this be reverted hot? | YES: `SET GLOBAL` / pd-ctl → safe. NO: requires restart → plan maintenance window |
| Is the rollback instant? | Some changes (like compaction config) take time to fully revert even after config reset |
| Could data state change irreversibly? | GC config: once old versions are collected, they're gone. Compaction: once triggered, runs to completion |

---

## Phase 4: Review Checklist

### T1/T2 Changes — Full Review

```
□ 1. Parameter name verified in current version docs
□ 2. Current value confirmed (not assuming default)
□ 3. Target value within documented range
□ 4. No deprecated/renamed parameter issues
□ 5. Product line allows this change
□ 6. Performance impact assessed (latency/throughput/resource)
□ 7. Interaction effects checked
□ 8. Rollback plan documented
□ 9. Monitoring plan: which metrics to watch after change
□ 10. Change window: off-peak recommended for T1
```

### T3/T4 Changes — Quick Review

```
□ 1. Parameter exists in current version
□ 2. Value within valid range
□ 3. Rollback possible
```

---

## Phase 5: Monitoring After Change

### What to Watch (first 30 minutes)

> Full PromQL for each metric → [promql-templates.md](../references/promql-templates.md)

| Metric | promql-templates ref | Why | Alert Threshold |
|--------|------------------|-----|-----------------|
| `tidb_server_query_total` | #1.1 Total QPS | QPS drop = something broke | > 20% drop from baseline |
| `tidb_server_handle_query_duration_seconds` | #1.2 Query P99 | Latency regression | P99 > 2x baseline |
| `tikv_engine_write_stall` | #3.6 Write Stall | Write stall from TiKV config change | Any increase from 0 |
| `tikv_raftstore_region_count` | #3.8 Region Count | Region count explosion from split config | > 20% increase in 5 min |
| `process_resident_memory_bytes` | #5.4/#5.5 Memory | Memory impact | Approaching OOM threshold |
| `tikv_grpc_msg_duration_seconds` | #3.1 gRPC Get | TiKV response time | P99 > 2x baseline |

### Rollback Trigger

```
IF within 15 minutes of change:
  - P99 latency > 3x baseline, OR
  - QPS drop > 30%, OR
  - Any write_stall events, OR
  - Error rate increase > 5%
THEN:
  → Rollback immediately (revert config)
  → Collect metrics from the change window for post-analysis
```

---

## Report Format

```
## Configuration Change Review
Cluster: {cluster_id} | Version: {version} | Tier: {tier}

### Proposed Change
| Parameter | Component | Current | Target | Reason |
|-----------|-----------|---------|--------|--------|

### Risk Assessment
- Risk Tier: T{1-4}
- Hot Reload: YES/NO
- Rollback: {instant/delayed/irreversible}

### Compatibility: PASS/FAIL
- {any version or product line issues}

### Impact Analysis
- Latency impact: {none/increase/decrease} — {reason}
- Throughput impact: {none/increase/decrease} — {reason}
- Resource impact: {none/increase/decrease} — {reason}
- Interaction risks: {if any}

### Recommendation
- {APPROVE / APPROVE WITH CONDITIONS / REJECT}
- {conditions or reasons}

### Monitoring Plan
- Watch metrics: {list}
- Rollback trigger: {conditions}
- Change window: {recommended time}
```

---

## Relationship to Other Components

| Component | Relationship |
|-----------|-------------|
| S4 Design Review | Config change review is a specialized form of design review |
| S5 Inspection | Audit current config against best practices |
| MODULE-TIKV | TiKV config changes route here for impact analysis |
| MODULE-PD | PD config changes (scheduling limits, etc.) |
| PLAYBOOK-HOTSPOT | Hotspot remediation often involves config changes — reviewed here first |
