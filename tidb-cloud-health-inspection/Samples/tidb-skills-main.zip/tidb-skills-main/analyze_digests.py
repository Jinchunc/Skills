#!/usr/bin/env python3
"""Analyze top 10 slow query digests and generate report."""
import json
import sys
import re

sys.path.insert(0, '/Users/meiking/workspace/github/meiking/tidb-skills/profiles/dba/providers/tidb-cloud/ops/scripts')
from clinic_api import ClinicAPI

api = ClinicAPI(env_file='/Users/meiking/workspace/github/meiking/tidb-skills/profiles/dba/providers/tidb-cloud/ops/.env')

records = [
    {"idx":1, "clusters":["10989049060142230334","10754652599988043412"], "cluster_names":["Cluster-1 (10989049060142230334)","Cluster-3 (10754652599988043412)"], "digest":"f3b6a1bfb901c0eab887f8260b0bdaa548747a9518e63db327114f03d33aaff0", "未现天数":0,"出现天数":16,"风险分":36.3, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_count, top_by_request_count, top_by_total_latency", "首发日期":"2026-09-23","最近发生":"2026-10-15", "高峰窗口":"11-13","业务库/表":"dh_account_basic", "定级原因":"P1中量警示 risk_score=36.3 | [qt_max=2s, cnt=1406, cpu=1594s, share=0%]"},
    {"idx":2, "clusters":["10989049060142230334","10518506906906971664","10754652599988043412"], "cluster_names":["Cluster-1 (10989049060142230334)","Cluster-2 (10518506906906971664)","Cluster-3 (10754652599988043412)"], "digest":"c8daaa2100b6654709334cc2e9c44fcc4bb3be569b3b57a508be1a749449d97e", "未现天数":0,"出现天数":11,"风险分":57.8, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_count, top_by_total_latency", "首发日期":"2026-09-26","最近发生":"2026-10-15", "高峰窗口":"11-13","业务库/表":"dh_account_basic", "定级原因":"P1中量警示 risk_score=41.8 | [qt_max=3s, cnt=3761, cpu=4896s, share=0%]"},
    {"idx":3, "clusters":["10518506906906971664","10754652599988043412"], "cluster_names":["Cluster-2 (10518506906906971664)","Cluster-3 (10754652599988043412)"], "digest":"42b4e823ab4f9bc13582913caf912cb1b2cbd5bfdad1ba23cc26fd31aa1fdc63", "未现天数":0,"出现天数":8,"风险分":61, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_request_count", "首发日期":"2026-06-07","最近发生":"2026-10-15", "高峰窗口":"","业务库/表":"dh_account_ext_financeinfo", "定级原因":"P1中量警示 risk_score=49.0 | [qt_max=30s, cnt=583, cpu=1148s, share=0%]"},
    {"idx":4, "clusters":["10989049060142230334","10518506906906971664","10754652599988043412"], "cluster_names":["Cluster-1 (10989049060142230334)","Cluster-2 (10518506906906971664)","Cluster-3 (10754652599988043412)"], "digest":"308443eba503e559cf3f6f290cd7822b770dba06d40626a50cee75be9f8e0101", "未现天数":0,"出现天数":7,"风险分":65, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_count, top_by_process_keys, top_by_request_count, top_by_sum_ru, top_by_total_keys, top_by_total_latency", "首发日期":"2026-10-07","最近发生":"2026-10-15", "高峰窗口":"11-13","业务库/表":"dh_user_day_report", "定级原因":"P1中量警示 risk_score=49.0 | [qt_max=6s, cnt=8640, cpu=13952s, share=0%]"},
    {"idx":5, "clusters":["10754652599988043412"], "cluster_names":["Cluster-3 (10754652599988043412)"], "digest":"6febc93c880042d5b1e5945b9c74ece9d6f0af71f0f6cdf8a28a082635204fb7", "未现天数":0,"出现天数":3,"风险分":39.7, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_request_count", "首发日期":"2026-09-27","最近发生":"2026-10-15", "高峰窗口":"11-13","业务库/表":"dh_active_receive_details", "定级原因":"P1中量警示 risk_score=35.2 | [qt_max=5s, cnt=395, cpu=519s, share=0%]"},
    {"idx":6, "clusters":["10518506906906971664"], "cluster_names":["Cluster-2 (10518506906906971664)"], "digest":"840e8311a58da8697028d69e039f3cc65fc280b32d50239fbd29d414d3e0af4e", "未现天数":0,"出现天数":2,"风险分":46.6, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_total_latency", "首发日期":"2026-10-14","最近发生":"2026-10-15", "高峰窗口":"","业务库/表":"dh_promote_myteam_direct", "定级原因":"P1中量警示 risk_score=43.8 | [qt_max=7s, cnt=1453, cpu=3205s, share=0%]"},
    {"idx":7, "clusters":["10754652599988043412"], "cluster_names":["Cluster-3 (10754652599988043412)"], "digest":"643e735ca652c921a2425c3db11f15e4ccc5925d07d6d80131748e6943b514c7", "未现天数":0,"出现天数":1,"风险分":47.2, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_request_count", "首发日期":"2026-10-15","最近发生":"2026-10-15", "高峰窗口":"","业务库/表":"dh_user_day_report", "定级原因":"P1中量警示 risk_score=47.2 | [qt_max=13s, cnt=1243, cpu=3022s, share=0%]"},
    {"idx":8, "clusters":["10989049060142230334","10754652599988043412"], "cluster_names":["Cluster-1 (10989049060142230334)","Cluster-3 (10754652599988043412)"], "digest":"6204264b720a407280e88a395f0f3301c1a382716bd322534228d103a227d896", "未现天数":1,"出现天数":7,"风险分":49.8, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_request_count", "首发日期":"2026-07-25","最近发生":"2026-10-14", "高峰窗口":"11-13","业务库/表":"dh_promote_myteam_others", "定级原因":"P1中量警示 risk_score=37.8 | [qt_max=25s, cnt=13, cpu=204s, share=0%]"},
    {"idx":9, "clusters":["10989049060142230334"], "cluster_names":["Cluster-1 (10989049060142230334)"], "digest":"bb15bc7c2c517853be0b670476d1b29300a46fb340d35d4fe4075913a6b56805", "未现天数":1,"出现天数":4,"风险分":37.2, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_request_count", "首发日期":"2026-10-07","最近发生":"2026-10-14", "高峰窗口":"11-13","业务库/表":"dh_report_bet_summary", "定级原因":"P1中量警示 risk_score=37.2 | [qt_max=9s, cnt=204, cpu=429s, share=0%]"},
    {"idx":10, "clusters":["10989049060142230334","10518506906906971664","10754652599988043412"], "cluster_names":["Cluster-1 (10989049060142230334)","Cluster-2 (10518506906906971664)","Cluster-3 (10754652599988043412)"], "digest":"f9e67b5149a9b0898f6e12eb06cc43cdadc4828acfbcc2636b2996b8763dccce", "未现天数":1,"出现天数":3,"风险分":52.6, "当前等级":"P1", "规则":"slowlog_top_digest:top_by_process_keys, top_by_sum_ru, top_by_total_keys", "首发日期":"2026-10-12","最近发生":"2026-10-14", "高峰窗口":"","业务库/表":"dh_pay_order_success", "定级原因":"P1中量警示 risk_score=40.1 | [qt_max=12s, cnt=262, cpu=562s, share=0%]"},
]

def query_digest(cluster_id, digest, date_str):
    date_compact = date_str.replace("-", "")
    sql = f"""SELECT query, plan, query_time, mem_max, process_keys, total_keys,
       cop_time, wait_time, index_names, db, rocksdb_block_read_byte,
       rocksdb_block_cache_hit_count, rocksdb_block_read_count,
       get_snapshot_time, tikv_cpu_time, tidb_cpu_time, num_cop_tasks
FROM clinic_data_proxy.slow_query_logs
WHERE date = '{date_compact}' AND digest = '{digest}'
ORDER BY query_time DESC
LIMIT 3"""
    try:
        result = api.query_sql(cluster_id, sql, timeout=120)
        if 'error' in result:
            print(f"  Error on {cluster_id}: {result['error'][:200]}", file=sys.stderr)
            return []
        rows = result.get('rows', [])
        cols = result.get('columns', [])
        return [dict(zip(cols, row)) for row in rows]
    except Exception as e:
        print(f"  Exception on {cluster_id}: {e}", file=sys.stderr)
        return []

def query_digest_count(cluster_id, digest, date_str):
    date_compact = date_str.replace("-", "")
    sql = f"""SELECT COUNT(*) as cnt
FROM clinic_data_proxy.slow_query_logs
WHERE date = '{date_compact}' AND digest = '{digest}'"""
    try:
        result = api.query_sql(cluster_id, sql, timeout=120)
        if 'error' in result:
            return 0
        rows = result.get('rows', [])
        if rows:
            return int(rows[0][0])
        return 0
    except:
        return 0

def fmt_dur(s):
    try:
        v = float(s)
        if v >= 3600: return f"{v/3600:.1f}h"
        if v >= 60: return f"{v/60:.1f}min"
        if v >= 1: return f"{v:.1f}s"
        if v >= 0.001: return f"{v*1000:.1f}ms"
        return f"{v*1e6:.0f}µs"
    except: return "N/A"

def fmt_num(n):
    try: return f"{int(float(n)):,}"
    except: return "N/A"

def fmt_bytes(b):
    try:
        v = float(b)
        if v >= 1024**3: return f"{v/1024**3:.2f} GB"
        if v >= 1024**2: return f"{v/1024**2:.1f} MB"
        if v >= 1024: return f"{v/1024:.1f} KB"
        return f"{v:.0f} B"
    except: return "N/A"

def analyze_exec_plan(rows):
    """Analyze execution plan from slow query rows."""
    if not rows:
        return [], "N/A"

    plan_text = str(rows[0].get('plan', '') or '')
    issues = []
    operators = []

    if 'TableFullScan' in plan_text:
        issues.append("存在全表扫描 (TableFullScan)")
        operators.append("TableFullScan")
    if 'IndexRangeScan' in plan_text:
        m = re.search(r'index:(\w+)\(([^)]+)\)', plan_text)
        if m:
            operators.append(f"IndexRangeScan({m.group(1)})")
        else:
            operators.append("IndexRangeScan")
    if 'IndexLookUp' in plan_text:
        operators.append("IndexLookUp")
    if 'IndexHashJoin' in plan_text:
        operators.append("IndexHashJoin")
    if 'HashAgg' in plan_text:
        operators.append("HashAgg")
    if 'StreamAgg' in plan_text:
        operators.append("StreamAgg")
    if 'Batch_Point_Get' in plan_text:
        operators.append("Batch_Point_Get")
    if 'Point_Get' in plan_text:
        operators.append("Point_Get")
    if 'TableReader' in plan_text:
        operators.append("TableReader")

    # Analyze timing from execution info
    for row in rows:
        plan_str = str(row.get('plan', '') or '')

        # Check wait_time
        wt = row.get('wait_time')
        if wt:
            try:
                if float(wt) > 1.0:
                    issues.append(f"TiKV wait_time 过长 ({fmt_dur(wt)})")
            except: pass

        # Check get_snapshot_time
        gs = row.get('get_snapshot_time')
        if gs:
            try:
                if float(gs) > 0.5:
                    issues.append(f"get_snapshot_time 异常 ({fmt_dur(gs)})，可能存在 scheduler 阻塞")
            except: pass

        # Check total_keys vs process_keys ratio
        tk = row.get('total_keys')
        pk = row.get('process_keys')
        if tk and pk:
            try:
                tk_f = float(tk)
                pk_f = float(pk)
                if tk_f > 100000 and pk_f / tk_f < 0.1:
                    issues.append(f"过滤比高 (process/total={pk_f/tk_f:.1%})，索引选择性不足")
                if tk_f > 1000000:
                    issues.append(f"扫描 keys 过多 ({fmt_num(tk)})")
            except: pass

        # Check rocksdb read
        rb = row.get('rocksdb_block_read_byte')
        if rb:
            try:
                if float(rb) > 100 * 1024 * 1024:
                    issues.append(f"磁盘读取量大 ({fmt_bytes(rb)})")
            except: pass

        # Check cop_time
        ct = row.get('cop_time')
        if ct:
            try:
                if float(ct) > 5.0:
                    issues.append(f"cop_time 高 ({fmt_dur(ct)})，TiKV 计算开销大")
            except: pass

    if not issues:
        issues.append("执行计划未发现明显异常，建议结合监控进一步分析")

    plan_summary = " → ".join(operators) if operators else "N/A"
    return issues, plan_summary

# Main
print("Querying slow query logs...", file=sys.stderr)

out = []
out.append("# 2026-10-16 提案\n")
out.append("> 数据来源：SAAS 集群进度跟进表 - 未处理视图（状态=新发现）")
out.append("> 排序：未现天数正序 / 出现天数倒序 / 风险分数倒序，取前 10 条\n")
out.append("---\n")

for rec in records:
    print(f"\nDigest {rec['idx']}: {rec['digest'][:16]}...", file=sys.stderr)

    out.append(f"\n## Digest {rec['idx']}: {rec['digest']}\n")
    out.append(f"**等级**: {rec['当前等级']} | **风险分**: {rec['风险分']} | **出现天数**: {rec['出现天数']} | **未现天数**: {rec['未现天数']}")
    out.append(f"**业务库/表**: {rec['业务库/表']} | **高峰窗口**: {rec['高峰窗口'] or 'N/A'}")
    out.append(f"**定级原因**: {rec['定级原因']}")
    out.append(f"**触发规则**: {rec['规则']}")
    out.append(f"**首发日期**: {rec['首发日期']} | **最近发生**: {rec['最近发生']}\n")

    out.append("### 各集群统计\n")

    all_rows = {}
    cluster_summary = []

    for i, cid in enumerate(rec['clusters']):
        cname = rec['cluster_names'][i]
        date = rec['最近发生']

        rows = query_digest(cid, rec['digest'], date)
        cnt = query_digest_count(cid, rec['digest'], date)
        all_rows[cid] = rows

        if rows:
            max_lat = max(float(r.get('query_time', 0) or 0) for r in rows)
            avg_lat = sum(float(r.get('query_time', 0) or 0) for r in rows) / len(rows)
            total_dur = sum(float(r.get('query_time', 0) or 0) for r in rows)
            cluster_summary.append({
                'name': cname, 'id': cid,
                'cnt': cnt, 'max_lat': max_lat, 'avg_lat': avg_lat, 'total_dur': total_dur,
            })
        else:
            cluster_summary.append({
                'name': cname, 'id': cid,
                'cnt': cnt, 'max_lat': 0, 'avg_lat': 0, 'total_dur': 0,
            })

    # Summary line
    total_cnt = sum(s['cnt'] for s in cluster_summary)
    max_lat_all = max((s['max_lat'] for s in cluster_summary), default=0)
    total_dur_all = sum(s['total_dur'] for s in cluster_summary)
    out.append(f"慢且高频 最慢{fmt_dur(max_lat_all)}, {fmt_num(total_cnt)}次 | [qt_max={fmt_dur(max_lat_all)}, cnt={fmt_num(total_cnt)}, cpu={fmt_dur(total_dur_all)}]\n")

    out.append("| 集群 | 出现次数 | Avg Latency | Max Latency | Total Duration |")
    out.append("|-|-|-|-|-|")
    for s in cluster_summary:
        out.append(f"| {s['name']} | {fmt_num(s['cnt'])} | {fmt_dur(s['avg_lat'])} | {fmt_dur(s['max_lat'])} | {fmt_dur(s['total_dur'])} |")
    out.append("")

    # Sample SQL
    out.append("\n### 原始 SQL（样本）\n")
    sample_query = None
    for cid, rows in all_rows.items():
        for r in rows:
            if r.get('query'):
                sample_query = r['query']
                break
        if sample_query:
            break

    if sample_query:
        q_display = sample_query[:3000] + "\n..." if len(sample_query) > 3000 else sample_query
        out.append(f"```sql\n{q_display}\n```\n")
    else:
        out.append("*无法获取 SQL 样本*\n")

    # Execution plan analysis
    all_rows_flat = []
    for rows in all_rows.values():
        all_rows_flat.extend(rows)

    if all_rows_flat:
        out.append("### 执行计划分析\n")
        issues, plan_summary = analyze_exec_plan(all_rows_flat)

        out.append(f"**算子链路**: {plan_summary}")

        # Index info
        idx_names = set()
        db_names = set()
        for r in all_rows_flat:
            if r.get('index_names'):
                idx_names.add(str(r['index_names']))
            if r.get('db'):
                db_names.add(str(r['db']))
        if db_names:
            out.append(f"**数据库**: {', '.join(db_names)}")
        if idx_names:
            out.append(f"**使用索引**: {', '.join(idx_names)}")

        out.append("\n**执行计划特征**:")
        for issue in issues:
            out.append(f"- {issue}")
        out.append("")

    # Root cause
    out.append("\n#### 根因判断\n")
    root_causes = []

    if all_rows_flat:
        plan_str = str(all_rows_flat[0].get('plan', '') or '')
        if 'TableFullScan' in plan_str:
            root_causes.append("全表扫描导致大量无效数据读取，是主要性能瓶颈")

        total_keys_all = sum(float(r.get('total_keys', 0) or 0) for r in all_rows_flat)
        total_proc_keys = sum(float(r.get('process_keys', 0) or 0) for r in all_rows_flat)
        if total_keys_all > 100000:
            root_causes.append(f"扫描数据量大 (total_keys={fmt_num(total_keys_all)})")
        if total_keys_all > 0 and total_proc_keys > 0 and total_proc_keys / total_keys_all < 0.1:
            root_causes.append(f"过滤比高 (process/total={total_proc_keys/total_keys_all:.1%})，索引选择性不足")

        max_qt = max(float(r.get('query_time', 0) or 0) for r in all_rows_flat)
        if max_qt > 10:
            root_causes.append(f"单次执行最慢 {fmt_dur(max_qt)}，存在严重性能问题")

        # Check if compile_time is high
        for r in all_rows_flat:
            plan_s = str(r.get('plan', '') or '')
            if 'compile' in plan_s.lower() or 'optimize' in plan_s.lower():
                pass  # hard to extract from this format

    if not root_causes:
        # Use the info from the record
        qt_match = re.search(r'qt_max=(\d+)s', rec['定级原因'])
        cnt_match = re.search(r'cnt=(\d+)', rec['定级原因'])
        cpu_match = re.search(r'cpu=(\d+)s', rec['定级原因'])
        if qt_match:
            root_causes.append(f"最慢执行时间 {qt_match.group(1)}s")
        if cnt_match and int(cnt_match.group(1)) > 1000:
            root_causes.append(f"高频执行 {cnt_match.group(1)} 次/天")
        if cpu_match and int(cpu_match.group(1)) > 1000:
            root_causes.append(f"CPU 消耗 {cpu_match.group(1)}s")
        root_causes.append("需结合执行计划详情和集群监控进一步分析根因")

    for rc in root_causes:
        out.append(f"- {rc}")

    # Optimization
    out.append("\n#### 优化建议\n")
    opts = []
    if all_rows_flat:
        plan_str = str(all_rows_flat[0].get('plan', '') or '')
        if 'TableFullScan' in plan_str:
            opts.append("添加合适的索引避免全表扫描")
        if any('wait_time' in str(r.get('plan', '')) for r in all_rows_flat):
            opts.append("提单检查 TiKV 节点在异常时间段的负载情况")

    if not opts:
        opts.append("建议结合执行计划详情和集群监控进一步分析根因")
        opts.append("可考虑在高峰时段增加资源配额或优化查询调度")

    for o in opts:
        out.append(f"- {o}")

    out.append("\n---\n")

report = "\n".join(out)
with open("/Users/meiking/workspace/github/meiking/tidb-skills/2026-10-16-提案.md", "w") as f:
    f.write(report)

print(f"\nReport generated: 2026-10-16-提案.md ({len(report)} bytes)", file=sys.stderr)
