# MODULE-SQL: SQL Diagnosis

> Source: A3 analyze-slow-query merged + A1 Query Tuning enhancement
> Purpose: Locate problem SQL, analyze execution plans, determine SQL-level root cause

---

## Safety Red Lines (Especially Emphasized in This Module)

- All SQL that needs to query TiDB system tables **must be generated and output to the user for offline execution, with results returned by the user**
- Do not directly execute any operations that modify database state
- DDL suggestions (CREATE INDEX, ANALYZE TABLE, SQL Binding) must be labeled "recommended for user execution"

---

## Sub-modules

### SQL_IDENTIFY: Locate Problem SQL

```
Step 1: Query Top N Slow Queries
  Data source: slowlog SQL query
  SQL:
    SELECT
      digest,
      digest_text,
      COUNT(*) AS exec_count,
      MAX(query_time) AS max_query_time,
      AVG(query_time) AS avg_query_time,
      MAX(mem_max) AS max_mem,
      MAX(disk_max) AS max_disk,
      MAX(total_keys) AS max_total_keys,
      MAX(process_keys) AS max_process_keys
    FROM slowlogs
    WHERE date = '{date}'
      AND time BETWEEN {start_ts} AND {end_ts}
    GROUP BY digest, digest_text
    ORDER BY max_query_time DESC
    LIMIT 10

Step 2: If user specified a particular SQL
  Match by digest or SQL text, retrieve slow query records for that SQL

Step 3: Output
  - target_digests: List of SQL digests to analyze
  - Summary statistics for each digest
```

### SQL_PLAN_ANALYSIS: Execution Plan Analysis

```
Step 1: Get Execution Plan
  Data source: slowlog SQL query
  SQL:
    SELECT
      digest,
      decoded_plan,
      query_time,
      total_keys,
      process_keys,
      mem_max,
      disk_max,
      backoff_types,
      cop_proc_avg,
      cop_wait_avg
    FROM slowlogs
    WHERE digest = '{target_digest}'
      AND date = '{date}'
      AND time BETWEEN {start_ts} AND {end_ts}
    ORDER BY query_time DESC
    LIMIT 5

Step 2: Analyze Execution Plan (decoded_plan)
  Check items (by priority):
    a. TableFullScan / IndexFullScan -> Full table scan (missing index)
    b. actRows vs estRows deviation > 10x -> Stale statistics
    c. Very high cop_task count -> Large range scan
    d. Abnormal memory usage -> HashJoin/Sort spill
    e. IndexLookUp with high lookback volume -> Missing covering index
```

### SQL_ROOT_CAUSE: Root Cause Determination (Decision Tree)

```
Node 1: actRows vs estRows deviation > 10x?
  YES -> Stale statistics
    -> Generate diagnostic SQL: SHOW STATS_HEALTHY WHERE Table_name = '{table}' (for user execution)
    -> Suggestion: ANALYZE TABLE {table} (for user execution)
    -> confidence: HIGH
  NO -> Node 2

Node 2: TableFullScan exists AND process_keys > 10000?
  YES -> Missing index
    -> Analyze WHERE/JOIN conditions, suggest index columns
    -> Index design principles:
      - Equality condition columns first
      - Sort columns next
      - Consider covering index to reduce table lookback
      - Pay attention to composite index column order (higher selectivity first)
    -> confidence: HIGH
  NO -> Node 3

Node 3: cop_proc_avg > 100ms or cop_wait_avg > 50ms?
  YES -> Coprocessor bottleneck
    -> cop_proc high: Single TiKV processing slow -> Delegate to MODULE-TIKV (read subtree)
    -> cop_wait high: TiKV coprocessor thread pool queuing -> Delegate to MODULE-TIKV R2A_COPR_THREADS
    -> confidence: MEDIUM
  NO -> Node 4

Node 4: backoff_types contains txnLock / txnLockFast?
  YES -> Lock contention
    -> Generate diagnostic SQL (for user execution):
      SELECT * FROM information_schema.DATA_LOCK_WAITS LIMIT 20;
      SELECT * FROM information_schema.DEADLOCKS LIMIT 20;
    -> confidence: HIGH
  NO -> Node 5

Node 5: mem_max > 1GB or disk_max > 0?
  YES -> Large query memory overflow
    -> Check if SQL has unnecessary large JOINs / sorts
    -> Suggestion: Optimize SQL or increase tidb_mem_quota_query{tidb_cluster_id="{cluster_id}"}
    -> confidence: MEDIUM
  NO -> Node 6

Node 6: total_keys >> process_keys (ratio > 10x)?
  YES -> Excessive MVCC versions
    -> Many old versions not cleaned up by GC
    -> Delegate to MODULE-TIKV R6_GC
    -> confidence: MEDIUM
  NO -> Node 7

Node 7: Implicit type conversion check
  -> Generate diagnostic SQL (for user execution):
    EXPLAIN ANALYZE {original_sql}
  -> Check if execution plan has cast / convert causing index invalidation
  -> confidence: LOW (requires user to return EXPLAIN result)

Node 8: None of the above matched
  -> No clear root cause found at SQL level
  -> Suggestions:
    1. Check infrastructure layer (MODULE-DBTIME)
    2. Temporary mitigation: SQL Binding to lock a good execution plan
       -> Generate: CREATE GLOBAL BINDING FOR {sql} USING {good_plan} (for user execution)
  -> confidence: LOW
```

---

## Remediation — Tuning References

After identifying root cause from the decision tree above, load the relevant tuning reference for fix implementation:

| Root Cause (from tree above) | Tuning Reference | Fix Strategy |
|------------------------------|-----------------|--------------|
| Node 1: Stale statistics | [../references/stats-management.md](../references/stats-management.md) | ANALYZE TABLE, auto-analyze tuning |
| Node 2: Missing/wrong index | [../references/sql-optimization.md](../references/sql-optimization.md) | Index hints, composite index design |
| Node 2: Plan regression | [../references/optimizer-controls.md](../references/optimizer-controls.md) | Optimizer hints to force better plan |
| Node 2: Plan regression | [../references/session-variables.md](../references/session-variables.md) | Session variables for workload tuning |
| Node 3: Coprocessor bottleneck | Delegate to MODULE-TIKV | Infrastructure-level fix |
| Node 4: Lock contention | (transaction-level, see fault-diagnosis) | Reduce transaction scope |
| Node 5: Memory overflow | [../references/sql-optimization.md](../references/sql-optimization.md) | Join strategy selection |
| Node 5: Subquery issue | [../references/sql-optimization.md](../references/sql-optimization.md) | Decorrelation, SEMI_JOIN_REWRITE |
| Node 6: MVCC version buildup | Delegate to MODULE-TIKV R6_GC | GC tuning, long transaction cleanup |
| Node 7: Implicit type conversion | [../references/sql-optimization.md](../references/sql-optimization.md) | Fix column/parameter type mismatch, check CAST in plan |
| Node 8: No clear SQL cause | [../references/sql-optimization.md](../references/sql-optimization.md) | Deep EXPLAIN ANALYZE reading |
| Any: Cost model bias | [../references/optimizer-controls.md](../references/optimizer-controls.md) | Cost factor tuning |
| Any: Upgrade plan instability | [../references/optimizer-controls.md](../references/optimizer-controls.md) | Fix control toggles |
| Any: Plan locked wrong | [../references/plan-replayer-testing.md](../references/plan-replayer-testing.md) | Local reproduction |
| Any: Stats config issue | [../references/stats-management.md](../references/stats-management.md) | Stats v1/v2, column coverage |
| Any: Cold start plan drift | [../references/stats-management.md](../references/stats-management.md) | Init stats, sync load |

**Similar case search:** Before applying a fix, search for matching precedent:
- By symptom/root cause: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
- By GitHub issue/PR: [../../knowledge/customer-issues/](../../knowledge/customer-issues/)

**Diagnostic data collection script:** [../scripts/collect_diag_info.sql](../scripts/collect_diag_info.sql)

---

## Slow Query Common Query Templates

### Top N by Execution Time
```sql
SELECT digest, digest_text, MAX(query_time) AS max_qt, COUNT(*) AS cnt
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY max_qt DESC LIMIT 10
```

### Top N by Execution Frequency (high-frequency non-slow SQL can also be problematic)
```sql
SELECT digest, digest_text, COUNT(*) AS cnt, AVG(query_time) AS avg_qt
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY cnt DESC LIMIT 10
```

### Top N by Memory Consumption
```sql
SELECT digest, digest_text, MAX(mem_max) AS max_mem, MAX(disk_max) AS max_disk
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY max_mem DESC LIMIT 10
```

### Top N by Scan Volume
```sql
SELECT digest, digest_text, MAX(total_keys) AS max_keys, MAX(process_keys) AS max_proc
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY max_keys DESC LIMIT 10
```

### Execution Plan and Details for a Specific Digest
```sql
SELECT time, query_time, decoded_plan, total_keys, process_keys,
       mem_max, disk_max, backoff_types, cop_proc_avg, cop_wait_avg
FROM slowlogs
WHERE digest = '{digest}'
  AND date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
ORDER BY query_time DESC LIMIT 5
```
