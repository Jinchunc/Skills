# Statistics Management

## 1. Stats Health & Auto-Analyze

Statistics health determines whether the optimizer sees the real data distribution. When statistics go stale, TiDB can pick the wrong join order, the wrong access path, or the wrong execution engine even if the SQL itself did not change.

This guide focuses on keeping `AUTO ANALYZE` ahead of statistics decay without overloading TiDB or TiKV.

## What "healthy stats" means operationally

`AUTO ANALYZE` is healthy when it can refresh statistics at least as fast as tables become stale.

Treat the following as the primary signals:

- `Statistics -> Stats Healthy Distribution`
- `Statistics -> Auto Analyze Duration`
- `Statistics -> Auto Analyze Query Per Minute`
- TiDB CPU and memory usage
- TiKV read pressure during analyze windows

In practice:

- Most relevant tables should stay in the high-health buckets (`[80, 100]`).
- The unhealthy bucket should not show a persistent backlog.
- `AUTO ANALYZE` throughput should not spend long periods at zero when there are stale tables waiting.

## Diagnostic workflow

### 1. Check whether stats are actually decaying faster than TiDB can repair them

Start with:

```sql
SHOW STATS_HEALTHY;
SHOW ANALYZE STATUS;
```

Then compare the dashboard trends:

- If the unhealthy range keeps growing for days, `AUTO ANALYZE` is not keeping up.
- If `Auto Analyze Query Per Minute` frequently drops to zero while stale tables still exist, the trigger threshold may be too conservative.
- If `Auto Analyze Duration` P95 is high, analyze work is too slow and needs capacity or concurrency tuning.

### 2. Decide whether the bottleneck is triggering or execution

Use this split:

- **Too few analyze tasks start**: lower `tidb_auto_analyze_ratio`
- **Tasks start but finish too slowly**: tune analyze concurrency, scan concurrency, or partition/global-stats behavior
- **Tasks are slow only for partitioned tables**: inspect partition merge behavior
- **Analyze harms business traffic**: isolate the stats owner and add TiKV rate limiting before increasing concurrency

## Primary tuning levers

### `tidb_auto_analyze_ratio`

Controls when a table becomes eligible for `AUTO ANALYZE`.

- Lower value: refresh stats earlier, more frequent analyze
- Higher value: fewer analyze tasks, higher risk of stale stats

Use a lower ratio only when:

- Analyze duration is already acceptable
- TiDB and TiKV still have headroom
- The unhealthy bucket is rising because analyze is triggered too late, not because tasks are too slow

### `tidb_auto_analyze_concurrency` (v8.5+)

Controls how many analyze jobs can run at the same time.

Use it when:

- `AUTO ANALYZE` is clearly throughput-limited
- TiDB CPU is not saturated
- TiKV read pressure is controlled

Do not increase it blindly. If possible, dedicate one or more TiDB nodes to stats work first.

### `tidb_auto_build_stats_concurrency`

Controls parallel stats building. This is especially useful for partitioned tables because multiple partitions can be analyzed in parallel.

Increase it when:

- Partition tables dominate the backlog
- TiDB CPU is still underutilized

### `tidb_build_sampling_stats_concurrency`

Controls concurrent column sampling.

Increase it when:

- Wide tables are slow to analyze
- Column sampling, not partition fan-out, is the bottleneck

### Effective concurrency rule

Treat these parameters as multiplicative, not independent:

- `tidb_auto_build_stats_concurrency`
- `tidb_build_sampling_stats_concurrency`
- `tidb_auto_analyze_concurrency` (v8.5+)

Keep the effective concurrency within what the TiDB CPU can sustain. Overdriving them creates contention and can make analyze slower, not faster.

## Partitioned tables

Partitioned tables often dominate stats maintenance cost.

### `tidb_auto_analyze_partition_batch_size`

Increase it when TiDB repeatedly performs many small partition analyze batches and global stats merge becomes the long pole.

### `tidb_enable_async_merge_global_stats`

Enable this on versions that support it when global stats merge is slow or memory-heavy.

Use it when:

- `SHOW ANALYZE STATUS` shows long-running `merge global stats`
- Partitioned-table analyze causes memory spikes

### `tidb_merge_partition_stats_concurrency`

Increase it when the bottleneck is merging global partition stats rather than scanning base data.

## Scan concurrency and TiKV protection

### `tidb_analyze_distsql_scan_concurrency`

This controls the scan concurrency used by analyze.

Increase it when:

- Analyze is scan-bound
- TiKV still has spare read bandwidth

### `tidb_sysproc_scan_concurrency`

Tune this carefully in large clusters, especially after scale-out.

General rule:

- Do not set it higher than the practical TiKV fan-out your cluster can absorb
- Add TiKV background read rate limiting before raising it

### TiKV guardrail

Before increasing analyze scan concurrency, rate-limit background reads in TiKV. Otherwise analyze can steal too much read bandwidth from business traffic.

## Stats-owner isolation

### `tidb_enable_stats_owner`

Use dedicated TiDB nodes for stats ownership when available.

This is valuable when:

- Analyze work competes with latency-sensitive SQL
- You want to raise analyze concurrency safely
- You need predictable operational isolation

Do not disable stats ownership on every TiDB node. That is effectively equivalent to disabling cluster-wide auto analyze execution.

## Common failure patterns

### Backlog grows, but query-per-minute is often zero

Likely cause:

- `tidb_auto_analyze_ratio` is too high

Action:

1. Lower `tidb_auto_analyze_ratio` gradually
2. Watch the unhealthy bucket trend
3. Confirm TiDB and TiKV still have headroom

### Backlog grows and duration P95 is high

Likely cause:

- Analyze is under-provisioned or blocked on partition/global-stats work

Action:

1. Inspect `SHOW ANALYZE STATUS`
2. Tune partition/global-stats settings first for partition-heavy workloads
3. Increase analyze/build/sampling concurrency gradually
4. Verify TiKV read pressure remains acceptable

### Analyze hurts online traffic

Likely cause:

- Too much scan concurrency or too many parallel jobs without isolation

Action:

1. Add TiKV background read rate limiting
2. Move stats ownership to dedicated TiDB nodes if possible
3. Reduce analyze concurrency if TiKV or business latency regresses

## Recommended operating discipline

- Change one variable at a time.
- Use dashboard trends, not single snapshots, to judge improvement.
- For partition-heavy clusters, inspect global-stats merge explicitly.
- Prefer dedicated stats-owner TiDB nodes before aggressive concurrency increases.
- Re-check query plans after major stats tuning changes because plan choices can legitimately change.

---

## 2. Stats Loading & Startup

Two stats-loading paths matter during TiDB startup and query compilation:

- **Init stats**: what TiDB loads during startup before or while serving traffic
- **Sync load**: what TiDB loads on demand during optimization when the needed histogram, TopN, or other stats objects are not fully in memory

If either path is slow or incomplete, the same SQL can get different plans before and after startup settles.

## Typical symptoms

- Query plans change shortly after TiDB restart
- The first wave of queries after restart is slower than steady-state traffic
- `EXPLAIN` shows unstable estimates during warm-up
- `Statistics -> Sync Load QPS` shows many timeouts

## Init stats evolution by version

### Before v7.1

TiDB loaded all statistics eagerly into memory during startup. On clusters with many tables, this could make startup very slow.

### v7.1: lite-init-stats

TiDB started by loading only stats metadata first, then relied on asynchronous loading for the heavier stats objects.

Trade-off:

- Faster startup
- Higher risk of plan instability during the warm-up period

### v6.5.7 and v7.1: force-init-stats

These versions added a mode that waits for stats initialization to complete before serving traffic.

Use this when:

- Startup latency is less important than predictable first-query plans
- Your workload is sensitive to plan changes immediately after restart

### v7.1.2 and v8.1: concurrently-init-stats

These versions improved startup by initializing stats concurrently, which reduces cold-start pain on clusters with many tables.

## Known fixes for startup-time plan instability

If plans jump after restart and the root cause is stats loading behavior, prefer upgrading to a release that includes the fix:

- v6.5.10
- v7.1.6
- v7.5.2
- v8.1.0

## Sync load

Sync load was introduced so the optimizer can wait briefly for complete column statistics instead of planning against partial metadata only.

### `tidb_stats_load_sync_wait`

This is the maximum time the optimizer waits for sync-loaded stats.

- Higher value: fewer stats-load timeouts, more stable planning, but longer compile latency
- Lower value: faster compile path, but higher risk of planning with incomplete stats

Use it when:

- `Sync Load QPS` shows meaningful timeout volume
- Compilation latency spikes correlate with missing stats objects

## How to diagnose sync load issues

### 1. Check the dashboard

Look at:

- `Statistics -> Sync Load QPS`

If you see many timeouts, the optimizer is frequently planning before full stats are ready.

### 2. Check the TiDB version

If the cluster is older than the fixed releases for known loading issues, upgrading is usually the cleanest fix.

### 3. Decide whether the problem is timeout budget or worker capacity

Use this split:

- **Timeouts are occasional and scattered**: increase `tidb_stats_load_sync_wait`
- **Timeouts are frequent and continuous**: increase stats-load worker capacity if the version requires manual tuning

### `stats-load-concurrency`

On versions where this is manually tuned, raise it when sync load is backlogged.

### v8.2+ adaptive behavior

In newer releases, `stats-load-concurrency = 0` enables adaptive concurrency based on CPU cores.

Implication:

- If you are already on v8.2+ and still see many sync-load timeouts, first tune `tidb_stats_load_sync_wait`
- If that is not enough, the machine may simply need more CPU or a different deployment shape

## Operational guidance

### Prefer upgrade over large startup workarounds

If you are seeing restart-time plan drift on an affected older release, upgrade before building operational complexity around it.

### Use force-init-stats only when the first queries matter more than startup latency

Examples:

- Stateful services that execute latency-sensitive SQL immediately after failover
- Planned maintenance windows where predictable warm-up is more important than the shortest restart time

### Watch startup regressions after changing stats policy

If you change:

- init-stats behavior
- sync-load wait budget
- stats-load concurrency

then validate:

- first-query latency after restart
- plan stability for the top critical queries
- TiDB CPU during warm-up

## Fast decision matrix

| Symptom | Most likely first move |
|--------|-------------------------|
| Plans change after restart on older releases | Upgrade to a fixed release |
| Sync Load timeouts are occasional | Increase `tidb_stats_load_sync_wait` |
| Sync Load timeouts are sustained | Increase stats-load worker capacity or machine CPU |
| Startup is too slow with many tables | Prefer concurrent init on newer releases |
| First queries after restart must be stable | Consider force-init-stats mode |

---

## 3. Stats Version & Analyze Configuration

Statistics collection quality is not only about whether `ANALYZE` runs. The stats version, column coverage, partition behavior, and column-type exclusions all shape plan quality and resource usage.

## Prefer stats version 2

TiDB historically had two stats systems:

- stats v1
- stats v2

Stats v1 is no longer maintained. Since v6.5, the default has moved to stats v2 and new deployments should stay there unless debugging a specific regression.

### Why stats v2 is preferred

- Better estimation on large tables and skewed data
- Better handling of out-of-range predicates
- Faster analyze because table and index sampling is more efficient
- Lower collection overhead because not every older stats structure is required

## `tidb_analyze_version`

Use:

```sql
SELECT @@tidb_analyze_version;
SET GLOBAL tidb_analyze_version = 2;
```

Operational rule:

- Keep the cluster on a consistent stats version as much as possible
- Mixed-version stats across tables and indexes make diagnosis harder and can create temporary plan instability during migrations

## When migrating old stats to v2

The safest pattern is:

1. Switch the analyze version
2. Re-analyze the tables that matter
3. Validate plan quality on critical SQL

Avoid partial migrations of only a few hot tables unless you have a clear reason to do so.

## Column coverage policy

### `tidb_analyze_column_options`

This variable controls how much column-level stats `ANALYZE` collects.

Main choices:

- `PREDICATE`: collect only predicate columns
- `ALL`: collect all columns

Use `ALL` when:

- The workload is analytical
- Query shapes vary a lot
- Non-predicate columns still influence plan quality or resource usage indirectly

Use `PREDICATE` when:

- The workload is strongly OLTP-oriented
- You need to cut analyze overhead
- Plan regressions are not caused by missing column coverage

For OLAP-heavy workloads, `PREDICATE` can reduce stats completeness enough to hurt plan quality.

## OOM-oriented configuration

### Partitioned-table global stats

Partitioned-table analyze can cause large memory spikes when global stats merge is expensive.

Preferred mitigation:

- Enable `tidb_enable_async_merge_global_stats` on supporting versions

### `tidb_enable_historical_stats`

Disable it unless you specifically need historical stats snapshots and have validated the memory cost.

Why:

- Historical stats can add meaningful TiDB memory pressure
- Older implementations were especially risky on tables with many stats objects or partitions

### `tidb_analyze_skip_column_types`

Use this to skip stats collection for low-value, memory-heavy column types such as:

- `json`
- `blob`
- `mediumblob`
- `longblob`
- `text`
- `mediumtext`
- `longtext`

This is appropriate when:

- These columns are large
- They are not useful for predicate estimation
- Analyze or memory usage is unstable because of them

## Sampling and build concurrency

### `tidb_build_sampling_stats_concurrency`

Use it to accelerate column sampling for wide tables.

### `tidb_auto_build_stats_concurrency`

Use it to accelerate stats building, especially on partition-heavy workloads.

Do not tune them in isolation. Their combined effect can exceed what the host CPU can handle.

## Version-sensitive guidance

- v6.5+: stats v2 should be the default path
- v7.5+: async global-stats merge is a key tool for partitioned-table analyze
- v8.5+: concurrent auto analyze makes throughput tuning more practical, but only if TiDB and TiKV still have capacity

## Practical checklist

Use this order:

1. Confirm the cluster is on stats v2
2. Decide whether `ALL` or `PREDICATE` fits the workload
3. Disable or limit memory-heavy stats features unless they are truly needed
4. Exclude large low-value column types from analyze
5. Tune sampling/build concurrency only after the policy choices above are correct

## Common anti-patterns

- Leaving the cluster on old stats behavior after upgrade because "nothing broke yet"
- Using `PREDICATE` for OLAP workloads and then debugging bad plans as if they were optimizer bugs
- Increasing analyze concurrency before excluding memory-heavy column types
- Turning on historical stats without a concrete operational need
