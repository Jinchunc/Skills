variable "project_name" {
  description = "Project name used for tagging and naming."
  type        = string
  default     = "tidb-onebox"
}

variable "environment" {
  description = "Environment name."
  type        = string
  default     = "dev"
}

variable "aws_region" {
  description = "AWS region for all resources."
  type        = string
  default     = "us-west-2"
}

variable "vpc_cidr" {
  description = "CIDR range for VPC."
  type        = string
  default     = "10.20.0.0/16"
}

variable "availability_zones" {
  description = "Availability zones used by VPC and EKS."
  type        = list(string)
  default     = ["us-west-2a", "us-west-2b"]
}

variable "public_subnet_cidrs" {
  description = "Public subnet CIDRs."
  type        = list(string)
  default     = ["10.20.0.0/24", "10.20.1.0/24"]
}

variable "private_subnet_cidrs" {
  description = "Private subnet CIDRs."
  type        = list(string)
  default     = ["10.20.10.0/24", "10.20.11.0/24"]
}

variable "eks_cluster_version" {
  description = "EKS cluster Kubernetes version."
  type        = string
  default     = "1.35"
}

variable "node_instance_types" {
  description = "EKS managed node group instance types."
  type        = list(string)
  default     = ["m6i.large"]
}

variable "node_desired_size" {
  description = "Desired node count."
  type        = number
  default     = 2
}

variable "node_min_size" {
  description = "Minimum node count."
  type        = number
  default     = 2
}

variable "node_max_size" {
  description = "Maximum node count."
  type        = number
  default     = 4
}

variable "scale_pd_replicas" {
  description = "Temporary override for tidb_x.pd_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_tikv_replicas" {
  description = "Temporary override for tidb_x.tikv_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_tidb_replicas" {
  description = "Temporary override for tidb_x.tidb_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_pd_tso_replicas" {
  description = "Temporary override for tidb_x.pd_tso_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_pd_scheduling_replicas" {
  description = "Temporary override for tidb_x.pd_scheduling_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_tiproxy_replicas" {
  description = "Temporary override for tidb_x.tiproxy_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_tiflash_write_replicas" {
  description = "Temporary override for tidb_x.tiflash_write_replicas during scale operations."
  type        = number
  default     = null
}

variable "scale_tiflash_compute_replicas" {
  description = "Temporary override for tidb_x.tiflash_compute_replicas during scale operations."
  type        = number
  default     = null
}

variable "enable_ingress_nginx" {
  description = "Install ingress-nginx Helm release (NLB-backed)."
  type        = bool
  default     = false
}

variable "enable_metrics_server" {
  description = "Install metrics-server Helm release."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Additional tags applied to all resources."
  type        = map(string)
  default     = {}
}

variable "readonly_principal_arns" {
  description = "Optional IAM principals granted read-only EKS access."
  type        = list(string)
  default     = []
}

variable "cluster_admin_principal_arn" {
  description = "IAM principal ARN granted cluster admin access. Accepts any IAM role/user ARN (e.g. the ARN from `aws sts get-caller-identity`, or an `AWSReservedSSO_*` role ARN). Empty string falls back to the caller's own ARN."
  type        = string
  default     = ""
}

# ── TiDB-X configuration ──────────────────────────────────────────────────────
# All TiDB-X settings are grouped into a single object so the tfvars file
# stays readable and adding new fields doesn't require touching outputs.tf.

variable "tidb_x" {
  description = "TiDB-X operator and cluster configuration."
  type = object({
    # ── Operator ──
    operator_namespace     = optional(string, "tidb-x-admin")
    operator_chart_version = optional(string, "v2.1.0-alpha.15")
    operator_image         = optional(string, "pingcap/tidb-operator")
    # Defaults to operator_chart_version when empty.
    operator_image_tag = optional(string, "")

    # ── Cluster identity ──
    cluster_name      = optional(string, "tidb-x-onebox")
    cluster_namespace = optional(string, "tidb-x-cluster")
    # Cluster-wide default version used when a component omits its own version.
    cluster_version = optional(string, "v8.5.4-nextgen.202510.1")

    # ── S3 object storage backend ──
    s3_bucket_name = optional(string, "tidb-x-onebox-data")
    # Set true to let Terraform create and manage the bucket lifecycle.
    s3_create_bucket   = optional(bool, false)
    s3_service_account = optional(string, "tidb-x-s3")

    # ── PD (Placement Driver) ──
    pd_image      = optional(string, "")
    pd_version    = optional(string, "") # falls back to cluster_version
    pd_replicas   = optional(number, 1)
    pd_storage    = optional(string, "20Gi")
    pd_config     = optional(string, "") # raw TOML
    pd_extra_spec = optional(string, "") # raw YAML overlay

    # ── TiKV ──
    tikv_image      = optional(string, "")
    tikv_version    = optional(string, "")
    tikv_replicas   = optional(number, 1)
    tikv_storage    = optional(string, "100Gi")
    tikv_config     = optional(string, "")
    tikv_extra_spec = optional(string, "")

    # ── TiDB (SQL layer) ──
    tidb_image    = optional(string, "")
    tidb_version  = optional(string, "")
    tidb_replicas = optional(number, 1)
    tidb_config   = optional(string, "")

    # ── TSO microservice (PD microservices mode) ──
    # Must be enabled together with pd_scheduling for mode=ms to take effect.
    pd_tso_enabled  = optional(bool, true)
    pd_tso_image    = optional(string, "") # defaults to pd_image
    pd_tso_version  = optional(string, "")
    pd_tso_replicas = optional(number, 1)

    # ── Scheduling microservice ──
    pd_scheduling_enabled  = optional(bool, true)
    pd_scheduling_image    = optional(string, "") # defaults to pd_image
    pd_scheduling_version  = optional(string, "")
    pd_scheduling_replicas = optional(number, 1)

    # ── TiProxy ──
    tiproxy_enabled  = optional(bool, true)
    tiproxy_image    = optional(string, "")
    tiproxy_version  = optional(string, "")
    tiproxy_replicas = optional(number, 1)

    # ── TiFlash write (disaggregated write node) ──
    tiflash_write_enabled    = optional(bool, true)
    tiflash_write_image      = optional(string, "")
    tiflash_write_version    = optional(string, "")
    tiflash_write_replicas   = optional(number, 1)
    tiflash_write_storage    = optional(string, "100Gi")
    tiflash_write_config     = optional(string, "")
    tiflash_write_extra_spec = optional(string, "")

    # ── TiFlash compute (disaggregated compute node) ──
    tiflash_compute_enabled    = optional(bool, true)
    tiflash_compute_image      = optional(string, "")
    tiflash_compute_version    = optional(string, "")
    tiflash_compute_replicas   = optional(number, 1)
    tiflash_compute_storage    = optional(string, "100Gi")
    tiflash_compute_config     = optional(string, "")
    tiflash_compute_extra_spec = optional(string, "")
  })
  default = {}
}
