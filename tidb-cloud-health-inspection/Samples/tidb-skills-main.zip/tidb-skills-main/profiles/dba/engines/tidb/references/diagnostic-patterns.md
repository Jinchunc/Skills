# TiDB Diagnostic Patterns — Quick Reference

High-frequency diagnostic scenarios with decision trees and gotchas. Use as rapid triage index before diving into detailed paths/ and modules/.

## Diagnostic Flow

```
User symptom → SKILL.md routing table
  → paths/* (symptom-specific decision tree)
    → modules/* (deep component analysis)
```

## Top 10 High-Frequency Scenarios

### 1. Single SQL Slowdown

**Path:** ../performance-optimization/paths/sql-slow.md
**Common root causes (ordered by frequency):**
- Stale statistics — `ANALYZE TABLE` needed
- Missing index — full table scan or wrong index selection
- Execution plan regression — check `SHOW WARNINGS` after `EXPLAIN`, look for plan binding changes
- Lock contention — `txnLock` backoff in slowlog, check `DATA_LOCK_WAITS`
- Coprocessor bottleneck — large scan volume, TiKV CPU saturated
- Implicit type conversion — column type mismatch in WHERE clause causes index skip

**Quick check:** compare `Process_keys` vs `Total_keys` in slowlog. Large gap indicates MVCC garbage or scan inefficiency.

### 2. Cluster-Wide Latency Increase

**Path:** ../performance-optimization/paths/latency-global.md
**Triage:** decompose DB Time into parse/compile/execute/backoff/commit. The dominant component points to the layer.
- Execute dominant — TiKV read path or SQL plan issue
- Backoff dominant — lock contention or region unavailability
- Commit dominant — write path (raftstore, apply, disk)

### 3. TiKV CPU High

**Path:** ../performance-optimization/paths/cpu-high.md
**Thread pool breakdown matters:**
- `grpc_server` high — request volume issue, check QPS
- `unified-read-pool` / `coprocessor` high — heavy read, check top SQL by scan volume
- `raftstore` high — too many regions per TiKV (>50K warning, >80K critical) or hot write regions
- `scheduler-worker` high — write contention, check latch wait

### 4. TiKV OOM / Memory High

**Path:** ../fault-diagnosis/paths/oom.md
**Common culprits (check in order):**
1. Block cache misconfigured — default 45% of total memory, check `storage.block-cache.capacity`
2. Region count too high — each region costs ~30–50KB metadata (经验估值，不同来源 30–50KB/个；未能以官方源码快速实证). 100K regions = ~3–5GB overhead
3. Coprocessor large query — single query scanning huge range, check `coprocessor_mem_lock_keys`
4. Write buffer accumulation — memtable backlog during write stall
5. Lock accumulation — pessimistic lock memory during long transactions

**Key metric:** `process_resident_memory_bytes` vs `tikv_engine_block_cache_size_bytes` + region count x 30–50KB

### 5. Hotspot / Instance Imbalance

**Path:** ../performance-optimization/paths/hotspot.md
**Classification:**
- **Read hotspot:** one TiKV handles disproportionate read QPS. Check table access pattern, consider follower read.
- **Write hotspot:** sequential insert (auto-increment PK, monotonic timestamp). Check `SPLIT TABLE` or `SHARD_ROW_ID_BITS`.
- **Region-level:** use `SHOW TABLE REGIONS` to map hot region to table/index. Check PD scheduling for pending operators.

**Gotcha:** after `SPLIT TABLE`, PD needs time to scatter. Monitor `region_balance` operator count.

### 6. Write Latency / Write Stall

**Path:** ../performance-optimization/paths/latency-write.md
**Decision chain:** S1_BALANCE > S2_WRITE_STALL > S3_COMPACTION > S4_ASYNC_WRITE
- Write stall — check `tikv_engine_write_stall` reason: L0 file count, pending compaction bytes, memtable count
- Compaction backlog — insufficient compaction threads or disk IOPS bottleneck
- Raft propose/apply slow — check `raftstore_propose_wait_duration` and `raftstore_apply_wait_duration`
- Disk bottleneck — check `disk_io_time` and WAL fsync duration

### 7. Transaction Conflicts

**Path:** ../performance-optimization/paths/txn-conflict.md
**Three flavors:**
- **Write conflict** (optimistic): `WriteConflict` error at commit, retry overhead. Check `tidb_txn_retry_num`.
- **Lock wait** (pessimistic): `information_schema.DATA_LOCK_WAITS` shows holder/waiter. Common with large batch + concurrent OLTP.
- **Deadlock:** `information_schema.DEADLOCKS` has the cycle. Usually 2-3 transactions with opposite key ordering.

**Slowlog signal:** `Backoff_types` containing `txnLock` or `regionMiss`.

### 8. Node Down / Restart

**Path:** ../fault-diagnosis/paths/store-failure.md
**OOM detection:** check `dmesg` or systemd journal for `oom-kill`. If OOM:
- TiDB OOM — identify the SQL: `tidb_mem_quota_query` exceeded, check expensive query log
- TiKV OOM — see scenario #4 above

**Post-recovery checklist:**
1. Region leader rebalance — may take 10-30min depending on region count
2. Raft log replay — `raftstore_apply_log_duration` spike is normal during catch-up
3. Stale reads — until leader transfer completes, some reads may fail with `NotLeader`

### 9. DDL Stuck

**Path:** ../fault-diagnosis/paths/query-error.md (DDL section)
**Common causes:**
- Long-running transaction blocking schema change — check `ADMIN SHOW DDL JOBS` + `CLUSTER_TIDB_TRX`
- DDL owner unhealthy — check `ADMIN SHOW DDL` for owner status
- Add index backfill slow — normal for large tables, check progress via `ADMIN SHOW DDL JOBS`
- v6.5+ `fast_reorg` + distributed task bug — known issue, check version-specific notes

**Safe to cancel:** `ADMIN CANCEL DDL JOBS <job_id>` is non-destructive.

### 10. TiFlash Issues

**Path:** ../performance-optimization/paths/tiflash.md
**Common issues:**
- Replica lag — check `tiflash_sync_replica_lag`, usually caught up within minutes for small tables
- Query not routed to TiFlash — check `tidb_isolation_read_engines` session variable
- TiFlash OOD (out of disk) — TiFlash stores column data separately, can grow faster than expected

## Common Diagnostic Gotchas

1. **Statistics staleness is the #1 root cause** of unexpected plan changes. Always check `SHOW STATS_HEALTHY` early.
2. **Region count per TiKV** is a silent killer. >50K starts degrading, >80K causes raftstore CPU saturation and memory pressure.
3. **GC lag** (`tikv_gcworker_autogc_safe_point` far behind current TSO; value is a TSO, divide by 2^18 for seconds) causes MVCC accumulation, leading to read amplification and everything slowing down. Check `tidb_gc_life_time` and long-running transactions.
4. **Write stall is not disk full.** Write stall is RocksDB flow control, triggered by compaction backlog. Disk can have plenty of space.
5. **Hotspot after split** needs PD scatter time. Don't split + immediately load test.
6. **Pessimistic lock memory** is not bounded by `tidb_mem_quota_query`. Large transactions can accumulate locks that push TiKV OOM.
7. **`ANALYZE TABLE` on large tables** can itself cause load. Use `ANALYZE TABLE ... WITH 256 BUCKETS` or schedule during off-peak.
8. **TiFlash replica count** affects storage, not query parallelism. 1 replica is usually sufficient.
