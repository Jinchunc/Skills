# PLAYBOOK: Execution Plan Compare

> Compare execution plans for the same SQL across time periods to detect plan regression.
> Core question: "Did the plan change, and if so, why?"

---

## When to Use

- Single SQL suddenly became slow (no code change)
- After TiDB version upgrade
- After ANALYZE TABLE or statistics auto-update
- Slow query batch analysis detected plan instability
- User reports "it was fast yesterday, slow today"

## Prerequisites

1. **MODULE-CLUSTER-ID** completed
2. SQL digest (or SQL text to derive digest)
3. Two time windows: **baseline** (when fast) and **current** (when slow)

---

## Phase 1: Collect Plans from Both Windows

### Step 1.1: Baseline Period Plans

```sql
SELECT decoded_plan, query_time, total_keys, process_keys,
       mem_max, cop_proc_avg, cop_wait_avg,
       time AS exec_time
FROM slowlogs
WHERE digest = '{digest}'
  AND date = '{baseline_date}'
  AND time BETWEEN {baseline_start} AND {baseline_end}
ORDER BY query_time ASC
LIMIT 5
```

> Note: ORDER BY query_time ASC — in baseline period, we want the "normal" fast executions.

### Step 1.2: Current Period Plans

```sql
SELECT decoded_plan, query_time, total_keys, process_keys,
       mem_max, cop_proc_avg, cop_wait_avg,
       time AS exec_time
FROM slowlogs
WHERE digest = '{digest}'
  AND date = '{current_date}'
  AND time BETWEEN {current_start} AND {current_end}
ORDER BY query_time DESC
LIMIT 5
```

### Step 1.3: If Baseline Not in slow_query_logs

The SQL might not have been slow in the baseline period (not captured in slow log).

Fallback: Ask user to execute on cluster:
```sql
-- For user execution:
SELECT @@tidb_slow_log_threshold;
-- If threshold is high, the SQL may not appear in slow logs during normal performance.
-- Ask user to provide: EXPLAIN ANALYZE {sql_text}
```

---

## Phase 2: Plan Diff Analysis

### Step 2.1: Structural Comparison

Compare decoded_plan between baseline and current:

| Check Point | What to Compare | Significance |
|-------------|----------------|--------------|
| **Access method** | TableFullScan vs IndexRangeScan | Index usage changed |
| **Join order** | Table join sequence | Optimizer chose different join order |
| **Join type** | HashJoin vs IndexJoin vs MergeJoin | Cost estimation changed |
| **Operator** | Presence of Sort, TopN, Aggregation | Query plan structure changed |
| **Task type** | cop[tikv] vs root | Computation pushed down vs pulled up |

### Step 2.2: Quantitative Comparison

| Metric | Baseline | Current | Ratio | Interpretation |
|--------|----------|---------|-------|----------------|
| query_time | | | | Overall regression factor |
| total_keys | | | | Scan volume change |
| process_keys | | | | Useful work ratio |
| mem_max | | | | Memory impact |
| cop_proc_avg | | | | Per-coprocessor processing time |
| cop_wait_avg | | | | Coprocessor queuing time |

**Key ratios:**
- `total_keys_current / total_keys_baseline` > 10x → Scan explosion (plan or data change)
- `process_keys` stayed similar but `query_time` increased → Infrastructure issue, not plan issue
- `cop_wait_avg` increased significantly → Coprocessor congestion (not a plan issue)

---

## Phase 3: Root Cause Classification

### Decision Tree

```
Plan structure changed?
├── YES → Plan Regression
│   ├── IndexScan → TableFullScan?
│   │   ├── Statistics stale (estRows way off) → Node A
│   │   ├── Index dropped/invisible → Node B
│   │   └── Optimizer hint removed/SQL Binding expired → Node C
│   ├── Join type changed (IndexJoin → HashJoin)?
│   │   ├── Inner table grew significantly → Node D
│   │   └── Statistics on join column stale → Node A
│   └── Join order changed?
│       └── Table cardinality changed → Node A or Node D
│
└── NO → Same Plan, Different Performance
    ├── total_keys increased significantly?
    │   ├── Data volume grew → Node D
    │   └── MVCC versions accumulated → Node E
    ├── cop_proc_avg increased?
    │   └── TiKV resource contention → MODULE-TIKV
    ├── cop_wait_avg increased?
    │   └── Coprocessor thread saturation → MODULE-TIKV
    └── backoff_types appeared?
        └── Lock contention → PATH-TXN-CONFLICT
```

### Root Cause Nodes

**Node A: Statistics Stale**
```
Evidence: actRows vs estRows deviation > 10x in current plan
Diagnostic SQL (for user execution):
  SHOW STATS_HEALTHY WHERE Table_name IN ('{involved_tables}');
  SHOW STATS_META WHERE Table_name IN ('{involved_tables}');
Recommendation (for user execution):
  ANALYZE TABLE {table};
Confidence: HIGH
```

**Node B: Index Unavailable**
```
Evidence: Baseline used index X, current uses TableFullScan
Diagnostic SQL (for user execution):
  SHOW INDEX FROM {table};
  SHOW CREATE TABLE {table};
  -- Check if index is invisible:
  SELECT * FROM information_schema.tidb_indexes
  WHERE table_name = '{table}' AND is_visible = 'NO';
Recommendation: Recreate index or set visible (for user execution)
Confidence: HIGH
```

**Node C: SQL Binding Expired**
```
Evidence: Baseline had a SQL Binding, current does not
Diagnostic SQL (for user execution):
  SHOW GLOBAL BINDINGS WHERE Original_sql LIKE '%{sql_pattern}%';
Recommendation: Recreate binding (for user execution):
  CREATE GLOBAL BINDING FOR {sql} USING {baseline_plan_hint};
Confidence: HIGH
```

**Node D: Data Volume Change**
```
Evidence: total_keys increased proportionally to data growth
Diagnostic SQL (for user execution):
  SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH
  FROM information_schema.TABLES
  WHERE TABLE_SCHEMA = '{db}' AND TABLE_NAME IN ('{tables}');
Recommendation: Review index design, consider partitioning (for user execution)
Confidence: MEDIUM
```

**Node E: MVCC Accumulation**
```
Evidence: total_keys >> process_keys (ratio > 10x)
Check GC status:
  metrics: tikv_gc_last_run_duration_seconds{tidb_cluster_id="{cluster_id}"}
  metrics: tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}"}
Recommendation: Check GC safe point, long-running transactions (for user execution):
  SELECT * FROM mysql.tidb WHERE variable_name = 'tikv_gc_safe_point';
  SELECT * FROM information_schema.cluster_processlist
  WHERE time > 600 ORDER BY time DESC;
Confidence: MEDIUM
```

---

## Phase 4: Report

```
## Execution Plan Comparison Report
Cluster: {cluster_id} | SQL Digest: {digest}
Baseline: {baseline_window} (avg {baseline_qt}ms)
Current:  {current_window} (avg {current_qt}ms)
Regression factor: {ratio}x

### Plan Changed: YES/NO

### Structural Diff
{side-by-side plan comparison highlighting differences}

### Quantitative Diff
| Metric | Baseline | Current | Change |
|--------|----------|---------|--------|

### Root Cause
{root_cause} — Confidence: {HIGH/MEDIUM/LOW}
Evidence: {specific metrics/values}

### Recommendations (for user execution)
1. {immediate action}
2. {preventive measure}
```

---

## Relationship to Other Components

| Component | Relationship |
|-----------|-------------|
| PATH-SQL-SLOW | Routes here when plan instability suspected |
| PLAYBOOK-SLOW-QUERY-BATCH | Routes here when per-digest analysis finds multiple plans |
| MODULE-SQL | Provides SQL_PLAN_ANALYSIS sub-module |
| MODULE-TIKV | Called when same-plan performance regression points to infrastructure |
