# PATH-COLD-START (S1.5 Slow First Query)

> Entry condition: First query is very slow after startup/long idle period, subsequent queries return to normal

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm Cold Start Pattern

```
metrics:
  p99: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))  step=15s
  instance_uptime: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}"}

checks:
  - A single spike appears in p99 time series (> baseline x 5) then drops back within < 5min
  - Uptime drops sharply (an instance with uptime < 300s) aligned with the spike timing
pattern: Spike only appears on first request or shortly after restart
```

### Step 2: Identify Component

**Branch a: TiKV Cold Start**
```
metrics:
  block_cache: tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}", instance="{inst}"}
  block_cache_hit: sum(rate(tikv_engine_block_cache_hit{tidb_cluster_id="{cluster_id}"}[2m])) / (sum(rate(tikv_engine_block_cache_hit{tidb_cluster_id="{cluster_id}"}[2m])) + sum(rate(tikv_engine_block_cache_miss{tidb_cluster_id="{cluster_id}"}[2m])))

condition: block_cache_hit < 50% after restart (normally > 95% during operation)
```
- First read loads SST from disk -> normal warm-up behavior
- block cache default = system memory x 45%, check if configuration is reasonable

**Branch b: TiDB Cold Start**
```
metrics:
  plan_cache_miss: sum(rate(tidb_server_plan_cache_miss_total{tidb_cluster_id="{cluster_id}"}[2m]))
  auto_analyze: sum(rate(tidb_statistics_auto_analyze_total{tidb_cluster_id="{cluster_id}"}[2m]))

condition: plan_cache_miss rate 100% after restart or auto_analyze is running
```
- Statistics loading takes time
- auto-analyze just triggered

**Branch c: Serverless/Essential Cold Start (TiDB X only)**
- Instance scaling from zero (cold start latency = instance startup time)
- -> [MODULE-RCU](../../knowledge/rcu-check.md) check scaling events

### Step 3: Diagnosis + Recommendations

| Component | Diagnosis | Recommendation |
|-----------|-----------|----------------|
| TiKV | Block cache warm-up is normal | Can increase cache to speed up warm-up |
| TiDB | Plan cache/statistics loading | Configure pre-load |
| TiDB X | Serverless cold start | Set minimum instance > 0 to avoid scaling to zero |

---

## Data Source Call Templates

### P99 Latency (High Precision)
```
query: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))
step: 15
```

### Instance Uptime
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}"}
```

### TiKV Block Cache Size
```
query: tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### Block Cache Hit Rate
```
query: sum(rate(tikv_engine_block_cache_hit{tidb_cluster_id="{cluster_id}"}[2m])) / (sum(rate(tikv_engine_block_cache_hit{tidb_cluster_id="{cluster_id}"}[2m])) + sum(rate(tikv_engine_block_cache_miss{tidb_cluster_id="{cluster_id}"}[2m])))
```

### Auto Analyze Trigger
```
query: sum(rate(tidb_statistics_auto_analyze_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

---

## Remediation References

- Stats loading and startup behavior: [../references/stats-management.md](../references/stats-management.md)
- Stats configuration tuning: [../references/stats-management.md](../references/stats-management.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
