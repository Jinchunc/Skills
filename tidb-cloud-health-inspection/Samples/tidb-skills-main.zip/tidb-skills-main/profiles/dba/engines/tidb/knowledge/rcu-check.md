# MODULE-RCU: RCU Throttling Check

> Source: A1 TiDB X/Premium section
> Applicable: TiDB X product lines only (starter / essential / premium)
> Dedicated clusters skip this module

---

## Background

TiDB Cloud TiDB X (formerly Serverless / formerly TiDB-X) uses Request Capacity Unit (RCU) for resource metering:
- Read RCU: 0.475 RU/request + 1 RU/64KiB
- Write RCU: 2.55 RU/request + 1 RU/2KiB

When actual RCU consumption approaches or exceeds the provisioned limit, requests are throttled.

---

## Input
- cluster_id, product_line (from MODULE-CLUSTER-ID)
- time_range

## Output
- throttled: bool
- throttle_severity: NONE | MILD | SEVERE
- rcu_utilization: Actual / quota percentage
- evidence: Metrics supporting the judgment

---

## Decision Tree

```
Pre-check: product_line == DEDICATED?
  YES -> SKIP (Dedicated has no RCU limits)
  NO -> Determine sub-type (Starter/Essential vs Premium)

===============================================
Pre-Step: Get keyspace_id (Starter/Essential only)
===============================================

  Starter/Essential RCU metrics use keyspace_id (not cluster_id).
  Mapping method:
    1. clinic_search_cluster_by_id {cluster_id} -> Get orgID
    2. GET /clinic/api/v1/orgs/{orgID}/clusters/{cluster_id}
       -> Extract keyspaceID field from response JSON
    3. If API does not return keyspaceID -> fail-open: skip RCU metric check,
       fall back to inferring throttling from slow_query_logs (check rc_wait time)

===============================================
Branch A: Starter / Essential Clusters
===============================================

Step A1: Check Provisioned Capacity vs Limit Max RCU
  Pre-requisite: keyspace_id obtained from Pre-Step
  metrics:
    provisioned:
      sum(serverless_metering_rcu_provisioned_capacity{keyspace_id="{keyspace_id}"})
    limit:
      resource_manager_resource_unit_service_limit{
        namespace="tidb-serverless", name="{keyspace_id}"}
  condition:
    provisioned >= limit -> RCU-CAPPED (throttled)
    provisioned / limit > 0.8 -> Approaching throttle boundary
    provisioned / limit < 0.8 -> Normal

Step A2: Check RC Queue Wait
  metrics:
    rc_wait: (from slow_query_logs, the portion of total_time spent in RC queuing)
  condition:
    rc_wait_avg > 0 and sustained -> Confirms throttling in progress
    QPS curve flattens (plateau) -> Throughput capped by RCU

Step A3: Determine Throttling Severity
  provisioned = limit AND QPS plateau + rc_wait > 0:
    -> SEVERE: RCU capped, throughput ceiling
    -> DIAGNOSIS:
      a. Increase Provisioned Capacity (scaling-up)
      b. Optimize high RU consumption SQL (reduce KV request count and data volume)
         - Read: 0.475 RU/request + 1 RU/64KiB payload
         - Write: 2.55 RU/request + 1 RU/2KiB payload
      c. Split large queries, reduce per-scan volume

  provisioned approaching limit but not capped:
    -> MILD: Warning state
    -> DIAGNOSIS: Plan capacity expansion to avoid burst traffic hitting ceiling

===============================================
Branch B: Premium Clusters
===============================================

Step B1: Check KV Request Wait Duration
  metrics:
    kv_request_wait:
      histogram_quantile(0.99,
        sum(rate(resource_manager_client_request_success_bucket{
          tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  condition:
    kv_request_wait_p99 > 5ms -> Resource management queuing present
    kv_request_wait_p99 > 50ms -> Severe queuing

Step B2: Check Cop Worker Bottleneck
  Symptom: Concurrency Limiter Waiting Length persistently high
  Cause: Premium TiKV Cop workers cannot auto-scale
  Metrics:
    tikv_coprocessor_waiting_duration_seconds{tidb_cluster_id="{cluster_id}"} (P99)
    tikv_coprocessor_request_wait_seconds{tidb_cluster_id="{cluster_id}"} (P99)
  condition:
    Sustained queuing -> cop-side throughput limited
    -> DIAGNOSIS: Adjust Cop limiter or cache configuration (recommended for user execution)

===============================================
Common: Throttling Root Cause Analysis
===============================================

Step 3: High RCU Consumption Root Cause
  -> MODULE-SQL: Query Top SQL (sorted by total_keys / process_keys / mem_max)
  -> Focus on:
    a. Excessive BatchGet/Batch_Point_Get -> Missing index / too many IndexLookUp
    b. total_keys >> process_keys -> MVCC version accumulation
    c. Very high write_keys -> Bulk writes
  -> DIAGNOSIS:
    - Reduce KV request count (covering index, reduce table lookback)
    - Reduce KV data volume (select only needed columns, use LIMIT)
    - Balance workload (avoid hotspots)
```

---

## Product Line Specific Issue Quick Reference

| Issue | Product Line | Root Cause Clue | Recommendation |
|-------|-------------|-----------------|----------------|
| TiProxy gateway bottleneck | Essential | TiProxy CPU high, becoming bottleneck | Horizontally scale TiProxy nodes |
| Raftlog Disk IOPS insufficient | Essential | Disk IOPS hitting ceiling (default 500) | Increase raftlog disk IOPS, add TiKV nodes |
| Small/empty table hotspot | Essential | gRPC requests all hitting one TiKV, flow-control triggered | Pre-populate data, ensure leader distribution across multiple nodes |
| Cop worker cannot auto-scale | Premium | Concurrency Limiter Waiting persistently high | Adjust TiKV Cop limiter and cache configuration |

---

## Data Source Call Templates

### Starter/Essential: Provisioned Capacity vs Limit
```
query: sum(serverless_metering_rcu_provisioned_capacity{keyspace_id="{keyspace_id}"})
query: resource_manager_resource_unit_service_limit{namespace="tidb-serverless", name="{keyspace_id}"}
```

### Premium: KV Request Wait Duration
```
query: histogram_quantile(0.99, sum(rate(resource_manager_client_request_success_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Common: RCU Consumption Trend
```
query: sum(rate(tidb_server_request_unit_total{tidb_cluster_id="{cluster_id}"}[1m]))
```

### Common: Throttling Events
```
query: sum(rate(tidb_server_resource_control_throttled_total{tidb_cluster_id="{cluster_id}"}[1m]))
```

### TiKV-side Cop Queuing
```
query: histogram_quantile(0.99, sum(rate(tikv_coprocessor_request_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

---

## Known Limitations

1. **Essential/Starter metrics may return HTTP 500** — Some metrics are unavailable under the shared architecture. On 500 errors, fail-open and fall back to inferring from slow_query_logs
2. **keyspace_id parameter** — Starter/Essential RCU metrics require keyspace_id (not cluster_id), obtained from cluster metadata
3. **No direct rc_wait metric** — Must be inferred indirectly through time decomposition in slow_query_logs
