# Serverless Backup

Base command: `ticloud serverless backup`

Manage serverless cluster backups

## Direct Subcommands

- `ticloud serverless backup describe` - Describe a serverless cluster backup
- `ticloud serverless backup list` - List serverless cluster backups (human-output)
