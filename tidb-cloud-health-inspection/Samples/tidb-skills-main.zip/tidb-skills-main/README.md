# TiDB Skills

TiDB DBA 专业技能系统。从 [agent-stack](https://github.com/meiking/skills/agent-stack) 提取，专注于 TiDB 集群日常运维。

## 覆盖场景

| 场景 | 核心 Skill | 覆盖度 |
|------|-----------|--------|
| 集群巡检 | tidb-instance-inspection（45 项检查 + TiCDC 巡检） | 完整 |
| 周度巡检（固定口径） | `specs/*-weekly-inspection-spec.md` + instance-inspection playbooks | 完整 |
| 故障定位 | tidb-fault-diagnosis（13 类故障 + 188 案例库） | 完整 |
| 慢查询分析 | tidb-performance-optimization（20 条路径 + DB Time 分解） | 完整 |
| 版本升级 | tidb-ops-change-management（upgrade-runbook） | 部分 |
| 配置修改 | tidb-ops-change-management（config-change-review） | 完整 |

## 周度巡检 Spec

每个客户一份 spec，目标是**把整份 spec 粘贴给 agent，不追加口头补充，就能产出与既定报告同格式、同口径的结果**。因此 spec 里写死了标题层级、表格列名、固定行数、数字精度、排序规则与成稿自检命令。

| 客户 | 集群 | 交付物 | Spec |
|------|------|--------|------|
| TokenPocket | `tidb-hk-gb-1`（Essential / cn-hongkong） | 飞书 wiki 巡检报告 | [tokenpocket-weekly-inspection-spec.md](specs/tokenpocket-weekly-inspection-spec.md) |
| bitunix | `tidb-bu-growth-welfare`、`tidb-futuresv2` | 飞书 docx（含 10 张趋势图） | [bitunix-weekly-inspection-spec.md](specs/bitunix-weekly-inspection-spec.md) |
| UE Cassandra | `prod-cassandra-chat-on-TiKV`（Premium） | 巡检表新 sheet + summary 文档 | [ue-cassandra-weekly-inspection-spec.md](specs/ue-cassandra-weekly-inspection-spec.md) |

三份客户 spec 由 [weekly-inspection-orchestration-spec.md](specs/weekly-inspection-orchestration-spec.md) 编排：定义子任务并行、P0–P5 状态机、G1–G5 门禁（含“骨架比对”）、阻塞隔离与汇总模板。规范本身的 review 结论与机械校验记录见 [specs/reviews/](specs/reviews/)。

另一个独立任务是 [slow-query-digest-proposal-spec.md](specs/slow-query-digest-proposal-spec.md)：从飞书多维表格取慢查询 digest，做执行计划分析与优化建议，产出飞书文档。

## 项目结构

```
profiles/
  dba.yaml                         Profile 定义 + 技能清单
  dba/
    DISPATCH.md                    三层调度协议（Domain → Engine → Provider）
    GUARDRAILS.md                  安全护栏（操作分级）
    IDENTITY.md                    DBA 角色身份
    TOOLS.md                       工具生态 + MCP
    domains/                       9 个问题域（5 Covered + 4 Gap）
      INDEX.md                     域路由表
    engines/tidb/                  TiDB 引擎技能（422 文件）
      fault-diagnosis/             故障诊断（13 类故障路径）
      performance-optimization/    性能优化（20 条症状路径）
      instance-inspection/         实例巡检（45 项检查清单）
        playbooks/                 固定入口（bitunix 周检 / org 总览 / dedicated 日检）
      ops-change-management/       运维变更（升级/配置/扩缩容）
      knowledge/                   知识库（OnCall 经验、客户案例、产品线）
      references/                  PromQL 模板、诊断模式
    providers/tidb-cloud/          TiDB Cloud 集成（API/CLI/O11Y/Ops）
  _shared/                         所有 Profile 共享的行为规则

specs/                             可整份粘贴给 agent 执行的任务规范
  tokenpocket-weekly-inspection-spec.md
  bitunix-weekly-inspection-spec.md
  ue-cassandra-weekly-inspection-spec.md
  weekly-inspection-orchestration-spec.md
  slow-query-digest-proposal-spec.md
  reviews/                         Spec review 记录与校验结果

skills/                            21 个共享技能
  db-fundamentals/                 通用 SQL/查询优化
  db-fact-check/                   数据库行为验证（源码交叉比对）
  incident-response/               故障响应流程
  infrastructure-review/           基础设施审查
  observability-designer/          可观测性设计
  dashboard-builder/               Grafana 仪表板构建
  deep-research/                   深度调研
  evidence-grading/                证据分级
  jira-ops/                        Jira 工单操作
  doc-coauthoring/                 文档协作
  security-guardrail/              安全护栏
  verification-loop/               变更验证
  session-memory/                  会话记忆
  migration-planner/               迁移规划
  ...

analyze_digests.py                 慢查询 digest 批量分析脚本
scripts/
  build.sh                         技能包构建
  net_triage.sh                    网络问题快速排查
```

## 版本范围

TiDB 6.5–8.x（LTS 及近期 GA）。大部分诊断查询和系统视图兼容至 TiDB 5.4。

## 来源

本项目内容提取自 [agent-stack](https://github.com/meiking/skills/agent-stack) 的 DBA Profile，针对 TiDB DBA 日常工作场景裁剪。

## License

Private repository.
