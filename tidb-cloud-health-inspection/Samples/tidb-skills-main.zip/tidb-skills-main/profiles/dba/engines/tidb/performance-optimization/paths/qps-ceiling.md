# PATH-QPS-CEILING (S1.7 QPS Cannot Scale Up) <!-- Reason for change: unified as S1.x performance troubleshooting sub-number -->

> Entry condition: Adding pressure does not increase QPS but instead increases latency, e.g. "adding concurrency does not increase QPS but increases latency"

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. **Product line limitations**:
   - **Starter/Essential**: IOPS quota limits exist (typically 500), QPS bottleneck may originate from IOPS being maxed out.
   - **Dedicated**: Focus on compute-to-storage node specification matching.
3. Time range

---

## Decision Tree

### Step 1: TiDB X Throttling Check

→ [MODULE-RCU](../../knowledge/rcu-check.md)

RCU throttling → DIAGNOSIS "QPS ceiling = Max RCU quota" → END

### Step 2: Resource Bottleneck Check

```
metrics:
  tikv_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tikv"}[1m]) by (instance)
  tidb_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m]) by (instance)
  disk_write_latency: histogram_quantile(0.99, sum(rate(tikv_engine_write_micro_seconds_bucket{tidb_cluster_id="{cluster_id}", type="write_wal"}[2m])) by (le))

Some resource approaching limit:
  TiKV CPU > 80% x cores  → DIAGNOSIS "TiKV CPU bottleneck limiting QPS"
  TiDB CPU > 80% x cores  → DIAGNOSIS "TiDB CPU bottleneck limiting QPS"
  WAL write latency P99 > 10ms → DIAGNOSIS "IO bottleneck limiting QPS"
```

### Step 3: Lock/Hotspot Bottleneck

→ [MODULE-TIKV](../modules/tikv-fast-tune.md)
  - S1_BALANCE → hotspot? Single instance handling most requests
  - W_LATCH → lock conflict? High-concurrency writes to the same key

Single-point bottleneck → DIAGNOSIS "Hotspot/lock conflict limiting concurrency" → END

### Step 4: Thread Pool Bottleneck

```
metrics:
  cop_cpu:       sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"cop_.*"}[1m])) by (instance)
  raftstore_cpu: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"raftstore.*"}[1m])) by (instance)
  grpc_cpu:      sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"grpc_server_.*"}[1m])) by (instance)
  sched_cpu:     sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"sched-worker.*"}[1m])) by (instance)
  unified_cpu:   sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"unified-read-.*"}[1m])) by (instance)

Saturation thresholds (source: ../../knowledge/product-lines/dedicated.md):
  gRPC:              > 80% x grpc-concurrency (default 5, i.e. > 4.0 cores)
  Raftstore:         > 80% x store-pool-size (default 2, i.e. > 1.6 cores; keep < 120% when pool=2)
  Scheduler worker:  > 90% x scheduler-worker-pool-size (default 8 @>=16 cores, i.e. > 7.2 cores)
  Unified read pool: > 80% x thread count (default = CPU cores x 80%)
  Coprocessor:       observe whether running tasks are continuously growing

Some thread pool CPU approaching above thresholds → DIAGNOSIS "Thread pool bottleneck: {pool_name}" + recommend increasing thread count or scaling out (suggest user to execute)
```

→ [MODULE-TIDB](../modules/tidb-diagnosis.md) (TiDB side worker pool)

---

## Data Source Call Templates

### CPU by Component
```
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tikv"}[1m]) by (instance)
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m]) by (instance)
```

### TiKV Thread Pool CPU (By Instance+Thread Name)
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, name)
```

### gRPC Thread CPU
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"grpc_server_.*"}[1m])) by (instance)
```

### Raftstore Thread CPU
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"raftstore.*"}[1m])) by (instance)
```

### Scheduler Worker Thread CPU
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"sched-worker.*"}[1m])) by (instance)
```

### WAL Write Latency P99
```
query: histogram_quantile(0.99, sum(rate(tikv_engine_write_micro_seconds_bucket{tidb_cluster_id="{cluster_id}", type="write_wal"}[2m])) by (le))
```

---

## Remediation References

When root cause is concurrency or thread pool bottleneck:
- Session variables (concurrency settings): [../references/session-variables.md](../references/session-variables.md)
- TiKV troubleshooting (thread pool tuning): [../../knowledge/troubleshooting-guide.md](../../knowledge/troubleshooting-guide.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
