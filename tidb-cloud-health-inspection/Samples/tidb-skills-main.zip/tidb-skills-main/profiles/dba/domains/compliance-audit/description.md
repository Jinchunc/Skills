# Domain 7: 安全合规 (Security & Compliance Audit)

> Status: **Gap**
> Tier: B (Engine-weak)

## Core

目标集群的访问控制与合规审计。（Agent 自身行为由 security-guardrail 管控。）

## Scenarios

- IP 白名单配置核查
- 账号权限审计（过度授权检测）
- SSL/TLS 强制状态检查
- TDE 加密状态检查
- 审计日志完整性验证（断档检测）
- 密码策略合规检查
- 跨平台统一安全态势评估

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | — | Not yet built |
| MySQL | — | Not yet built |
| PostgreSQL | — | Not yet built |
| MongoDB | — | Not yet built |

## Shared Skills

- `skills/security-guardrail` — Agent 行为安全（非目标集群审计）

## Key Checks (to build)

- IP 白名单覆盖度
- 过度授权账号检测
- SSL/TLS 强制状态
- TDE 启用状态
- 审计日志断档检测
- 密码策略合规

## Routing Note

- 独立触发的深度合规审计 → 本域
- 巡检中安全项快速扫描 → 域3 (instance-inspection)
