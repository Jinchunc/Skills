// Audit Hook — logs all agent operations to daily JSONL files
//
// Provides compliance and debugging audit trail for all agent activity.
// Each entry is a single JSON line with timestamp, event type, and metadata.

import { writeFile, appendFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';

interface AuditEntry {
  ts: string;
  event: string;
  [key: string]: unknown;
}

// Default audit directory — override via AUDIT_DIR env var
const AUDIT_DIR = process.env.AUDIT_DIR || '/data/audit';

function getAuditFilePath(): string {
  const today = new Date().toISOString().split('T')[0];
  return join(AUDIT_DIR, `audit-${today}.jsonl`);
}

async function ensureDir(dir: string): Promise<void> {
  if (!existsSync(dir)) {
    await mkdir(dir, { recursive: true });
  }
}

async function logAudit(entry: AuditEntry): Promise<void> {
  await ensureDir(AUDIT_DIR);
  const filePath = getAuditFilePath();
  const line = JSON.stringify(entry) + '\n';

  if (existsSync(filePath)) {
    await appendFile(filePath, line, 'utf-8');
  } else {
    await writeFile(filePath, line, 'utf-8');
  }
}

export default {
  name: 'audit-hook',
  version: '1.0.0',

  hooks: {
    before_tool_call: async (context: Record<string, unknown>) => {
      await logAudit({
        ts: new Date().toISOString(),
        event: 'tool_call',
        tool: context.tool as string,
        user: (context.user as Record<string, unknown>)?.id as string,
      });
    },

    after_tool_call: async (context: Record<string, unknown>) => {
      await logAudit({
        ts: new Date().toISOString(),
        event: 'tool_result',
        tool: context.tool as string,
        ok: (context.result as Record<string, unknown>)?.ok ?? true,
        duration_ms: context.duration as number,
      });
    },

    message: async (context: Record<string, unknown>) => {
      await logAudit({
        ts: new Date().toISOString(),
        event: context.direction === 'in' ? 'message_in' : 'message_out',
        user: (context.user as Record<string, unknown>)?.id as string,
        preview: (context.text as string)?.substring(0, 100),
      });
    },
  },
};
