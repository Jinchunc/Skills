output "cluster_name" {
  value       = module.eks.cluster_name
  description = "EKS cluster name."
}

output "cluster_endpoint" {
  value       = module.eks.cluster_endpoint
  description = "EKS API endpoint."
}

output "oidc_provider_arn" {
  value       = module.eks.oidc_provider_arn
  description = "OIDC provider ARN for IRSA."
}

output "ebs_csi_role_arn" {
  value       = module.ebs_csi_irsa_role.iam_role_arn
  description = "IAM role ARN for EBS CSI controller."
}

output "node_security_group_id" {
  value       = module.eks.node_security_group_id
  description = "Shared security group for EKS worker nodes."
}

output "cluster_primary_security_group_id" {
  value       = module.eks.cluster_primary_security_group_id
  description = "EKS-managed cluster security group (control plane to data plane)."
}

output "cluster_certificate_authority_data" {
  value       = module.eks.cluster_certificate_authority_data
  description = "Base64-encoded certificate authority data for the EKS cluster API server."
  sensitive   = true
}
