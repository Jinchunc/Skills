---
name: redact
description: Strips sensitive data (credentials, tokens, PII, private keys) from agent outputs before delivery.
scope: all-profiles
---

## Purpose

Defense-in-depth data masking. Even if the agent fails to self-censor (agent Rule 6), this hook catches credentials, tokens, and PII in outbound messages and tool results.

## Patterns

| Category | What's Caught | Replacement |
|----------|--------------|-------------|
| Passwords | `password=`, `pwd:`, connection string passwords | `***REDACTED_PASSWORD***` |
| AWS Keys | `AKIA*`, `ASIA*`, secret access keys | `***REDACTED_AWS_KEY***` / `***REDACTED_SECRET***` |
| Tokens | Bearer tokens, GitHub/Slack/Jira tokens, `sk-*` | `***REDACTED_TOKEN***` |
| Generic Secrets | `api_key=`, `secret_key=`, `auth_token=` | `***REDACTED_SECRET***` |
| JWT | Base64-encoded JWT tokens | `***REDACTED_JWT***` |
| URL Params | `?token=`, `?api_key=`, `?secret=` | `?***REDACTED_PARAM***` |
| Email | Any email address | `***REDACTED_EMAIL***` |
| Private Keys | PEM-encoded private key blocks | `***REDACTED_PRIVATE_KEY***` |

## Extending for Deployment

The base patterns are generic. Deployments should add org-specific patterns:

```typescript
// Example: add internal URL redaction
REDACT_PATTERNS.push({
  name: 'internal_grafana',
  regex: /https?:\/\/[\w.-]*grafana\.internal\.example\.com\S*/gi,
  replace: '***REDACTED_INTERNAL_URL***',
});
```

## Hook Order

If both audit and redact hooks are active, audit should run first (to capture pre-redaction data for debugging), then redact runs on outbound content.

## What's NOT Redacted by Default

- IP addresses (commonly needed for infrastructure debugging)
- Hostnames (needed for routing/DNS diagnosis)
- Cluster IDs, instance IDs (operational identifiers)

Deployments with stricter requirements should add patterns for these.
