# PromQL Templates for TiDB Cluster Metrics

> **Usage**: Replace `{cluster_id}` with the actual TiDB Cloud cluster identifier.
> All queries use the label `tidb_cluster_id="{cluster_id}"` for cluster scoping.
> Adjust `rate()` window to match your step interval (e.g., `[1m]` for 1m step, `[5m]` for 5m step).

---

## 1. Cluster Overview

### 1.1 Total QPS (Queries Per Second)

- **Metric**: Total successful statement execution rate
- **PromQL**: `sum(rate(tidb_executor_statement_total{tidb_cluster_id="{cluster_id}"}[1m])) by (type)`
- **Metric choice note**: Two counters are easily confused —
  - `tidb_executor_statement_total` counts executed SQL **statements** by statement type (Select/Insert/Update/...). This is the canonical **QPS** metric (matches the TiDB dashboard "QPS" panel) and is the standard used across this profile.
  - `tidb_server_query_total` counts MySQL-protocol **commands** (COM_QUERY, COM_STMT_EXECUTE, ...) with a `result` label — i.e., **CPS** (Command Per Second, the dashboard "Command Per Second" panel). Use it only when you specifically need command-level throughput or OK/Error command ratios; do not mix it into QPS baselines.
- **Normal Range**: Varies by workload; baseline first. Sudden drops or spikes are noteworthy.
- **Anomaly Meaning**: A sharp QPS drop may indicate upstream connection issues, lock contention, or TiKV unavailability. A spike may precede latency degradation.
- **Related Diagnostic Path**: `paths/sql-slow`, `paths/conn-fail`

### 1.2 Query Duration P99

- **Metric**: 99th percentile query execution duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 500ms for OLTP workloads; < 5s for analytical queries
- **Anomaly Meaning**: P99 > 1s in OLTP indicates hot regions, lock waits, or resource saturation. Check TiKV gRPC and scheduler CPU.
- **Related Diagnostic Path**: `paths/sql-slow`

### 1.3 Query Duration P50

- **Metric**: Median query execution duration
- **PromQL**: `histogram_quantile(0.50, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 10ms for simple OLTP
- **Anomaly Meaning**: Rising P50 suggests systemic degradation, not just tail latency outliers.
- **Related Diagnostic Path**: `paths/sql-slow`

### 1.4 Failed Query Count

- **Metric**: Rate of failed SQL executions
- **PromQL**: `sum(rate(tidb_server_execute_error_total{tidb_cluster_id="{cluster_id}"}[1m])) by (type)`
- **Normal Range**: Near zero
- **Anomaly Meaning**: Non-zero error rate indicates query failures — check error type label for specifics (lock timeout, syntax, privilege).
- **Related Diagnostic Path**: `paths/query-error`

### 1.5 Active Connection Count

- **Metric**: Current active connections to TiDB
- **PromQL**: `sum(tidb_server_connections{tidb_cluster_id="{cluster_id}"}) by (instance)`
- **Normal Range**: Well below `max_connections` setting (default 0 = unlimited, but practical limit ~5000)
- **Anomaly Meaning**: Approaching limit causes connection refusals. Sudden spikes may indicate connection leak.
- **Related Diagnostic Path**: `paths/conn-fail`

### 1.6 Transaction OPS

- **Metric**: Transaction commit and rollback rate
- **PromQL**: `sum(rate(tidb_session_transaction_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[1m])) by (type, txn_mode)`
- **Normal Range**: Commit rate >> rollback rate. Rollback ratio < 5%.
- **Anomaly Meaning**: High rollback ratio signals lock conflicts or retry storms.
- **Related Diagnostic Path**: `paths/txn-conflict`

---

## 2. TiDB (SQL Layer)

### 2.1 Parse Duration

- **Metric**: SQL parse phase duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tidb_session_parse_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 1ms
- **Anomaly Meaning**: High parse time suggests extremely complex SQL or parser bottleneck. Rare.
- **Related Diagnostic Path**: `paths/sql-slow`

### 2.2 Compile Duration

- **Metric**: SQL compile/optimize phase duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tidb_session_compile_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 10ms
- **Anomaly Meaning**: Elevated compile time points to plan cache misses or overly complex query plans.
- **Related Diagnostic Path**: `paths/sql-slow`

### 2.3 Execute Duration

- **Metric**: SQL execution phase duration (post-optimization)
- **PromQL**: `histogram_quantile(0.99, sum(rate(tidb_session_execute_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 100ms for OLTP
- **Anomaly Meaning**: High execute time with normal parse/compile indicates TiKV bottleneck, large scans, or lock waits.
- **Related Diagnostic Path**: `paths/sql-slow`, `paths/cpu-high`, `paths/io-high`

### 2.4 Transaction Retry Count

- **Metric**: Rate of transaction retries
- **PromQL**: `sum(rate(tidb_session_retry_num{tidb_cluster_id="{cluster_id}"}[1m])) by (instance)`
- **Normal Range**: Near zero in optimistic mode; expected in pessimistic under contention
- **Anomaly Meaning**: Frequent retries indicate write-write conflicts. Check hot region distribution.
- **Related Diagnostic Path**: `paths/txn-conflict`, `paths/hotspot`

### 2.5 TiDB Memory Usage

- **Metric**: TiDB server process memory consumption
- **PromQL**: `process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"}`
- **Normal Range**: Below `server-memory-quota` (default: 80% of host memory)
- **Anomaly Meaning**: Approaching quota triggers memory GC; exceeding it causes OOM kills. Check expensive queries.
- **Related Diagnostic Path**: `paths/oom`

### 2.6 Slow Query Count

- **Metric**: Rate of queries exceeding slow-query threshold
- **PromQL**: `sum(rate(tidb_server_slow_query_process_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[1m]))`
- **Normal Range**: < 1/s under normal conditions
- **Anomaly Meaning**: Spike in slow queries correlates with latency issues. Cross-check with slow query log.
- **Related Diagnostic Path**: `paths/sql-slow`

### 2.7 Statement Memory Usage

- **Metric**: Per-statement peak memory consumption
- **PromQL**: `histogram_quantile(0.99, sum(rate(tidb_server_statement_mem_quota_exceeded_total_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: Well below `mem-quota-query` setting
- **Anomaly Meaning**: Queries exceeding memory quota are killed. Frequent occurrences suggest analytical queries on OLTP cluster.
- **Related Diagnostic Path**: `paths/oom`

---

## 3. TiKV (Storage Layer)

### 3.1 gRPC Message Duration (Get)

- **Metric**: TiKV gRPC get request duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="kv_get"}[1m])) by (le))`
- **Normal Range**: < 10ms
- **Anomaly Meaning**: High get latency indicates disk I/O issues, block cache misses, or CPU contention on TiKV.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`

### 3.2 gRPC Message Duration (Prewrite)

- **Metric**: TiKV gRPC prewrite request duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="kv_prewrite"}[1m])) by (le))`
- **Normal Range**: < 20ms
- **Anomaly Meaning**: Elevated prewrite latency points to raftstore pressure, write stalls, or disk saturation.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/throttle`

### 3.3 gRPC Message Duration (Commit)

- **Metric**: TiKV gRPC commit request duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="kv_commit"}[1m])) by (le))`
- **Normal Range**: < 20ms
- **Anomaly Meaning**: High commit latency with normal prewrite suggests Raft log apply bottleneck.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`

### 3.4 Scheduler CPU Usage

- **Metric**: TiKV scheduler thread CPU utilization
- **PromQL**: `sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"sched_.*"}[1m])) by (instance)`
- **Normal Range**: < 80% of allocated scheduler threads
- **Anomaly Meaning**: Saturated scheduler CPU causes write queueing. Consider scaling TiKV or reducing write load.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/disk-space`

### 3.5 Raftstore CPU Usage

- **Metric**: TiKV raftstore thread CPU utilization
- **PromQL**: `sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"raftstore_.*"}[1m])) by (instance)`
- **Normal Range**: < 80% of allocated raftstore threads
- **Anomaly Meaning**: Raftstore CPU saturation causes Raft proposal delays, affecting both reads and writes. May need region split or TiKV scale-out.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/hotspot`

### 3.6 Write Stall Count

- **Metric**: RocksDB write stall events
- **PromQL**: `sum(rate(tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, type)`
- **Normal Range**: 0
- **Anomaly Meaning**: Any write stall is a red flag. Indicates L0 file accumulation, pending compaction overflow, or memtable limit. Causes sudden latency spikes.
- **Related Diagnostic Path**: `paths/throttle`

### 3.7 Compaction Pending Bytes

- **Metric**: Bytes pending compaction in RocksDB
- **PromQL**: `sum(tikv_engine_pending_compaction_bytes{tidb_cluster_id="{cluster_id}"}) by (instance, db)`
- **Normal Range**: < 1 GiB; consistently rising is concerning
- **Anomaly Meaning**: Growing pending compaction means compaction cannot keep up with writes. Precursor to write stalls.
- **Related Diagnostic Path**: `paths/throttle`

### 3.8 Region Count per Store

- **Metric**: Number of regions on each TiKV store
- **PromQL**: `sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="region"}) by (instance)`
- **Normal Range**: < 30,000 per store (recommended); balanced across stores
- **Anomaly Meaning**: Imbalanced region distribution causes hot stores. Excessive region count (>50K) degrades heartbeat and scheduling performance.
- **Related Diagnostic Path**: `paths/hotspot`, `paths/disk-space`

### 3.9 Leader Count per Store

- **Metric**: Number of region leaders on each TiKV store
- **PromQL**: `sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="leader"}) by (instance)`
- **Normal Range**: Balanced across stores (within 10% variance)
- **Anomaly Meaning**: Leader imbalance causes uneven load distribution — one store handles disproportionate read/write traffic.
- **Related Diagnostic Path**: `paths/hotspot`

### 3.10 Block Cache Hit Rate

- **Metric**: RocksDB block cache hit ratio
- **PromQL**: `sum(rate(tikv_engine_cache_efficiency{tidb_cluster_id="{cluster_id}", type="block_cache_hit"}[1m])) / (sum(rate(tikv_engine_cache_efficiency{tidb_cluster_id="{cluster_id}", type="block_cache_hit"}[1m])) + sum(rate(tikv_engine_cache_efficiency{tidb_cluster_id="{cluster_id}", type="block_cache_miss"}[1m])))`
- **Normal Range**: > 95%
- **Anomaly Meaning**: Low hit rate causes excessive disk reads. May indicate working set exceeds cache size or full table scans.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`

### 3.11 Disk I/O Utilization

- **Metric**: Disk I/O utilization percentage for TiKV data disks
- **PromQL**: `rate(node_disk_io_time_seconds_total{tidb_cluster_id="{cluster_id}", instance=~"tikv.*"}[1m])`
- **Normal Range**: < 80%
- **Anomaly Meaning**: Sustained I/O at >80% causes read/write latency spikes. Check compaction and write stall metrics.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/disk-space`

### 3.12 Apply Log Duration

- **Metric**: Raft apply log duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tikv_raftstore_apply_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 100ms
- **Anomaly Meaning**: Slow apply indicates disk I/O bottleneck on the apply path. Correlate with disk utilization.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`

### 3.13 Commit Log Duration

- **Metric**: Raft commit log (append) duration
- **PromQL**: `histogram_quantile(0.99, sum(rate(tikv_raftstore_commit_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))`
- **Normal Range**: < 50ms
- **Anomaly Meaning**: Slow Raft log append points to WAL write latency — check disk I/O on Raft log disk.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`

---

## 4. PD (Placement Driver)

### 4.1 TSO Wait Duration

- **Metric**: Duration clients wait for a TSO (timestamp oracle) from PD
- **PromQL**: `histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[1m])) by (le))`
- **Normal Range**: < 5ms
- **Anomaly Meaning**: High TSO wait stalls every transaction start and commit. Indicates PD leader issues, network latency, or PD CPU saturation.
- **Related Diagnostic Path**: `paths/pd-issues`

### 4.2 Scheduling Rate

- **Metric**: Rate of PD scheduling operations
- **PromQL**: `sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[1m])) by (type, event)`
- **Normal Range**: Stable under normal conditions; spikes during scale-out or rebalance
- **Anomaly Meaning**: Excessive scheduling (especially `remove-peer`) during production hours indicates instability. Check store status.
- **Related Diagnostic Path**: `paths/pd-issues`, `paths/scaling`

### 4.3 Store Status

- **Metric**: Count of TiKV stores in each status
- **PromQL**: `pd_cluster_status{tidb_cluster_id="{cluster_id}", type=~"store_.*"}`
- **Normal Range**: All stores `up`; zero in `disconnected`, `down`, `offline`, or `tombstone`
- **Anomaly Meaning**: Any store not `up` means reduced redundancy or active data migration. Investigate immediately.
- **Related Diagnostic Path**: `paths/store-failure`, `paths/pd-issues`

### 4.4 Region Health

- **Metric**: Unhealthy region counts
- **PromQL**: `pd_regions_status{tidb_cluster_id="{cluster_id}", type=~"miss-peer-region-count|extra-peer-region-count|pending-peer-region-count"}`
- **Normal Range**: Zero for miss-peer and extra-peer; pending-peer near zero (transient during scheduling)
- **Anomaly Meaning**: Miss-peer regions have reduced fault tolerance. Persistent pending peers indicate slow snapshot or network issues.
- **Related Diagnostic Path**: `paths/pd-issues`, `paths/store-failure`

### 4.5 PD Leader Changes

- **Metric**: PD leader election events
- **PromQL**: `changes(pd_tso_events{tidb_cluster_id="{cluster_id}", type="save"}[5m])`
- **Normal Range**: 0 (stable leader)
- **Anomaly Meaning**: Frequent PD leader changes cause TSO disruption and scheduling pauses. Check PD node health and network.
- **Related Diagnostic Path**: `paths/pd-issues`

---

## 5. Resource

### 5.1 CPU Utilization (TiDB)

- **Metric**: TiDB process CPU usage
- **PromQL**: `rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m])`
- **Normal Range**: < 80% of allocated CPU cores
- **Anomaly Meaning**: CPU saturation causes query queueing and latency spikes. Check for expensive queries or sudden QPS increase.
- **Related Diagnostic Path**: `paths/disk-space`, `paths/sql-slow`

### 5.2 CPU Utilization (TiKV)

- **Metric**: TiKV process CPU usage
- **PromQL**: `rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tikv"}[1m])`
- **Normal Range**: < 80% of allocated CPU cores
- **Anomaly Meaning**: TiKV CPU saturation indicates heavy compaction, coprocessor scans, or raftstore pressure.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/disk-space`

### 5.3 CPU Utilization (PD)

- **Metric**: PD process CPU usage
- **PromQL**: `rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m])`
- **Normal Range**: < 60% — PD is typically lightweight
- **Anomaly Meaning**: PD CPU saturation impacts TSO and scheduling. Usually caused by excessive region heartbeats (>100K regions).
- **Related Diagnostic Path**: `paths/pd-issues`

### 5.4 Memory Utilization (TiDB)

- **Metric**: TiDB process resident memory
- **PromQL**: `process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"}`
- **Normal Range**: Below memory quota setting; trending stable
- **Anomaly Meaning**: Monotonic growth without plateau indicates memory leak. Sudden spikes correlate with expensive queries.
- **Related Diagnostic Path**: `paths/oom`

### 5.5 Memory Utilization (TiKV)

- **Metric**: TiKV process resident memory
- **PromQL**: `process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"}`
- **Normal Range**: Dominated by block cache size + raft engine memory; should be stable
- **Anomaly Meaning**: Unexpected growth outside block cache may indicate region metadata overhead (too many regions) or memory leak.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/oom`

### 5.6 Disk Usage

- **Metric**: Disk space used vs available for TiKV data
- **PromQL**: `tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="used"} / tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="capacity"}`
- **Normal Range**: < 80%
- **Anomaly Meaning**: > 80% triggers PD to stop scheduling new regions to the store. > 90% is critical — risk of write failures.
- **Related Diagnostic Path**: `paths/disk-space`

### 5.7 Disk Write Throughput (TiKV)

- **Metric**: Disk write bytes per second
- **PromQL**: `rate(node_disk_written_bytes_total{tidb_cluster_id="{cluster_id}", instance=~"tikv.*"}[1m])`
- **Normal Range**: Below disk throughput limit; balanced across stores
- **Anomaly Meaning**: Sustained high write throughput correlates with compaction storms or write-heavy workloads. Check write stall.
- **Related Diagnostic Path**: `paths/cpu-high`, `paths/io-high`, `paths/throttle`

### 5.8 Network Traffic (In)

- **Metric**: Inbound network bytes per second
- **PromQL**: `rate(node_network_receive_bytes_total{tidb_cluster_id="{cluster_id}", device!="lo"}[1m])`
- **Normal Range**: Well below NIC bandwidth limit
- **Anomaly Meaning**: Network saturation causes gRPC timeouts, Raft message delays, and replication lag.
- **Related Diagnostic Path**: `paths/net-latency`, `paths/net-traffic`

### 5.9 Network Traffic (Out)

- **Metric**: Outbound network bytes per second
- **PromQL**: `rate(node_network_transmit_bytes_total{tidb_cluster_id="{cluster_id}", device!="lo"}[1m])`
- **Normal Range**: Well below NIC bandwidth limit
- **Anomaly Meaning**: High outbound on TiKV may indicate large scan results or snapshot transfers during region scheduling.
- **Related Diagnostic Path**: `paths/net-latency`, `paths/net-traffic`, `paths/scaling`

---

## Quick Reference: Anomaly-to-Template Mapping

| Symptom | Start With Templates |
|---------|---------------------|
| Slow queries | 1.2, 1.3, 2.1, 2.2, 2.3, 3.1 |
| High error rate | 1.4, 1.5, 4.3, 4.4 |
| Write latency spike | 3.2, 3.3, 3.6, 3.7, 3.5 |
| Read latency spike | 3.1, 3.10, 3.11, 5.2 |
| OOM / memory issues | 2.5, 2.7, 5.4, 5.5 |
| Transaction conflicts | 1.6, 2.4, 3.8, 3.9 |
| PD / TSO issues | 4.1, 4.2, 4.3, 4.5, 5.3 |
| Capacity planning | 1.1, 3.8, 5.1, 5.2, 5.6, 5.7 |
| Store failure | 4.3, 4.4, 3.8, 3.9, 4.2 |
| Disk pressure | 3.6, 3.7, 3.11, 5.6, 5.7 |
