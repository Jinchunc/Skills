# PATH-CPU-HIGH (S1.9 Abnormally High CPU)

> Entry condition: CPU utilization is high relative to baseline (not necessarily maxed out)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

> **Field correction:** Use `tikv_server_cpu_cores_quota` for actual CPU core count per TiKV node — do NOT estimate from utilization percentages (#2). See [field-corrections.md](../../knowledge/field-corrections.md).

---

## Decision Tree

### Step 1: Determine Which Component Has High CPU

```
metrics:
  tidb_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{job="tidb", tidb_cluster_id="{cluster_id}"}[1m]) by (instance)
  tikv_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{job="tikv", tidb_cluster_id="{cluster_id}"}[1m]) by (instance)
  pd_cpu{tidb_cluster_id="{cluster_id}"}:   rate(process_cpu_seconds_total{job="pd", tidb_cluster_id="{cluster_id}"}[1m]) by (instance)

routing: Follow the branch for whichever component is high
```

### Step 2a: TiDB CPU High

```
Check if QPS also increased:
  qps: sum(rate(tidb_executor_statement_total{tidb_cluster_id="{cluster_id}"}[2m]))
  (QPS metric standard: tidb_executor_statement_total = statement-level QPS;
   tidb_server_query_total = command-level CPS. See ../../references/promql-templates.md 1.1)
  Proportional increase = traffic growth
  Disproportionate = efficiency issue

Check parse/compile ratio:
  compile_cpu: tidb_session_compile_duration_seconds{tidb_cluster_id="{cluster_id}"}
  High -> Plan Cache miss

Check large queries:
  -> MODULE-SQL: Check total_keys / mem_max Top SQL

Check connection imbalance:
  per_instance_qps: sum(rate(tidb_executor_statement_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
  One instance too high -> LB issue
```

-> [MODULE-TIDB](../modules/tidb-diagnosis.md)

### Step 2b: TiKV CPU High

```
metrics:
  thread_cpu: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (name)

CRITICAL: Must decompose by (instance, name) two dimensions, cannot only look at total CPU

Route by thread pool (thresholds from: ../../knowledge/product-lines/dedicated.md + tikv-fast-tune module):
  grpc_server_* high  -> gRPC thread bottleneck
    Threshold: total CPU > 80% x grpc-concurrency (default 5, i.e. > 4.0 cores)
    Case: In TCOC-4831, gRPC avg CPU 4.58 caused global latency increase
    -> DIAGNOSIS "gRPC thread CPU saturated" + recommend increasing grpc-concurrency or scaling out TiKV (suggest user to execute)
  raftstore_* high    -> MODULE-TIKV W_RAFTSTORE
    Threshold: > 80% x store-pool-size (default 2, i.e. > 1.6 cores; keep < 120% when pool=2)
  sched-worker-* high -> Scheduler bottleneck -> MODULE-TIKV W_SCHEDULER
    Threshold: > 90% x scheduler-worker-pool-size (default 8 @>=16 cores, i.e. > 7.2 cores)
  unified-read-* high -> High read pressure
    Threshold: > 80% x thread count (default = CPU cores x 80%); recommended to keep in 60%-90% range
  cop_* high          -> MODULE-TIKV R2A_COPR_THREADS
  rocksdb:* high      -> Compaction -> MODULE-TIKV S3_COMPACTION_FLOW

Instance imbalance:
  tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"} by (instance, name)
  One instance with a thread pool much higher than others -> PATH-HOTSPOT
  All instances uniformly increasing -> Overall load growth
```

-> [MODULE-TIKV](../modules/tikv-fast-tune.md)

### Step 2c: PD CPU High

```
Check Region count (too many heartbeats):
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="region_count"}

Check TSO processing volume
```

-> [MODULE-PD](../modules/pd-diagnosis.md)

-> DIAGNOSIS -> END

---

## Data Source Call Templates

### Per-Component CPU
```
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tikv"}[1m]) by (instance)
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m]) by (instance)
```

### TiKV Thread Pool CPU (Aggregated by Thread Name)
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (name)
```

### TiKV Thread Pool CPU (By Instance + Thread Name, Detect Instance Imbalance)
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, name)
```

### TiKV gRPC Thread CPU (Critical Check)
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"grpc_server_.*"}[1m])) by (instance)
```

---

## Remediation References

When root cause is SQL-driven CPU (Step 2a large queries), load the relevant tuning reference:
- Full remediation routing table: [../modules/sql-diagnosis.md — Remediation section](../modules/sql-diagnosis.md#remediation--tuning-references)
- TiKV thread pool tuning: [../modules/tikv-fast-tune.md](../modules/tikv-fast-tune.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
