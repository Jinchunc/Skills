# Configuration

Base command: `ticloud config`

Configure and manage your user profiles

## Direct Subcommands

- `ticloud config create` - Configure a user profile to store settings
- `ticloud config delete` - Delete a profile (dangerous)
- `ticloud config describe` - Describe a specific profile
- `ticloud config edit` - Open the config file with the default text editor (sensitive)
- `ticloud config list` - List all profiles
- `ticloud config set` - Configure specific properties of the active profile (sensitive)
- `ticloud config use` - Use the specified profile as the active profile (sensitive)

## Confirmation Required

- `ticloud config delete`
