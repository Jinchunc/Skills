output "vpc_id" {
  value       = module.network.vpc_id
  description = "VPC ID."
}

output "private_subnet_ids" {
  value       = module.network.private_subnet_ids
  description = "Private subnet IDs."
}

output "eks_cluster_name" {
  value       = module.eks.cluster_name
  description = "EKS cluster name."
}

output "eks_cluster_endpoint" {
  value       = module.eks.cluster_endpoint
  description = "EKS cluster API endpoint."
}

output "ebs_csi_role_arn" {
  value       = module.eks.ebs_csi_role_arn
  description = "IAM role ARN used by EBS CSI add-on."
}

output "tidb_x_s3_irsa_role_arn" {
  value       = module.tidb_x.s3_irsa_role_arn
  description = "IRSA IAM role ARN for the tidb-x S3 ServiceAccount."
}

output "tidb_x_cluster_name" {
  value       = module.tidb_x.cluster_name
  description = "Deployed TiDB cluster name."
}

output "tidb_x_operator_namespace" {
  value       = module.tidb_x.operator_namespace
  description = "Namespace where tidb-operator is deployed."
}

output "tidb_x_cluster_namespace" {
  value       = module.tidb_x.cluster_namespace
  description = "Namespace where the TiDB cluster CRD instances are deployed."
}

