#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Usage:
  install_cse_worker.sh [--plan|--apply]

Runs on the control host. Distributes tikv-worker and cse-worker.toml to every
TiKV host, installs cse-worker.service, starts it, and waits for /healthz.
Defaults to --plan.
USAGE
}

action="${1:---plan}"
case "$action" in
  --plan) apply=0 ;;
  --apply) apply=1 ;;
  --help) usage; exit 0 ;;
  *) usage; exit 1 ;;
esac

SSH_USER="${SSH_USER:-admin}"
WORKER_TARBALL="${WORKER_TARBALL:-$HOME/bin/tikv-worker.tar.gz}"
WORKER_CONFIG="${WORKER_CONFIG:-/tmp/cse-worker.toml}"
SSH_OPTS_DEFAULT="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
SSH_OPTS="${SSH_OPTS:-$SSH_OPTS_DEFAULT}"

require_env TIKV_HOSTS

if [ "$apply" -eq 0 ]; then
  cat <<EOF
PLAN ONLY: no remote worker files will be changed.
To apply on the control host, rerun: $0 --apply

Will install:
  worker tarball: $WORKER_TARBALL
  worker config:  $WORKER_CONFIG
  SSH user:       $SSH_USER
  SSH key:        ${SSH_KEY_PATH:-<agent/default ssh identity>}
  TiKV hosts:     $TIKV_HOSTS
EOF
  exit 0
fi

need_cmd scp
need_cmd ssh
need_cmd tar
need_cmd mktemp

[ -f "$WORKER_TARBALL" ] || die "missing worker tarball: $WORKER_TARBALL"
[ -f "$WORKER_CONFIG" ] || die "missing worker config: $WORKER_CONFIG"

ssh_args=()
if [ -n "$SSH_OPTS" ]; then
  # shellcheck disable=SC2206
  ssh_args=($SSH_OPTS)
fi
if [ -n "${SSH_KEY_PATH:-}" ]; then
  [ -f "$SSH_KEY_PATH" ] || die "missing SSH key: $SSH_KEY_PATH"
  ssh_args+=(-i "$SSH_KEY_PATH")
fi

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT
tar -xzf "$WORKER_TARBALL" -C "$tmp_dir" tikv-worker
chmod +x "$tmp_dir/tikv-worker"

cat > "$tmp_dir/cse-worker.service" <<'UNIT'
[Unit]
Description=CSE TiKV Worker
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=admin
Group=admin
ExecStart=/home/admin/bin/tikv-worker --config /home/admin/cse-worker.toml
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
UNIT

for host in $TIKV_HOSTS; do
  log "Installing cse-worker on $host"
  run_step "upload worker $host" 300 \
    scp "${ssh_args[@]}" \
      "$tmp_dir/tikv-worker" "$WORKER_CONFIG" "$tmp_dir/cse-worker.service" \
      "$SSH_USER@$host:/tmp/"

  run_step "install worker $host" 300 \
    ssh "${ssh_args[@]}" "$SSH_USER@$host" '
      set -e
      sudo systemctl stop cse-worker 2>/dev/null || true
      mkdir -p /home/admin/bin /home/admin/cse-worker-data
      install -m 0755 /tmp/tikv-worker /home/admin/bin/tikv-worker
      install -m 0644 /tmp/cse-worker.toml /home/admin/cse-worker.toml
      sudo mv /tmp/cse-worker.service /etc/systemd/system/cse-worker.service
      sudo systemctl daemon-reload
      sudo systemctl enable --now cse-worker
      systemctl is-active cse-worker
      for _ in $(seq 1 30); do
        curl -sf http://127.0.0.1:9500/healthz && exit 0
        sleep 1
      done
      journalctl -u cse-worker --no-pager -n 80
      exit 1
    '
done

log "cse-worker installed on all TiKV hosts"
