# Serverless Audit Log Config

Base command: `ticloud serverless audit-log config`

Manage TiDB Cloud Serverless database audit logging configuration

## Direct Subcommands

- `ticloud serverless audit-log config describe` - Describe the database audit logging configuration
- `ticloud serverless audit-log config update` - Update the database audit logging configuration (sensitive)
