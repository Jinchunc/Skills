# PATH-THROTTLE (S1.8 Throttled) <!-- Modification reason: Unified as S1.x performance investigation sub-number -->

> Entry condition: Explicit throttling (RCU throttling / flow control / server is busy)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Branch 1: TiDB X RCU Throttling

→ [MODULE-RCU](../../knowledge/rcu-check.md)

Confirm RCU consumed ≈ limit → DIAGNOSIS + recommend increasing quota

### Branch 2: TiKV Flow Control

```
metrics:
  flow_control: sum(rate(tikv_scheduler_flow_control_actions_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
  write_stall:  sum(rate(tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
  l0_files:     tikv_engine_num_files_at_level{tidb_cluster_id="{cluster_id}", level="0"}

condition: flow_control rate > 0 or write_stall rate > 0
YES:
  l0_files >= 20 (level0-slowdown-writes-trigger default) → "L0 SST accumulation triggered flow control"
  pending_compaction_bytes > 192GB (soft-pending-compaction-bytes-limit default) → "Compaction falling behind triggered throttling"
  → MODULE-TIKV S2_WRITE_STALL → S2A_STALL_CAUSE
  → Identify stall root cause (L0 accumulation / pending compaction / memtable)
```

→ [MODULE-TIKV](../modules/tikv-fast-tune.md) S2_WRITE_STALL

### Branch 3: Server is Busy

```
metrics:
  server_busy:    sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}", type="server_is_busy"}[2m])) by (instance)
  raftstore_cpu:  sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"raftstore.*"}[1m])) by (instance)
  sched_too_busy: sum(rate(tikv_scheduler_too_busy_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

condition: server_busy rate > 0
YES:
  raftstore_cpu > 80% × store-pool-size (default 2, i.e., > 1.6; pool=2 means > 120%) → "Raftstore overloaded"
  sched_too_busy > 0 → "Scheduler overloaded"
  → MODULE-TIKV W_RAFTSTORE / W_SCHEDULER
```

→ DIAGNOSIS + END

---

## Data Source Call Templates

### Flow Control Actions
```
query: sum(rate(tikv_scheduler_flow_control_actions_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
```

### Write Stall
```
query: sum(rate(tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
```

### L0 File Count
```
query: tikv_engine_num_files_at_level{tidb_cluster_id="{cluster_id}", level="0"} by (instance)
```

### Pending Compaction Bytes
```
query: tikv_engine_pending_compaction_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### Server is Busy
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}", type="server_is_busy"}[2m])) by (instance)
```

### Raftstore CPU
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"raftstore.*"}[1m])) by (instance)
```

### Scheduler Too Busy
```
query: sum(rate(tikv_scheduler_too_busy_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
```

---

## Remediation References

- TiKV troubleshooting (write stall, flow control, thread pool): [../../knowledge/troubleshooting-guide.md](../../knowledge/troubleshooting-guide.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
