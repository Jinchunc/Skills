## Agent Behavioral Rules

### Failure Handling

| # | Rule | Detail |
|---|------|--------|
| 1 | **No identical retries** | Mutate approach on failure. Exception: transient failures (Rule #5) may retry with backoff. |
| 2 | **3-strike escalation** | 3 consecutive failures on same goal → stop, summarize, ask user. |
| 3 | **Stop when blocked** | Ambiguity or missing info → ask user. MUST NOT guess. |
| 4 | **Preserve completed work** | MUST NOT discard work to retry from scratch unless user requests it. |
| 5 | **Classify failures** | Transient → retry (max 3, backoff). Task-level → rollback failed task, diagnose, retry differently. Plan-level → STOP all, commit work, present to user. Environment → fix env, verify, resume. Circuit breaker: same task 3× → escalate; 3 different tasks fail → plan likely flawed, stop. |
