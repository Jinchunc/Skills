# PATH-PD-ISSUES (PD Placement Driver Issues)

> Entry condition: TSO latency spike / scheduling anomaly / PD leader flapping / region health degradation

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Check PD Leader Stability

```
metrics:
  leader_changes: changes(pd_tso_events{tidb_cluster_id="{cluster_id}", type="save"}[5m])

0 changes → leader stable → Step 2
>0 changes → leader flapping → Branch A
```

### Branch A: PD Leader Flapping

- Check PD node health: `process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="pd"}` by instance
- Check PD CPU: `rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m])` by instance
- Check network between PD nodes → [PATH-NET-LATENCY](../../performance-optimization/paths/net-latency.md)
- Disk I/O on PD etcd data dir (WAL write latency)

→ DIAGNOSIS: PD node resource exhaustion / network partition / disk bottleneck

### Step 2: Check TSO Latency

```
metrics:
  tso_wait: histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[1m])) by (le))

< 5ms → normal → Step 3
> 5ms → TSO bottleneck → check PD CPU + network latency to PD leader
```

### Step 3: Check Scheduling Health

```
metrics:
  sched_ops: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[1m])) by (type, event)

Excessive remove-peer during production → scheduling storm
  → Check if store going offline → [PATH-STORE-FAILURE](store-failure.md)
  → Check if manual schedule limit too aggressive
No scheduling when expected (region imbalance persists) → PD scheduler disabled or store limit = 0
```

### Step 4: Check Region Health

```
metrics:
  miss_peer: pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"}
  extra_peer: pd_regions_status{tidb_cluster_id="{cluster_id}", type="extra-peer-region-count"}
  pending_peer: pd_regions_status{tidb_cluster_id="{cluster_id}", type="pending-peer-region-count"}

miss-peer > 0 → reduced fault tolerance → check store status
extra-peer > 0 → scheduling lag → check PD scheduler
pending-peer sustained > 0 → slow snapshot → check TiKV I/O + network
```

→ DIAGNOSIS + recommendations: fix PD leader stability / adjust scheduler config / investigate store health

---

## Data Source Call Templates

### PD Leader Changes
```
query: changes(pd_tso_events{tidb_cluster_id="{cluster_id}", type="save"}[5m])
```

### TSO Wait Duration P99
```
query: histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[1m])) by (le))
```

### PD CPU Usage
```
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m]) by (instance)
```

### Scheduling Rate by Type
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[1m])) by (type, event)
```

### Region Health Status
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type=~"miss-peer-region-count|extra-peer-region-count|pending-peer-region-count"}
```

### Store Status
```
query: pd_cluster_status{tidb_cluster_id="{cluster_id}", type=~"store_.*"}
```
