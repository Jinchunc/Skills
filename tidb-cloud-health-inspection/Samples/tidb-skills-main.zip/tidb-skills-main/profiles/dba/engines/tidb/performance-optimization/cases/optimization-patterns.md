# Optimization Patterns — Case Studies

Concrete optimization patterns with real scenarios, SQL examples, and explainable outcomes.

---

## Case: Use Clustered Primary Key to Reduce PointGet or BatchPointGet RPC


## Symptom

- Query plan shows `Point_Get` or `Batch_Point_Get`, but latency is still higher than expected.
- `EXPLAIN ANALYZE` shows `Get:{num_rpc:2,...}` for primary-key lookup.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema (`SHOW CREATE TABLE`), especially whether the primary key is `CLUSTERED` or `NONCLUSTERED`.

## Plan Signature

- Bottleneck operator is `Point_Get` or `Batch_Point_Get`.
- Access object looks like `table:..., index:PRIMARY(...)` on a non-clustered primary-key table.
- Runtime shows double-read behavior (`Get:{num_rpc:2,...}`), indicating one read for primary-key index lookup and one read for table row fetch.

## Diagnosis

- This is usually a schema layout issue rather than a bad operator choice.
- For non-clustered primary-key tables, point lookup by primary key may require 2 RPCs.
- For clustered primary-key tables, the same lookup can be completed in 1 RPC.
- The same principle applies to both `PointGet` and `BatchPointGet`.

## Suggestions (Strict Order)

1. Binding or hints first.
   - Usually not effective for reducing this specific `PointGet`/`BatchPointGet` double-read pattern when the root cause is non-clustered storage layout.
2. Add new index.
   - Usually not the right fix for this pattern.
3. Rewrite query or schema.
   - If workload is dominated by primary-key point lookups, prefer clustered primary key table design.
   - For existing non-clustered tables, consider schema migration (rebuild into a clustered primary-key table) when benefit justifies migration cost.

## Example

```sql
create table t_non_clustered (a int, b int, c int, primary key(a) nonclustered);
create table t_clustered (a int, b int, c int, primary key(a) clustered);
insert into t_non_clustered values (1, 1, 1);
insert into t_clustered values (1, 1, 1);
```

```sql
mysql> explain analyze select * from t_non_clustered where a=1;
+-------------+---------+---------+------+-----------------------------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+---------------+--------+------+
| id          | estRows | actRows | task | access object                           | execution info                                                                                                                                                                                                                                                                                                                                                                                                                        | operator info | memory | disk |
+-------------+---------+---------+------+-----------------------------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+---------------+--------+------+
| Point_Get_1 | 1.00    | 1       | root | table:t_non_clustered, index:PRIMARY(a) | time:347.3µs, open:792ns, close:3.79µs, loops:2, RU:0.96, Get:{num_rpc:2, total_time:312.4µs}, time_detail: {total_process_time: 34.9µs, total_wait_time: 55.1µs, total_kv_read_wall_time: 95.6µs, tikv_grpc_process_time: 3.96µs, tikv_grpc_wait_time: 26.5µs, tikv_wall_time: 130.8µs}, scan_detail: {total_process_keys: 2, total_process_keys_size: 89, total_keys: 2, get_snapshot_time: 28.4µs, rocksdb: {block: {}}}           |               | N/A    | N/A  |
+-------------+---------+---------+------+-----------------------------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+---------------+--------+------+
```

```sql
mysql> explain analyze select * from t_clustered where a=1;
+-------------+---------+---------+------+-------------------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+---------------+--------+------+
| id          | estRows | actRows | task | access object     | execution info                                                                                                                                                                                                                                                                                                                                                                                                                   | operator info | memory | disk |
+-------------+---------+---------+------+-------------------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+---------------+--------+------+
| Point_Get_1 | 1.00    | 1       | root | table:t_clustered | time:187µs, open:625ns, close:5.96µs, loops:2, RU:0.48, Get:{num_rpc:1, total_time:168.3µs}, time_detail: {total_process_time: 14.8µs, total_wait_time: 36.8µs, total_kv_read_wall_time: 53.7µs, tikv_grpc_process_time: 1.96µs, tikv_grpc_wait_time: 8.79µs, tikv_wall_time: 64.2µs}, scan_detail: {total_process_keys: 1, total_process_keys_size: 41, total_keys: 1, get_snapshot_time: 12µs, rocksdb: {block: {}}}           | handle:1      | N/A    | N/A  |
+-------------+---------+---------+------+-------------------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+---------------+--------+------+
```

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm `Get:{num_rpc:...}` decreases (for example, from `2` to `1`).
- Confirm total latency and RU for `Point_Get`/`Batch_Point_Get` improve.

---

## Case: Use Covering Index for `WHERE ... ORDER BY ...`


## Symptom

- Query has selective filters plus sorting, for example `WHERE a = ? AND b = ? ORDER BY c`.
- Plan shows extra sort cost or double-read lookup cost.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema and existing indexes.

## Plan Signature

- Filter columns and order-by columns are not aligned in one good index.
- Plan may include `Sort` on filtered rows or `IndexLookUp` with extra table reads.
- Bottleneck operator is sort-heavy or lookup-heavy.

## Diagnosis

- This is a potential plan/access-path problem.
- A covering index that matches filter prefix and order key can reduce lookup and sort overhead.

## Suggestions (Strict Order)

1. Binding or hints first.
   - If a suitable existing index already exists, guide user to force it with hints/bindings first.
2. Add new index.
   - Consider index like `idx(a, b, c)` for query shape `WHERE a = ? AND b = ? ORDER BY c`.
   - Ensure no duplicated index recommendation (left-prefix duplicates).
3. Rewrite query.
   - Reduce selected columns and simplify ordering requirements when possible.

## Example

- Query:
  - `SELECT c FROM t WHERE a = ? AND b = ? ORDER BY c;`
- Better index candidate:
  - `idx(a, b, c)`
- Why:
  - `a, b` support filtering.
  - `c` supports ordered access and can help avoid extra sort.
  - When selected columns are covered, it can also avoid double-read lookup.

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm reduced sort/lookup cost and lower total latency.
- Confirm no duplicated-index recommendation is introduced.

---

## Case: Use Covering Index to Avoid Double Scan


## Symptom

- Query is slow and plan shows `IndexLookUp`/double-read pattern.
- `EXPLAIN ANALYZE` shows high time in lookup/table-read side.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema (`SHOW CREATE TABLE`) and existing indexes.

## Plan Signature

- Bottleneck operator is `IndexLookUp` (or lookup-related path).
- Large gap between scanned rows and returned rows, with heavy table row fetch cost.
- Current index cannot cover all needed columns.

## Diagnosis

- This is usually a query plan problem (access path not ideal).
- Goal is to avoid table lookup by using a covering index when possible.

## Suggestions (Strict Order)

1. Binding or hints first.
   - If a better existing covering index already exists, guide user to force it by hint/binding first.
   - Example: `/*+ USE_INDEX(t, idx_a_b_c) */`.
2. Add new index.
   - Recommend a covering index only if no suitable existing index can cover predicates and required columns.
   - Avoid duplicated indexes: do not recommend a shorter prefix when a longer useful index already exists.
3. Rewrite query.
   - Reduce selected columns when possible to make existing index covering.

## Example

- Query:
  - `SELECT c FROM t WHERE a = ? AND b > ?;`
- Existing index:
  - `idx_a_b(a, b)` (not covering for selected column `c`)
- Better index candidate:
  - `idx_a_b_c(a, b, c)` (covering)
- Expected impact:
  - Shift from double-read lookup path toward index-only read path.

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm lower total time and lower lookup/table-read cost.
- Confirm no duplicated-index recommendation is introduced.

---

## Case: Use IndexMerge for DNF Predicates


## Symptom

- Query has DNF predicates like `WHERE a = ? OR b = ? OR c > ?`.
- Current plan scans too many rows or falls back to table scan.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema and existing indexes.

## Plan Signature

- Predicate contains multiple `OR` branches.
- Single-index access path is not selective enough for all branches.
- Bottleneck operator is scan-heavy and row filtering happens late.

## Diagnosis

- This is a potential plan problem where IndexMerge can combine multiple index paths for DNF filters.
- Confirm each major `OR` branch has a usable index candidate.

## Suggestions (Strict Order)

1. Binding or hints first.
   - Guide user to try IndexMerge using hints/bindings first.
   - Example hint:
     - `/*+ USE_INDEX_MERGE(t, idx_a, idx_b, idx_c) */`
2. Add new index.
   - Add missing branch indexes only when an important `OR` branch has no usable index.
   - Avoid duplicated indexes (left-prefix duplicates).
3. Rewrite query.
   - Simplify DNF branches.
   - Remove redundant predicates.
   - Consider splitting into `UNION ALL` forms only when it is clearer and faster.

## Example

- Query:
  - `SELECT * FROM t WHERE a = ? OR b = ? OR c > ?;`
- Situation:
  - Existing plan does not use effective multi-index access.
  - Table has `idx_a(a)`, `idx_b(b)`, `idx_c(c)`.
- Action:
  - Try IndexMerge via hint/binding, then verify scan row reduction.

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm IndexMerge path is selected and total scanned rows/time decrease.
- Confirm no duplicated-index recommendation is introduced.

---

## Case: Use TiFlash or MPP for Large Aggregation


## Symptom

- Query is dominated by aggregation cost on large scanned data.
- `EXPLAIN ANALYZE` shows `HashAgg`/`StreamAgg` with high time and large input rows.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema and existing indexes.
- TiFlash replica status for involved large tables.

## Plan Signature

- Bottleneck operator is large-scale `HashAgg`/`StreamAgg`.
- Plan is mainly on TiKV path.
- No practical index path to turn this into an efficient selective scan plus `StreamAgg`.

## Diagnosis

- This is a plan-selection opportunity for large aggregation workloads.
- If index optimization cannot materially reduce scanned rows or enforce cheap ordered aggregation, prefer TiFlash/MPP path.

## Suggestions (Strict Order)

1. Binding or hints first.
   - Guide user to force TiFlash storage and MPP plan where suitable.
   - Example hint:
     - `/*+ READ_FROM_STORAGE(TIFLASH[t]) */`
   - Use SQL binding for stable reuse.
2. Add new index.
   - Recommend indexes only if they can materially improve selectivity or support better ordered aggregation.
   - If workload is large analytical aggregation, prioritize TiFlash/MPP over index expansion.
3. Rewrite query.
   - Push filters before aggregation.
   - Pre-aggregate in subqueries when it reduces rows early.
   - Remove unnecessary selected columns.

## Example

- Query pattern:
  - `SELECT k, SUM(v) FROM t WHERE dt >= ? AND dt < ? GROUP BY k;`
- Situation:
  - Very large scan and heavy aggregation.
  - Existing indexes cannot make aggregation cheap enough.
- Action:
  - Prefer TiFlash/MPP via hint/binding before new index proposals.

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm aggregation-heavy operators move to TiFlash/MPP path and latency improves.
- Confirm result correctness and acceptable resource usage.

---

## Case: Use TiFlash or MPP for Large Join


## Symptom

- Query is dominated by large join cost.
- `EXPLAIN ANALYZE` shows join operators consuming most time with large input rows.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema and existing indexes.
- TiFlash replica status for involved large tables.

## Plan Signature

- Bottleneck operator is `HashJoin`/`MergeJoin` over large row sets.
- Current plan runs mostly on TiKV path.
- No practical index path to transform this into an efficient `IndexJoin`.

## Diagnosis

- This is a plan-selection problem for large join workloads.
- If index design cannot realistically produce a good `IndexJoin`, prefer TiFlash/MPP path.

## Suggestions (Strict Order)

1. Binding or hints first.
   - Guide user to force TiFlash storage and MPP plan where suitable.
   - Example hints:
     - `/*+ READ_FROM_STORAGE(TIFLASH[t1, t2]) */`
     - `/*+ HASH_JOIN(t1, t2) */` (when needed to stabilize join shape)
   - Use SQL binding if hint effect should be persistent.
2. Add new index.
   - Recommend new indexes only if they can materially change join access into a better `IndexJoin`.
   - If large full/near-full joins remain unavoidable, do not force index creation.
3. Rewrite query.
   - Push highly selective filters before join.
   - Reduce join input columns and rows.
   - Break complex joins into staged subqueries when it lowers data volume.

## Example

- Query pattern:
  - `SELECT /* complex join */ ... FROM t1 JOIN t2 ON ... WHERE ...`
- Situation:
  - Join processes tens of millions of rows.
  - Existing indexes cannot produce a stable, fast `IndexJoin`.
- Action:
  - Prefer TiFlash/MPP path via hint/binding before new index design.

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm join-heavy operators move to TiFlash/MPP path and total latency improves.
- Validate that regression risk is acceptable for similar queries.

---

## Case: Use TiFlash to Speed Up Large Scan


## Symptom

- Query scans a large table and runs slowly.
- `EXPLAIN ANALYZE` shows large scan/aggregation operators dominating total time.

## Required Inputs

- Original SQL.
- `EXPLAIN ANALYZE` output.
- Related table schema and whether TiFlash replica is available for involved tables.

## Plan Signature

- Bottleneck is large scan plus heavy compute (`TableFullScan`, `HashAgg`, `Sort`, or join over large input).
- Row count is large, so this is not a small-row non-plan case.
- Plan is using TiKV path while workload is analytical/scan-heavy.

## Diagnosis

- This is a plan-selection opportunity when TiFlash is available but not chosen.
- Goal is to route large scan/compute to TiFlash.

## Suggestions (Strict Order)

1. Binding or hints first.
   - Guide user to force TiFlash with hints/bindings before schema changes.
   - Example hint: `/*+ READ_FROM_STORAGE(TIFLASH[t]) */`.
2. Add new index.
   - Only suggest index if query is actually selective and index can reduce scanned rows materially.
   - For true large analytical scans, index may not be the best next step.
3. Rewrite query.
   - Push down filters earlier and reduce scanned columns where possible.
   - Use pre-aggregation/query decomposition when it reduces scanned data.

## Example

- Query pattern:
  - `SELECT d, SUM(m) FROM t WHERE dt >= ? AND dt < ? GROUP BY d;`
- Situation:
  - Plan performs large TiKV scan with expensive aggregation.
  - TiFlash replica exists for `t` but is not selected.
- Action:
  - Try `/*+ READ_FROM_STORAGE(TIFLASH[t]) */` via direct hint or SQL binding.

## Verification

- Re-run `EXPLAIN ANALYZE`.
- Confirm scan/agg operators run on TiFlash path and end-to-end latency improves.
- If improvement is unstable, keep binding and document fallback behavior.

---

## Slow Plan Optimization Sub-Module


This is a sub-module of `tidb-performance-optimization`, not an independent skill entry point.

## Required Inputs

- Require the original SQL text (exact query sent to TiDB).
- Prefer real execution plans from `EXPLAIN ANALYZE` with runtime details (time cost, rows, loops, memory/disk when available).
- Ask whether the user can provide the related table schema (`SHOW CREATE TABLE` for involved tables).
- If the user only provides `EXPLAIN` (no runtime stats), ask for `EXPLAIN ANALYZE` before giving detailed optimization advice.
- Ask for missing required inputs before giving optimization advice.

## Workflow

- Confirm required inputs first (SQL, `EXPLAIN ANALYZE`, and schema if available).
- Identify the bottleneck operator in the execution plan first.
  - Define bottleneck operator as the operator that accounts for the largest time cost in the plan.
- Decide whether this is a query plan problem before proposing plan tuning.
  - If the bottleneck operator processes only a small number of rows but still takes a long time, treat it as likely not a query plan problem.
- If it is not a query plan problem, or there is no clear room for plan-side improvement, do not provide plan optimization suggestions.
  - Output a clear conclusion such as: "Can't improve this query from the plan perspective; this might be a <component> problem."
  - If plan is already optimal and bottleneck is at execution layer, suggest increasing execution engine concurrency as a possible non-plan solution.
- Use bottleneck-targeted methods first if and only if it is a query plan problem.
- Figure out optimization methods that directly target that bottleneck operator.
- Output suggestions in this strict order:
  1. Create SQL binding or add optimizer hints.
  2. Add new indexes.
  3. Rewrite the query.
- Re-run `EXPLAIN ANALYZE` to verify each applied change.

## Guardrails

- Keep recommendation priority fixed: binding/hints -> indexes -> query rewrite.
- Keep analysis priority fixed: identify bottleneck operator -> optimize bottleneck -> output suggestions.
- Keep diagnosis priority fixed: determine plan problem vs non-plan problem before plan changes.
- If diagnosis says non-plan problem, stop plan tuning and return only the non-plan conclusion.
- If diagnosis says execution-layer bottleneck with an already-optimal plan, allow concurrency tuning suggestion as non-plan guidance.
- Do not jump to index or SQL rewrite suggestions before considering binding/hints.
- Use runtime evidence from `EXPLAIN ANALYZE` to justify each recommendation.
- When recommending new indexes, avoid duplicated indexes.

## Index Recommendation Rules

- Treat indexes as duplicated when one index is a left-prefix of another index.
  - Example: `idx(a, b)` is duplicated by `idx(a, b, c)`.
- Prefer the longer duplicated index, because it can cover more predicates.
  - Example: `idx(a, b, c)` is better than `idx(a, b)` when both are candidates.
- If the plan is already using `idx(a, b, c)`, do not recommend `idx(a, b)` for queries like `WHERE a = ? AND b > ?`.
- If table schema already has `idx(a, b, c)`, do not recommend creating `idx(a, b)`.
- If there is an existing index that can cover more query predicates (especially `EQ`/`IN`) but the plan is not using it, treat this as a possible index-selection problem.
- For index-selection problems, guide the user to try optimizer hints/bindings first to force the better index choice.
  - Example: query `WHERE a = ? AND b = ? AND c > ? AND d = ?` uses `idx(a, c)`, but schema has `idx(a, b, d)`.
  - In this case, prefer guiding hint-based index selection before recommending new index creation.

## Non-Plan Cases

- `PointGet` or `BatchPointGet` as bottleneck usually means the plan is already optimal; suspect TiKV hotspot or storage-side latency.
- Exception: for non-clustered primary-key tables, `PointGet`/`BatchPointGet` can show double-read behavior (`num_rpc:2`). If workload is dominated by primary-key point lookups, consider clustered primary key table design to reduce RPCs.
- Small `IndexRangeScan`/`TableRangeScan` (for example ~100 rows) but long latency usually points to TiKV-side issues, not plan shape.
- Small-row `Hash`/`Agg`/`Sort` (for example ~1000 rows) but long latency is usually not a query plan problem.
- If plan is already optimal and bottleneck is execution-layer scheduling/compute, consider increasing execution engine concurrency.

## Useful References

- `cases/use-clustered-primary-key-for-pointget.md` - Use clustered primary key to reduce `PointGet`/`BatchPointGet` RPC count for primary-key point lookup workloads.
- `cases/use-covering-index-to-avoid-double-scan.md` - Use covering indexes to reduce index lookup double-read cost.
- `cases/use-tiflash-to-speed-up-large-scan.md` - Use TiFlash for large scan and analytical workloads.
- `cases/use-tiflash-mpp-for-large-join.md` - Use TiFlash or MPP for large joins when index-based join optimization is not feasible.
- `cases/use-tiflash-mpp-for-large-aggregation.md` - Use TiFlash or MPP for large aggregations when index-based StreamAgg optimization is not feasible.
- `cases/use-index-merge-for-dnf-predicates.md` - Consider IndexMerge for DNF predicates such as `a = ? OR b = ? OR c > ?`.
- `cases/use-covering-index-for-filter-and-order-by.md` - Use covering index to optimize `WHERE ... ORDER BY ...` patterns.
