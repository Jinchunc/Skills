
> ⚠️ Version note: contains cases from the TiDB v5.x era — verify applicability to your cluster version (this profile targets 6.5–8.x).
# FAULT-NODE-DOWN (F1 Node Unavailable)

> Entry condition: TiKV/TiDB node is down, restarted, or unreachable

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Fault time range [start, end]
3. Affected instance (instance label)

---

## Severity Assessment

| Level | Condition | Response |
|-------|-----------|----------|
| P0 | Multiple TiKV nodes simultaneously unavailable (risk of losing majority replicas) | Escalate immediately, prioritize service recovery |
| P1 | Single TiKV node unavailable, or any TiDB node unavailable | Handle promptly, assess business impact |
| P2 | Node has auto-recovered, but restart record exists | Investigate root cause, prevent recurrence |
| P3 | Node briefly unreachable (<30s) then self-recovered | Monitor trend, record event |

---

## Decision Tree

### Step 1: Confirm Node Status

```
metrics:
  uptime: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}"}

Checks:
  1. Which instances had uptime drop sharply (= restart occurred) within [start, end]
  2. Identify: RESTARTED_INSTANCES + job (tidb/tikv/pd)
  3. Is the instance currently online: up{tidb_cluster_id="{cluster_id}"} == 0 means still unreachable

Judgment:
  No restart + instance online → "No anomaly detected" → END
  Restart detected → Step 2
  Instance still unreachable → Emergency recovery procedure (see below)
```

### Step 2: Determine if OOM or Other Cause

```
metrics:
  rss_tikv: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv", instance="{inst}"}
  rss_tidb: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb", instance="{inst}"}

Check (5~30 minutes before restart):
  - RSS continuously rising until restart → Suspected OOM → Step 3
  - RSS stable then suddenly disappeared → Not OOM → Step 4
```

**Loki Log Search (loki_available=true, Dedicated/Premium only)**

```
Search keywords:
  {component="tikv"} |~ "(?i)OOM|killed|out of memory|panic|fatal"
  {component="tidb"} |~ "(?i)OOM|killed|memory exceed|panic|fatal"
  {component="tikv"} |~ "signal 9|signal 6|SIGKILL|SIGABRT"
  {component="tikv"} |~ "memory is limited|memory usage limit"

Typical matches:
  "OOM" / "killed" / "signal 9"   → Confirmed OOM → Step 3
  "panic" / "fatal"                → Process panic → Step 4 Branch B
  "disk" / "no space"              → Disk full → Step 4 Branch A
  No abnormal logs + stable RSS    → Manual operation / Platform scheduling → Step 4 Branch D
```

### Step 3: OOM Root Cause Analysis

> Detailed OOM investigation reference: [PATH-OOM](../paths/oom.md)

Branch by job:

#### Branch 3A: TiKV OOM

**3A-1: Memory Breakdown Check**

TiKV memory formula: `block-cache + region metadata + raftstore memtrace + resolved-ts locks + coprocessor buffers + ~1.3GB baseline`

Note: `memory-usage-limit` is not a hard limit; it only controls raft-related memory and cannot prevent OOM.

```
metrics (snapshot 30 minutes before restart):
  block_cache:    tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}", instance="{inst}"}
  regions:        tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", instance="{inst}"}
  write_buf:      tikv_engine_write_buffer_manager_memory_usage_bytes{tidb_cluster_id="{cluster_id}", instance="{inst}"}

All PromQL appended with tidb_cluster_id="{cluster_id}" filter

Checklist:
  1. block_cache > system memory x 45%
     → "Block cache configured too large" (Cloud 4c16g actual limit ~13GB, 8c32g actual limit ~28GB)
  2. regions > 50K
     → "Too many Regions (every 10K Regions ≈ 500MB metadata memory; 50K ≈ 2.5GB)"
  3. write_buf abnormally high
     → "Memtable accumulation" → Check write stall
```

**3A-2: Top OOM Cause Investigation**

```
(a) Coprocessor task accumulation
  metrics:
    running_tasks: tikv_unified_read_pool_running_tasks{tidb_cluster_id="{cluster_id}", instance="{inst}"}
  running_tasks persistently > 1000 → Coprocessor cached data causing memory spike
  Case: 8000+ accumulated tasks increased 5GB memory in 4 minutes → OOM
  Suggest user action: SET CONFIG tikv `readpool.unified.max-tasks-per-worker` = <lower_value>;
  (v8.2+) Suggest user action: SET CONFIG tikv `end-point-memory-quota` = '<value>';

(b) Resolved-ts lock accumulation
  metrics:
    lock_heap: tikv_resolved_ts_lock_heap_bytes{tidb_cluster_id="{cluster_id}", instance="{inst}"} (if available)
  lock_heap continuously growing + GC safepoint stalled → resolved-ts caching large amounts of uncommitted transaction locks
  Accompanying characteristics: Large transactions / GC stuck / Memory immediately rises again after restart
  Suggest user action: Disable resolved-ts (requires rolling restart; does not affect CDC/PITR/follower read)
  Emergency measure: SELECT count(1) FROM <table> to trigger lock cleanup (suggest user action)

(c) Pessimistic lock accumulation
  Characteristics: deadlock_detector thread CPU 100%, other nodes' pessimistic lock RPC backlogged
  Suggest user action: SET CONFIG tikv `pessimistic-txn.max-retry-count` = <lower_value>;

(d) Too many Regions (Scale-in overload)
  Occurs during rolling restart/scale-down: Remaining nodes absorb extra region metadata (500MB/10K regions)
  + Read/write pressure shifts → Memory exceeds limit → OOM
  Prevention: Confirm remaining nodes have sufficient memory headroom before scale-down

(e) Swap causing gRPC deadlock
  Swap enabled → Memory pressure → gRPC thread hung (keepalive watchdog timeout)
  → TiKV enters down state → Manifests as node unavailable
  Suggest user action: swapoff -a (disable swap)
```

**3A-3: Allocstall Causing TiKV to Freeze**

```
Characteristics: Non-typical OOM, process not killed but completely unresponsive
  - System free memory < 10GB → Kernel allocstall → All TiKV threads blocked
  - gRPC keepalive timeout → Other nodes mark this node as down

Confirmation (if node_exporter{tidb_cluster_id="{cluster_id}"} available):
  node_vmstat_allocstall{tidb_cluster_id="{cluster_id}"} (DataPlane metric, may not be available)
  node_memory_MemFree_bytes{tidb_cluster_id="{cluster_id}"} < 10GB

Suggest user action:
  Temporary: echo 1 > /proc/sys/vm/drop_caches
  Long-term: Configure vm.min_free_kbytes = min(num_numa_nodes * 1G, 16G)
```

#### Branch 3B: TiDB OOM

→ [PATH-OOM Branch A](../paths/oom.md) (Confirm RSS > quota x 90% → Check high-memory SQL → Check memory configuration)

**Loki Supplemental Search (loki_available=true)**

```
{component="tidb"} |~ "(?i)expensive_query|memory exceed"
{component="tidb"} |~ "TTL manager has timed out"
{component="tidb"} |~ "GC safe point|safepoint blocked"

Typical findings:
  - expensive_query → Long-running uncommitted large transaction
  - GC safepoint blocked by a running session → Long transaction blocking GC → PATH-TXN-CONFLICT
  - TTL manager has timed out → Pessimistic lock timeout, transaction not properly terminated
```

### Step 4: Non-OOM Root Cause

#### Branch A: Disk Space Exhaustion

```
metrics:
  store_avail: tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="available"} by (instance)
  store_used:  tikv_engine_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance, db)

Checks:
  available <= reserve-space (max(5GB, capacity*0.05))
    → "AlmostFull": Rejects normal writes
  available <= reserve-space / 2
    → "AlreadyFull": Rejects all writes

→ [PATH-DISK-SPACE](../../performance-optimization/paths/disk-space.md)
```

#### Branch B: Process Panic

```
Loki (loki_available=true):
  {component="tikv"} |~ "panic|fatal|thread.*panicked"
  {component="tidb"} |~ "panic|fatal"

Common panic causes:
  - SST file corruption → tikv-ctl bad-ssts check (suggest user action)
  - protobuf panic (Coprocessor response > 4GB, before v5.2.2)
  - start_ts=0 panic (caused by fast_reorg=ON + dist_task=OFF)
  - Raft applied memory statistics error (tikv#15371)

→ Collect panic stack trace, upgrade to version containing the fix
```

#### Branch C: Hardware/Network Failure

```
Checks:
  - Instance has completely no metric data during a specific time period → Physical machine/VM failure
  - Multiple instances disappear simultaneously in the same availability zone → AZ-level failure
  - gRPC error rate spikes:
    sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

→ Contact platform/cloud provider to investigate infrastructure
```

#### Branch D: Manual Operation/Platform Scheduling

```
Checks:
  - Restart time coincides with scale-in/upgrade/rolling-restart operation
  - PD logs show evict-leader-scheduler creation/deletion records
  - Confirmed as planned operation → Not a fault, just record
```

### Step 5: Post-Recovery Impact Assessment

> After node recovery, cluster-level performance degradation may occur; assessment is required

**5A: Raft Log Catch-up Latency (tikv#18617)**

```
Issue: After TiKV restart, catching up Raft log reads old logs sharing the same lock with normal writes
  → Normal writes to hot-write Regions are blocked → Overall cluster write latency increases

metrics:
  write_duration: histogram_quantile(0.99,
    sum(rate(tikv_storage_engine_async_request_duration_seconds_bucket{
      tidb_cluster_id="{cluster_id}", type="write"}[2m])) by (le))
  raft_log_lag: tikv_raftstore_log_lag{tidb_cluster_id="{cluster_id}"} by (instance)

Checks:
  - Is raft_log_lag on the restarted node continuously decreasing (normal recovery in progress)
  - Is write_duration P99 on other nodes abnormally elevated
  - If latency persists > 10 minutes without relief:
    Suggest user action: Upgrade to v7.5.7+ / v8.5.3+ (the lock was removed)
    Temporary mitigation: Reduce raftstore.raft-max-size-per-msg (may reduce wide-table throughput)
```

**5B: Region Balance Check**

```
metrics:
  region_count: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
  leader_count: tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"} by (instance)

Checks:
  max(region_count) / min(region_count) > 1.5 → Regions unbalanced, PD scheduling in progress
  max(leader_count) / min(leader_count) > 1.5 → Leaders unbalanced

PD scheduling status:
  sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[5m])) by (type)
  Has balance-region / balance-leader → Rebalancing in progress
  No scheduling + imbalanced → WARNING ("Scheduling may be disabled or stuck")
```

**5C: Post-Startup Apply Stall (tikv#18233)**

```
Characteristics: After TiKV startup, some peers remain in busy apply state for ~2 minutes
  Even with raft log lag = 0, still returns "Server is busy" (applystore_busy)

Loki (loki_available=true):
  {component="tikv"} |~ "(?i)server is busy|applystore_busy"

Mitigation:
  Suggest user action: Increase raftstore.min-pending-apply-region-count from 10 to 50-100
  Fixed in: v8.5.2 / v7.5.7
```

**5D: Business Recovery Confirmation**

```
metrics:
  qps: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m]))
  p99: histogram_quantile(0.99,
    sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m]))
    by (le))
  errors: sum(rate(tidb_server_execute_error_total{tidb_cluster_id="{cluster_id}"}[2m]))
  backoff: sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

Confirmation:
  - QPS recovered to pre-fault baseline
  - P99 latency recovered to pre-fault baseline
  - Error rate dropped to normal level
  - Backoff frequency dropped to normal level
```

---

## Emergency Recovery Procedure

> When the node is still unreachable and impacting business, prioritize service recovery

### Single TiKV Node Unavailable (P1)

```
1. Confirm if quorum still exists under 3 replicas (2/3 alive → Auto leader election, may have brief latency)
2. Check PD Region status:
   pd_regions_status{tidb_cluster_id="{cluster_id}"}
   Focus on: miss_peer_region_count, down_peer_count
3. If node can be recovered → Restart instance (suggest user action)
4. If node cannot be recovered → Platform replace node (suggest user action)
5. After recovery, execute Step 5 to assess impact
```

### Multiple TiKV Nodes Unavailable (P0)

```
1. Check if majority replicas are lost (any Region where 2/3 replica nodes are all down → That Region is unavailable)
2. If majority lost → Need unsafe-recover:
   Suggest user action: pd-ctl -u <pd_addr{tidb_cluster_id="{cluster_id}"}> unsafe remove-failed-stores <store_id>
3. Prioritize recovering as many nodes as possible
4. Contact platform team for assistance
```

### TiDB Node Unavailable (P1)

```
1. TiDB is stateless, restart or replace to recover
2. Check if load balancer has already redirected traffic
3. Confirm if remaining TiDB nodes can handle all traffic:
   rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m]) by (instance)
4. If CPU > 80% → Suggest user action: Recover/scale out TiDB nodes as soon as possible
```

---

## Data Source Call Templates

### Instance Uptime (Detect Restarts)
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}"}
```

### Instance Alive Status
```
query: up{tidb_cluster_id="{cluster_id}"}
```

### TiKV Memory RSS
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"} by (instance)
```

### TiDB Memory RSS
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"} by (instance)
```

### TiDB Memory Quota
```
query: tidb_server_memory_quota_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Block Cache Size
```
query: tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Region Count
```
query: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Leader Count
```
query: tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Write Buffer Memory
```
query: tikv_engine_write_buffer_manager_memory_usage_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Unified Read Pool Running Tasks
```
query: tikv_unified_read_pool_running_tasks{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Store Available Space
```
query: tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="available"} by (instance)
```

### gRPC Error Rate
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
```

### Write Latency P99 (Recovery Assessment)
```
query: histogram_quantile(0.99,
  sum(rate(tikv_storage_engine_async_request_duration_seconds_bucket{
    tidb_cluster_id="{cluster_id}", type="write"}[2m])) by (le))
```

### QPS (Recovery Confirmation)
```
query: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Query Duration P99 (Recovery Confirmation)
```
query: histogram_quantile(0.99,
  sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m]))
  by (le))
```

### PD Region Status
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}"}
```

### PD Scheduling Operations
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[5m])) by (type)
```

### Backoff Frequency (Recovery Confirmation)
```
query: sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### TiDB CPU (TiDB Node Recovery Assessment)
```
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m]) by (instance)
```
