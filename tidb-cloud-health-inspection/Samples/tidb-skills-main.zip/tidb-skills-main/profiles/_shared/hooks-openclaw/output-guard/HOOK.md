# output-guard

Minimal output quality guard. Only handles what prompt-layer rules cannot:

1. **Garbled text** — blocks corrupted model output, replaces with error message
2. **Long output** — appends guidance to write to local files (does NOT truncate)

Formatting, narration, and tone are enforced by agent rules (#34/#35) and the communication-protocol skill.
