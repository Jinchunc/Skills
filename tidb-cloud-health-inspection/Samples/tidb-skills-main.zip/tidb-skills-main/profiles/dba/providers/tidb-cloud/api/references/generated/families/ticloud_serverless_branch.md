# Serverless Branch

Base command: `ticloud serverless branch`

Manage TiDB Cloud Serverless branches

## Direct Subcommands

- `ticloud serverless branch create` - Create a branch
- `ticloud serverless branch delete` - Delete a branch (dangerous)
- `ticloud serverless branch describe` - Describe a branch
- `ticloud serverless branch list` - List branches (human-output)
- `ticloud serverless branch reset` - Reset a branch to its parent's latest state (dangerous)
- `ticloud serverless branch shell` - Connect to a branch

## Confirmation Required

- `ticloud serverless branch delete`
- `ticloud serverless branch reset`
