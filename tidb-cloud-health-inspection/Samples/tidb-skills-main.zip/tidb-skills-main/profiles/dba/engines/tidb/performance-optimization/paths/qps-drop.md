# PATH-QPS-DROP (S1.6 QPS Drop) <!-- Reason for change: unified as S1.x performance troubleshooting sub-number -->

> Entry condition: QPS drops under the same pressure, e.g. "same pressure but QPS is only half of what it was before"

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range [start, end]

---

## Decision Tree

### Step 1: Confirm QPS Drop + Latency Correlation

```
metrics:
  qps: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m]))
  p99: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

QPS drop + latency increase → system slowing down (something became a bottleneck) → Step 2
QPS drop + latency normal → traffic itself decreased (client issue) → DIAGNOSIS "Traffic decreased, not a database performance issue" → END
```

### Step 2: DB Time Decomposition

→ [MODULE-DBTIME](../modules/db-time.md) identify bottleneck component

### Step 3: Flow Control / Write Stall Check

→ [MODULE-TIKV](../modules/tikv-fast-tune.md) S2_WRITE_STALL

```
metrics:
  write_stall: tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}
  flow_control: tikv_scheduler_flow_control_actions_total{tidb_cluster_id="{cluster_id}"}
Throttled → DIAGNOSIS "Write Stall/Flow Control causing QPS drop" → END
```

### Step 3.5: Loki Log Search (Dedicated/Premium, loki_available=true)

```
Search for long transaction/GC blocking related logs:
  {component="tidb"} |~ "(?i)expensive_query|long transaction"
  {component="tidb"} |~ "GC safe point|safepoint blocked|globalMinStartTS"
  {component="tidb"} |~ "TTL manager has timed out|pessimistic locks"

Typical pattern (TCOC-4900):
  expensive_query appearing frequently → some application holding connections for a long time
  GC safepoint blocked → long transaction preventing GC advancement
  MVCC version accumulation → both reads and writes slow down → QPS drop

Long transaction found → PATH-TXN-CONFLICT or suggest user check application connection management
```

### Step 4: GC / Compaction Check

→ [MODULE-TIKV](../modules/tikv-fast-tune.md) R6_GC, S3_COMPACTION_FLOW

GC or compaction pressure causing overall slowdown → DIAGNOSIS → END

### Step 5: Deep Dive by Component

Route by component based on Step 2 DBTIME output:
- TIKV → MODULE-TIKV
- TIDB → MODULE-TIDB
- PD → MODULE-PD

→ DIAGNOSIS → END

---

## Data Source Call Templates

### QPS
```
query: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Query Duration P99
```
query: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Write Stall
```
query: sum(rate(tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
```

### Flow Control
```
query: sum(rate(tikv_scheduler_flow_control_actions_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

### GC Keys
```
query: sum(rate(tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Compaction Traffic
```
query: sum(rate(tikv_engine_compaction_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

---

## Remediation References

When root cause is plan change or GC/compaction pressure:
- Optimizer fix controls (pin plans, revert optimizer behavior): [../references/optimizer-controls.md](../references/optimizer-controls.md)
- TiKV troubleshooting (GC, compaction, write stall): [../../knowledge/troubleshooting-guide.md](../../knowledge/troubleshooting-guide.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
