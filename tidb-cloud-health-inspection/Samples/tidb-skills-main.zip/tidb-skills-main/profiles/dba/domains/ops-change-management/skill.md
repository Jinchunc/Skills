# Ops & Change Management — Domain Methodology (Partial)

> version: 0.1.0 (partial coverage)
> Engine-agnostic methodology for evaluating and managing operational changes.

## Activation

User requests: scaling, upgrade, parameter change, config review, rollback planning, change impact assessment.

## Engine Detection and Provider Loading

Follow the canonical procedure in `INDEX.md#engine-detection-and-provider-loading` (engine detection 3-step, conditional engine skill loading, DISPATCH Layer 3 provider loading).

---

## Step 1: Pre-Change Checklist

Before any operational change:
1. **What** — exact change being made (parameter, scaling, upgrade)
2. **Why** — business justification and expected outcome
3. **Impact scope** — which components, which users affected
4. **Rollback plan** — how to revert if change causes problems
5. **Verification** — how to confirm the change succeeded

## Step 2: Change Classification

| Type | Risk | Approach |
|------|------|----------|
| **Rolling** | Low — no downtime | Apply to nodes one at a time, verify each |
| **Disruptive** | Medium — brief impact | Schedule maintenance window, notify users |
| **Breaking** | High — potential data loss | Full backup first, staged rollout, immediate rollback ready |

## Step 3: Config Change Review Protocol

When reviewing configuration changes:
1. Identify the parameter and its current vs proposed value
2. Assess blast radius — what does this parameter affect?
3. Check for dependencies — does changing this require other changes?
4. Determine if change is hot-reloadable or requires restart
5. Define monitoring: which metrics to watch after the change

→ Engine: provides parameter-specific impact analysis, restart requirements, and safe ranges.

## Step 4: Verification Protocol

After any change:
1. Confirm the change took effect (read-back the parameter)
2. Monitor key metrics for 15-30 minutes post-change
3. Compare with pre-change baseline
4. If metrics degrade → execute rollback plan

## Security Tiers

Global guardrails (Security Tiers, Data Handling, Network & Identity): see ../../GUARDRAILS.md
