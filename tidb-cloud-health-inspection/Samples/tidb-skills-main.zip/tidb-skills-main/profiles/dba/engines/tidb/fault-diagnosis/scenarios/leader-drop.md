# FAULT-LEADER-DROP (F8 Abnormal Leader Transfer)

> Entry condition: TiKV frequently changing leaders / Leaders suddenly transferred in bulk
> Severity level: P1 (Large-scale leader transfer directly impacts availability, read/write latency spikes)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range [start, end]

---

## Decision Tree

### Step 1: Confirm Abnormal Leader Transfer

```
metrics:
  leader_count:    sum(tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"}) by (instance)                     step=15s
  transfer_rate:   sum(rate(tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)           step=15s
  region_count:    sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"}) by (instance)                     step=15s

Analysis:
  - leader_count on an instance drops sharply (>30% within 5 minutes) = Confirmed anomaly
  - Compare region_count: Regions unchanged but leaders dropped → Leaders actively/passively transferred away
  - Both regions and leaders drop simultaneously → Store may have briefly gone offline
  - Multiple instances fluctuating simultaneously vs single instance losing leaders → Determine impact scope
```

### Step 2: Is There a Scheduling Operation (External Cause)

> Trigger: Step 1 confirmed abnormal leader transfer

```
metrics:
  sched_ops:         sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
  store_status:      pd_scheduler_store_status{tidb_cluster_id="{cluster_id}"}

Checks:
  a. evict-leader-scheduler:
     - sched_ops{type="evict-leader"} has values → Manual operation or automatic eviction
     - Common scenarios: Rolling upgrade (rolling-update), scale-in/out, manual maintenance
     → If planned change → Normal behavior, DIAGNOSIS (expected scheduling) → END

  b. Is a rolling restart/upgrade in progress:
     → Search Loki for TiKV startup logs to confirm (see Data Source Call Templates)
     → Confirmed as upgrade → Normal behavior → END

  c. No manual operation but evict-leader present → Go to Step 3 (Slow Store automatic eviction)
```

### Step 3: Slow Store Detection

> Trigger: evict-leader exists but not manually triggered; or leaders continuously transferred out from an instance

```
metrics:
  slow_score:        tikv_raftstore_slow_score{tidb_cluster_id="{cluster_id}"} by (instance)                         step=15s

Analysis:
  - slow_score reaches 100 → PD triggers evict-slow-store-scheduler → Leaders are evicted
  - Check if slow store is a false positive:

  False positive scenario (tikv#18775):
    Under high write speed, raft log append backlog → inspect latency rises → slow score inflated
    Verify: Check if write traffic was at peak during the same period
      tikv_engine_flow_bytes{tidb_cluster_id="{cluster_id}", db="kv", type="write"} by (instance)
    Write peak + slow_score rise → High probability of false positive

  Confirmed not a false positive → Proceed to Step 4/5/6 to locate the true slow cause

Suggest user action (false positive scenario):
  - Increase inspect-interval (reduce detection sensitivity)
  - Or temporarily disable evict-slow-store-scheduler:
    pd-ctl scheduler remove evict-slow-store-scheduler
  - Upgrade to a version containing the tikv#18775 fix
```

### Step 4: gRPC Thread Bottleneck

> Trigger: slow_score is high and not a false positive; or leaders frequently transfer without obvious scheduling operations

```
metrics:
  grpc_cpu:          sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"grpc.*"}[1m])) by (instance)
  grpc_msg_fail:     sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
  raft_msg_send:     sum(rate(tikv_server_raft_message_flush_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

Analysis:
  a. gRPC CPU approaching quota (grpc-concurrency default 5 threads):
     - gRPC threads busy → Cannot send raft heartbeat in time → Follower election timeout → Re-election
     → DIAGNOSIS: "gRPC thread overload causing heartbeat timeout"

  b. gRPC blocked by large SQL (>1MB request deserialization blocking gRPC thread):
     - Manifestation: raft client send queue full → Log shows "channel full" or "raft client send queue is full"
     - RPC layer latency spikes simultaneously
     → Loki search: {component="tikv"} |= "channel full" or |= "send queue is full"
     → DIAGNOSIS: "Large SQL deserialization blocking gRPC thread"

Suggest user action:
  - Increase server.grpc-raft-conn-num: default 1, suggest 2-3
    SET CONFIG tikv `server.grpc-raft-conn-num` = 2;
  - Increase server.grpc-concurrency: default 5, suggest 8 for 16-core machines
    SET CONFIG tikv `server.grpc-concurrency` = 8;
  - Identify and optimize large SQL (>1MB requests)
```

### Step 5: Raftstore / IO Issues

> Trigger: gRPC is not overloaded but leaders still frequently transfer

```
metrics:
  append_log_p99:    histogram_quantile(0.99, sum(rate(tikv_raftstore_append_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le, instance))
  apply_log_p99:     histogram_quantile(0.99, sum(rate(tikv_raftstore_apply_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le, instance))
  write_stall:       tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"} by (instance)
  store_io_cpu:      sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"store-io.*"}[1m])) by (instance)

Analysis:
  a. append_log_p99 > 100ms:
     - Disk IO jitter → Raft log write slow → Leader lease expires → Re-election
     - Check if there is write_stall (RocksDB write stall)
     → DIAGNOSIS: "Disk IO jitter causing raft log append latency"

  b. raftstore thread overwhelmed by high load:
     - apply_log_p99 persistently high → raftstore processing slow → Heartbeat backlog
     → DIAGNOSIS: "Raftstore overloaded"

  c. Async IO check (before v8.1.0, store-io-pool-size not enabled by default):
     - Version < v8.1.0 and store-io-pool-size = 0 → Raft log IO executes synchronously in raftstore thread
     → DIAGNOSIS: "Async IO not enabled, raft log synchronous IO blocking raftstore"

Suggest user action:
  - Before v8.1.0: Enable Async IO
    SET CONFIG tikv `raftstore.store-io-pool-size` = 2;
  - Check disk performance, consider upgrading storage (SSD/NVMe)
  - If write_stall exists: Refer to RocksDB tuning (increase max-background-jobs)
```

### Step 6: Hardware/Network Issues

> Trigger: Above steps did not locate root cause

```
metrics:
  raft_msg_duration:   histogram_quantile(0.99, sum(rate(tikv_raftstore_raft_send_message_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le, instance))
  grpc_connections:    tikv_grpc_connections{tidb_cluster_id="{cluster_id}"} by (instance)

Checks:
  a. Network jitter:
     - Raft message latency high (raft_msg_duration > hundreds of ms)
     - gRPC connections frequently rebuilt (grpc_connections fluctuating)
     - Leader heartbeat timeout threshold: raft-store-max-leader-lease = 9s, network interruption exceeding this value triggers re-election
     → DIAGNOSIS: "Network jitter causing raft heartbeat timeout"
     → Loki search: {component="tikv"} |= "lease expired" or |= "campaign"

  b. Memory allocstall:
     - Kernel memory reclaim causes process to briefly hang → All threads stuck including raftstore
     - Check: node-exporter free memory < 10GB + allocstall events
     → Loki search: {component="tikv"} |= "allocstall" (if kernel logs are ingested)
     → DIAGNOSIS: "Memory allocstall causing TiKV process stall"

Suggest user action (network):
  - Check network devices, cross-AZ latency
  - Investigate if network policy/firewall rules changed

Suggest user action (allocstall):
  - Temporary: echo 1 > /proc/sys/vm/drop_caches (execute during low traffic)
  - Long-term: Configure vm.min_free_kbytes = min(num_numa_nodes * 1G, 16G)
    Example: For dual NUMA nodes, set vm.min_free_kbytes = 2097152
  - Check if TiKV memory configuration is reasonable, whether block-cache is too large
```

---

## Data Source Call Templates

### Leader Count per Instance (step=15s)
```
query: sum(tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"}) by (instance)
step: 15
```

### Region Count per Instance
```
query: sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"}) by (instance)
step: 15
```

### Slow Score per Instance
```
query: tikv_raftstore_slow_score{tidb_cluster_id="{cluster_id}"}
step: 15
```

### PD Scheduling Operations
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
step: 15
```

### gRPC Thread CPU per Instance
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"grpc.*"}[1m])) by (instance)
step: 15
```

### gRPC Failures
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
step: 15
```

### Raft Log Append Duration P99
```
query: histogram_quantile(0.99, sum(rate(tikv_raftstore_append_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le, instance))
step: 15
```

### Apply Log Duration P99
```
query: histogram_quantile(0.99, sum(rate(tikv_raftstore_apply_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le, instance))
step: 15
```

### Write Stall
```
query: tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}
step: 15
```

### Write Traffic per Instance
```
query: sum(rate(tikv_engine_flow_bytes{tidb_cluster_id="{cluster_id}", db="kv", type="write"}[2m])) by (instance)
step: 15
```

### Raft Message Send Duration P99
```
query: histogram_quantile(0.99, sum(rate(tikv_raftstore_raft_send_message_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le, instance))
step: 15
```

### gRPC Connection Count
```
query: tikv_grpc_connections{tidb_cluster_id="{cluster_id}"}
step: 15
```

### Store IO Thread CPU (Async IO)
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"store-io.*"}[1m])) by (instance)
step: 15
```

### Loki: TiKV Startup Logs (Confirm Rolling Restart)
```
logql: {component="tikv"} |= "TiKV is started"
```

### Loki: gRPC Channel Full (Large SQL Blocking)
```
logql: {component="tikv"} |~ "channel full|send queue is full"
```

### Loki: Leader Lease Expired (Network/Stall)
```
logql: {component="tikv"} |~ "lease expired|campaign"
```

### Loki: Slow Store Eviction Logs
```
logql: {component="pd"} |= "evict-slow-store"
```
