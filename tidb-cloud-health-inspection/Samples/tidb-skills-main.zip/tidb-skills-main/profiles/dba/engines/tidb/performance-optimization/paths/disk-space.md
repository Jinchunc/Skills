# PATH-DISK-SPACE (S1.14 Insufficient Disk Space) <!-- Modification reason: Unified as S1.x performance troubleshooting sub-number -->

> Entry condition: Storage nearly full / data volume surge / Region count surge

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm Disk Usage Status

```
metrics:
  store_size: tikv_engine_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance, db)
  available:  tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="available"} by (instance)

condition (thresholds from: troubleshooting-guide.md):
  Used > 70% (high-space-ratio default 0.7): PD starts ignoring remaining space on this node
  Used > 80% (low-space-ratio default 0.8): PD stops scheduling data to this node
  available <= reserve-space (max(5GB, capacity x 0.05)): TiKV rejects normal writes (AlmostFull)
  available <= reserve-space/2: TiKV rejects all writes (AlreadyFull)
  Abnormal growth rate (daily increase > historical daily average x 3)
```

### Step 2: Identify Space Consumption Cause

**Branch a: Normal Data Growth**
- Growth rate vs historical trend
- Normal business growth -> DIAGNOSIS + recommend scaling out

**Branch b: Compaction Falling Behind / Space Amplification**
```
metrics:
  pending: tikv_engine_pending_compaction_bytes{tidb_cluster_id="{cluster_id}"}
  Space amplification ratio: store_size / logical_data_size
pending_compaction_bytes > 192GB (soft-pending-compaction-bytes-limit default) -> "Compaction severely falling behind"
Amplification ratio > 2x -> MODULE-TIKV S3_COMPACTION_FLOW
```

**Branch c: MVCC Version Accumulation**
```
metrics:
  gc_safe_point vs current TSO -> GC lag
  tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}", tag="mvcc_versions"}
GC lag -> MODULE-TIKV R6_GC
GC blocked by long transactions -> Check tidb_tikvclient_txn_duration_seconds{tidb_cluster_id="{cluster_id}"}
```

**Branch d: Region Count Surge**
```
metrics:
  tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} growth rate
Too many small Regions -> Recommend merge (pd-ctl)
```

### Step 3: Urgency Assessment

| Available | Urgency | Recommendation |
|-----------|---------|----------------|
| < 10% | P0 | Scale out or clean up immediately |
| 10~20% | P1 | Plan scaling out |
| > 20% but growing fast | P2 | Alert + monitor |

---

## Data Source Call Templates

### Store Size
```
query: tikv_engine_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance, db)
query: tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="available"} by (instance)
```

### Pending Compaction
```
query: tikv_engine_pending_compaction_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### GC Safe Point
```
query: tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}"}
```

### Region Count
```
query: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
```
