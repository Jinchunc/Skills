#!/usr/bin/env bash
# Audit hook — logs all agent tool operations to daily JSONL files.
# Claude Code hook format: reads JSON from stdin, writes audit entry.
#
# Env: AUDIT_DIR (default: ~/.claude/audit)
set -euo pipefail

AUDIT_DIR="${AUDIT_DIR:-${HOME}/.claude/audit}"
(umask 077 && mkdir -p "$AUDIT_DIR")

INPUT=$(cat)
TODAY=$(date -u +%Y-%m-%d)
AUDIT_FILE="${AUDIT_DIR}/audit-${TODAY}.jsonl"

TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
EVENT=$(echo "$INPUT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('hook_event_name','unknown'))" 2>/dev/null || echo "unknown")
TOOL=$(echo "$INPUT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('tool_name',''))" 2>/dev/null || echo "")

# Write single-line JSON entry (pass via env vars to prevent shell injection)
TS="$TS" EVENT="$EVENT" TOOL="$TOOL" python3 -c "
import json, os
entry = {'ts': os.environ['TS'], 'event': os.environ['EVENT']}
if os.environ.get('TOOL'):
    entry['tool'] = os.environ['TOOL']
print(json.dumps(entry, ensure_ascii=False))
" >> "$AUDIT_FILE" 2>/dev/null || true

exit 0
