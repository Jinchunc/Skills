# Serverless Private Link Connection

Base command: `ticloud serverless private-link-connection`

Manage private link connections for dataflow

## Direct Subcommands

- `ticloud serverless private-link-connection attach` - Attach domains to a private link connection (sensitive)
- `ticloud serverless private-link-connection attach-domains` - Attach domains to a private link connection (sensitive)
- `ticloud serverless private-link-connection create` - Create a private link connection for dataflow
- `ticloud serverless private-link-connection delete` - Delete a private link connection for dataflow (dangerous)
- `ticloud serverless private-link-connection describe` - Describe a private link connection for dataflow
- `ticloud serverless private-link-connection detach` - Detach domains from a private link connection (dangerous)
- `ticloud serverless private-link-connection detach-domains` - Detach domains from a private link connection (sensitive)
- `ticloud serverless private-link-connection list` - List private link connections for dataflow (human-output)
- `ticloud serverless private-link-connection zones` - Get account and availability zones

## Confirmation Required

- `ticloud serverless private-link-connection delete`
- `ticloud serverless private-link-connection detach`
