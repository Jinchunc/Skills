---
name: skill-guard
description: Defense-in-depth protection for skill content — detects and blocks skill content leakage in outbound messages.
scope: all-profiles
---

## Purpose

Even if prompt-layer protection (SOUL.md content protection rules) is bypassed via prompt injection, this hook catches skill content in outbound messages and replaces them with a refusal notice.

## Detection Layers

### Layer 1: SKILL.md Frontmatter

Detects YAML frontmatter containing `name:` plus skill-specific metadata fields (`description`, `category`, `discipline`, `scope`, `clearance`, etc.).

### Layer 2: CONFIDENTIAL Markers

Detects `<CONFIDENTIAL>` tags, "STOP — This file is proprietary" warning text, and `SKILL-PROTECTION` tokens.

### Layer 3: Structural Fingerprints

Counts skill-specific section headers in a single message. If 3 or more appear, the message is blocked:
- "When to Trigger/Use", "Anti-Patterns", "Terminal State", "Boundary"
- "Security Red Lines", "Fail-Open Rules", "Pre-Flight Check"
- "Performance Constraints", "Routing", "Implementation", "Audit Requirements"

## Behavior

When any detection layer triggers:
1. Replace entire outbound message with refusal notice
2. Log to audit file: timestamp, triggers, message preview (200 chars)

## False Positive Risk

Low. Normal agent output rarely contains:
- YAML frontmatter with skill metadata fields
- CONFIDENTIAL markers
- 3+ skill-specific section headers

If false positives occur, tune `SKILL_HEADER_THRESHOLD` or narrow the header patterns. Audit log entries help identify which layer fired.

## Configuration

| Env Var | Default | Description |
|---------|---------|-------------|
| `AUDIT_DIR` | `/data/audit` | Directory for block audit logs |

## Relationship to Prompt-Layer Protection

```
SOUL.md rules (prompt layer)     ← First line of defense
  ↓ (bypassed by injection?)
skill-guard hook (runtime layer) ← Catches leaked content
  ↓ (blocked)
refusal notice → user
```

This is complementary, not redundant. The prompt layer prevents the model from generating skill content; the hook layer catches it if the model generates it anyway.
