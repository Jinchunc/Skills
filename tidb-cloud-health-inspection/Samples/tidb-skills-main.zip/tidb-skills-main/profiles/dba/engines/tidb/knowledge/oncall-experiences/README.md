# Oncall Experiences — Case Index

Search this directory by symptom, component, or error pattern to find matching precedent.

## By Component

| Component | Cases |
|-----------|-------|
| TiDB (SQL layer) | `parallel-join-query-oom-on-tidb.md`, `plan-cache-memory-growth-from-varying-parameter-shapes.md`, `plan-cache-skipped-by-short-circuit-predicates.md` |
| TiKV (storage) | `empty-range-seeks-cause-tikv-cpu-spikes.md`, `gc-stw-causes-simple-query-latency-jitter.md`, `storage-iops-saturation-from-read-heavy-query.md` |
| TiFlash | `tiflash-cop-overload-without-mpp.md` |
| Statistics | `stale-stats-after-bulk-data-change.md`, `force-init-stats-leaves-pseudo-stats-after-restart.md`, `new-tidb-instance-starts-without-stats.md` |
| Optimizer / Plan | `cost-model-v1-picks-the-wrong-engine.md`, `order-by-limit-picks-the-ordering-index.md`, `huge-in-list-falls-back-to-index-full-scan.md` |
| SQL Binding | `global-bindings-override-hints.md`, `binding-cache-quota-blocks-baselines.md`, `binding-digest-truncated-by-stmt-summary-limit.md`, `bindings-for-single-and-multi-value-in-lists-do-not-match.md`, `direct-delete-bind-info-leaves-stale-binding-cache.md` |
| DDL / Internal | `ddl-owner-memory-leak-from-internal-session-pool.md`, `analyze-jobs-run-too-long-or-too-hot.md` |

## By Symptom

| Symptom | Cases |
|---------|-------|
| OOM / Memory | `parallel-join-query-oom-on-tidb.md`, `plan-cache-memory-growth-from-varying-parameter-shapes.md`, `ddl-owner-memory-leak-from-internal-session-pool.md` |
| Latency jitter | `gc-stw-causes-simple-query-latency-jitter.md`, `new-tidb-instance-starts-without-stats.md` |
| CPU spike | `empty-range-seeks-cause-tikv-cpu-spikes.md`, `tiflash-cop-overload-without-mpp.md` |
| IOPS saturation | `storage-iops-saturation-from-read-heavy-query.md` |
| Plan regression | `stale-stats-after-bulk-data-change.md`, `cost-model-v1-picks-the-wrong-engine.md`, `force-init-stats-leaves-pseudo-stats-after-restart.md` |
| Binding failure | `global-bindings-override-hints.md`, `binding-cache-quota-blocks-baselines.md`, `binding-digest-truncated-by-stmt-summary-limit.md` |
