# PATH-IO-HIGH (S1.11 Abnormally High IO) <!-- Reason for change: unified as S1.x performance troubleshooting sub-number -->

> Entry condition: Disk IOPS / bandwidth / IO wait is abnormally high

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm IO Anomaly

```
metrics (prefer node_* metrics; Clinic may not support them):
  disk_iops, disk_throughput, disk_latency

fallback (TiKV internal metrics):
  write_latency: tikv_engine_write_micro_seconds{tidb_cluster_id="{cluster_id}", type="write_wal"} P99
  read_latency:  tikv_engine_read_micro_seconds{tidb_cluster_id="{cluster_id}"} P99
```

### Step 2: Write IO or Read IO

**Write IO high:**
→ [MODULE-TIKV](../modules/tikv-fast-tune.md) S3_COMPACTION_FLOW (compaction?)
→ MODULE-TIKV W_WAL_SYNC (WAL fsync slow?)

**Read IO high:**
→ MODULE-TIKV R5A_CACHE (block cache miss?)
→ MODULE-TIKV R5B_SST (compaction lagging?)

### Step 3: Has IO Reached Hardware Limits

```
metrics:
  write_wal_p99: histogram_quantile(0.99, sum(rate(tikv_engine_write_micro_seconds_bucket{tidb_cluster_id="{cluster_id}", type="write_wal"}[2m])) by (le, instance))

condition:
  write_wal_p99 > 10ms → IO latency anomaly (normal < 2ms SSD)
  Starter/Essential: raftlog disk IOPS default quota 500 → easily maxed out during write-intensive workloads
  → DIAGNOSIS + recommend increasing IOPS quota or upgrading disk tier

Bandwidth approaching quota:
  compaction traffic + WAL traffic approaching disk throughput limit
  → DIAGNOSIS + recommend upgrading disk tier or increasing max-background-jobs (default 9, can increase to 12)
```

---

## Data Source Call Templates

### TiKV Write Latency (WAL)
```
query: histogram_quantile(0.99, sum(rate(tikv_engine_write_micro_seconds_bucket{tidb_cluster_id="{cluster_id}", type="write_wal"}[2m])) by (le))
```

### Compaction Traffic
```
query: sum(rate(tikv_engine_compaction_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### Block Cache Hit Rate
```
query: sum(rate(tikv_engine_block_cache_hit{tidb_cluster_id="{cluster_id}"}[2m])) / (sum(rate(tikv_engine_block_cache_hit{tidb_cluster_id="{cluster_id}"}[2m])) + sum(rate(tikv_engine_block_cache_miss{tidb_cluster_id="{cluster_id}"}[2m])))
```

---

## Remediation References

- TiKV troubleshooting (compaction, WAL, block cache): [../../knowledge/troubleshooting-guide.md](../../knowledge/troubleshooting-guide.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
