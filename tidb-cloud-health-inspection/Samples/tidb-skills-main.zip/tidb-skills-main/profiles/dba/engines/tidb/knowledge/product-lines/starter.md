# TiDB Cloud Starter

> Starter tier of TiDB X — serverless dev/test tier. Logical clusters (keyspaces) run on shared physical pools with the smallest quotas and the most observability gaps.
>
> **Start here for architecture:** [tidb-x.md](tidb-x.md) covers the shared two-layer model (logical cluster vs physical pool) that Starter shares with Essential and Premium.

---

## What Starter Is

- **Logical cluster = keyspace**: each Starter cluster ID (`10...`) is a keyspace inside a shared physical pool (`20...`).
- **Shared infrastructure**: TiKV/PD nodes are shared with other Starter/Essential clusters.
- **Smallest quotas**: RCU and IOPS limits are lower than Essential.
- **Highest observability gaps**: metrics frequently 500, no aggregated log-stats, no TopSQL, no profiles.
- **Intended use**: development, testing, and light production workloads.

---

## Resource & Quota Characteristics

| Resource | Typical Limit / Behavior | Diagnostic Impact |
|----------|--------------------------|-------------------|
| IOPS | Quota-limited, often lower than Essential | Easier to hit IOPS ceiling under load |
| RCU | Request Capacity Unit metering with low limit | Throttling is common during bursts |
| Storage | Shared physical disk; per-cluster allocation | Do NOT use raw TiKV disk metrics as cluster usage |
| TiKV/PD | Shared across pool | TiKV gRPC metrics include other tenants |

---

## Cluster Enumeration

Same as TiDB X common model:

1. Use Clinic API `/clinic/api/v1/dashboard/clusters`
2. Keep `deployType=starter` AND `active=true` (ID pattern `10...`)
3. Exclude `deployType=nextgen-host` physical pools (ID pattern `20...`)
4. Record `parentID` for resource-pool mapping

See [tidb-x.md](tidb-x.md) § Cluster Enumeration for full details.

---

## Metrics Strategy

| What you need | Recommended source | Why |
|---------------|-------------------|-----|
| Business QPS / latency | SQL-layer metrics: `tidb_server_query_total`, `tidb_server_handle_query_duration_seconds_*` | TiKV metrics are pool-level aggregates |
| RCU utilization | `serverless_metering_rcu_provisioned_capacity` / `resource_manager_resource_unit_service_limit` via `keyspace_id` | RCU is keyspace-scoped |
| IOPS saturation | Disk metrics from Clinic DataPlane or O11Y infra UUID | Common Starter bottleneck |
| Storage growth | Per-cluster allocation metrics | Raw TiKV store size is multi-tenant |

**Note:** Starter metrics are the most likely to return HTTP 500 or be unavailable. Always fail-open and use slow-query / Loki evidence as fallback.

---

## Log & Slow Query Access

- **Loki only**: `{namespace="tidb-pool", container="tidb", cluster="<pool-name>"} |= "keyspaceID=<id>"`
- **Slow queries**: S3 raw files or Loki `container="slowlog"` filtered by keyspace
- **No aggregated log-stats SQLite**, no TopSQL, no continuous profiles

See [o11y-data.md](../../../providers/tidb-cloud/o11y/o11y-data.md) § Deploy Type: Starter / Essential for full access paths.

---

## Common Starter-Specific Issues

| Symptom | Root Cause Clue | Recommendation |
|---------|-----------------|----------------|
| QPS ceiling at low load | IOPS or RCU quota exhausted | Check RCU provisioned/limit and disk IOPS |
| Latency spikes under burst | RC queueing (`time_queued_by_rc` > 0) | Smooth workload or increase provisioned RCU |
| Metrics unavailable | Clinic DataProxy 500 for Starter | Mark N/A and use slowlog/Loki |
| Small table hotspot | Leaders concentrate on one TiKV | Pre-populate data or shard hot tables |

---

## RCU Check

For Starter, RCU checks require the `keyspace_id` (not `cluster_id`):

```
provisioned: sum(serverless_metering_rcu_provisioned_capacity{keyspace_id="{keyspace_id}"})
limit:       resource_manager_resource_unit_service_limit{namespace="tidb-serverless", name="{keyspace_id}"}
```

See [rcu-check.md](../rcu-check.md) § Branch A for the full Starter/Essential RCU throttling decision tree.

---

## Related References

- [tidb-x.md](tidb-x.md) — TiDB X common architecture and enumeration
- [essential.md](essential.md) — next-tier shared-pool product with higher quotas
- [premium.md](premium.md) — larger TiDB X tier with autoscaling
- [dedicated.md](dedicated.md) — single-tenant Gardener shoots
- [rcu-check.md](../rcu-check.md) — RCU throttling check
- [o11y-data.md](../../../providers/tidb-cloud/o11y/o11y-data.md) — observability data access by deploy type
