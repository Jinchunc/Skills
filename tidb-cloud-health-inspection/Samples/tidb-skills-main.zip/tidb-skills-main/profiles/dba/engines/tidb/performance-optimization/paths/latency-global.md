# PATH-LATENCY-GLOBAL (S1.1 Overall Query Latency Increase)

> Entry condition: User reports overall query latency increase (not a single SQL), e.g., "P99 went from 10ms to 500ms"

---

## Prerequisites

1. **MODULE-CLUSTER-ID** — Determine cluster_id, product_line, metrics_endpoint
2. Time range [start, end]
3. Baseline period (default: same time window 24h before the problem period)

---

## Decision Tree

### Step 1: Confirm Latency Anomaly (Multi-Dimensional Detection)

```
metrics:
  p99:   histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  p999:  histogram_quantile(0.999, ...)
  p9999: histogram_quantile(0.9999, ...)
  per_instance_p99: ... by (le, instance)

checks (any hit → YES):
  check 1: p99 > baseline_p99 × 2 or > user threshold           → global degradation
  check 2: p999/p99 ratio > baseline_ratio × 3              → tail expansion = some queries abnormal
  check 3: some instance p99 > mean × 2                       → instance-level imbalance
  check 4: some digests have much higher latency than others (Top N slow query)    → SQL-level imbalance

all normal → "Metrics did not confirm latency anomaly, please verify the time range" → END
any hit → record hit check number → Step 2
```

### Step 2: TiDB X Throttling Quick Check

> Only for starter / essential / premium; skip for Dedicated

→ [MODULE-RCU](../../knowledge/rcu-check.md)

| Output | Action |
|------|------|
| SEVERE throttling | DIAGNOSIS: "RCU throttling caused latency increase" → END |
| MILD throttling | FLAG: RCU_MILD_THROTTLE → Step 3 |
| No throttling | → Step 3 |

### Step 3: DB Time Breakdown

→ [MODULE-DBTIME](../modules/db-time.md)

Output bottleneck component and phase → Step 4

### Step 4: Route by Component

| Bottleneck | Next Step |
|------|--------|
| TIKV (kv_write / kv_read / kv_all) | → [MODULE-TIKV](../modules/tikv-fast-tune.md) |
| TIDB (parse/compile) | → [MODULE-TIDB](../modules/tidb-diagnosis.md) |
| PD (tso_wait) | → [MODULE-PD](../modules/pd-diagnosis.md) |
| EXTERNAL | DIAGNOSIS: "Bottleneck is outside the cluster (client/network/proxy)" → END |

### Step 5: (Optional) SQL-Level Cross Validation

> Trigger: Step 3 identified KV layer, or Step 1 check 4 hit

→ [MODULE-SQL](../modules/sql-diagnosis.md) (SQL_IDENTIFY, Top 10 slow queries)

Confirm whether specific SQL contributes to the main latency → append to diagnosis conclusion → END

---

## Data Source Call Templates

### Query Duration P99/P999
```
query: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
query: histogram_quantile(0.999, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Per-Instance P99
```
query: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, instance))
```

---

## Remediation References

When root cause routes to SQL/plan-level (Step 5), load the relevant tuning reference:
- Full remediation routing table: [../modules/sql-diagnosis.md — Remediation section](../modules/sql-diagnosis.md#remediation--tuning-references)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
