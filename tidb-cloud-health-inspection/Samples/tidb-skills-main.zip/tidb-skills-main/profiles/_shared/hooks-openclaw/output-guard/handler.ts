// Output Guard Hook for OpenClaw
//
// Minimal post-processing guard for outbound messages. Only handles issues
// that prompt-layer rules (agent rules) cannot prevent:
//
//   1. Garbled text — model output corruption (hard block + replace)
//   2. Excessive length — append guidance to write to local file
//      (does NOT truncate — avoids breaking tables/code blocks mid-stream)
//
// Everything else (narration, formatting, tone) is enforced at prompt layer
// via agent rules #34/#35 and the communication-protocol skill.

import { appendFile, writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';

// Default audit directory — override via AUDIT_DIR env var
const AUDIT_DIR = process.env.AUDIT_DIR || join(process.env.HOME || '/tmp', '.openclaw', 'audit');

// ── Configuration ──────────────────────────────────────────
const LONG_THRESHOLD = 30;           // DM: lines above this get a guidance nudge
const LONG_THRESHOLD_GROUP = 20;     // Group chat: stricter
const GARBLED_THRESHOLD = 0.15;      // >15% unexpected Unicode → garbled

// ── Garbled text detection ─────────────────────────────────
// CJK + Latin + Cyrillic + common punctuation/symbols are expected.
// High density of other scripts mixed into a CJK/Latin message
// suggests model output corruption.
const EXPECTED_RANGES = /[\u0000-\u024F\u0400-\u04FF\u2000-\u206F\u2E80-\u9FFF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\u{20000}-\u{2FA1F}]/u;

function detectGarbled(text: string): boolean {
  if (text.length < 50) return false;

  const start = Math.max(0, Math.floor(text.length / 2) - 250);
  const sample = text.substring(start, start + 500);

  let unexpected = 0;
  let total = 0;
  for (const char of sample) {
    if (/\s/.test(char)) continue;
    total++;
    if (!EXPECTED_RANGES.test(char)) {
      unexpected++;
    }
  }

  if (total === 0) return false;
  return (unexpected / total) > GARBLED_THRESHOLD;
}

// ── Guidance messages ──────────────────────────────────────
const GARBLED_REPLACEMENT =
  '[OUTPUT-GUARD] Response blocked — garbled/corrupted output detected.\n' +
  'Action: Regenerate your response. If the issue persists, simplify the output.';

const LENGTH_GUIDANCE =
  '\n\n---\n' +
  '[OUTPUT-GUARD] This response is long. Next time, write full content to a local file first, ' +
  'then send a concise summary (≤20 lines). See agent rule #39 (Report-Local-First).';

// ── Audit logging ──────────────────────────────────────────
async function ensureDir(dir: string): Promise<void> {
  if (!existsSync(dir)) {
    await mkdir(dir, { recursive: true });
  }
}

async function logEvent(event: string, details: Record<string, unknown>): Promise<void> {
  const entry = JSON.stringify({
    ts: new Date().toISOString(),
    event,
    ...details,
  }) + '\n';

  const today = new Date().toISOString().split('T')[0];
  const filePath = join(AUDIT_DIR, `audit-${today}.jsonl`);

  try {
    await ensureDir(AUDIT_DIR);
    if (existsSync(filePath)) {
      await appendFile(filePath, entry, 'utf-8');
    } else {
      await writeFile(filePath, entry, 'utf-8');
    }
  } catch {
    console.error('[output-guard] Failed to write audit log');
  }
}

// ── Main hook ──────────────────────────────────────────────
export default {
  name: 'output-guard',
  version: '1.0.0',

  hooks: {
    message: async (context: Record<string, unknown>) => {
      if (context.direction !== 'out' || !context.text) return;

      const text = context.text as string;

      // ── Check 1: Garbled text (hard block) ──
      if (detectGarbled(text)) {
        console.log('[output-guard] BLOCKED — garbled text detected');
        await logEvent('output_guard_block', {
          reason: 'garbled',
          preview: text.substring(0, 200).replace(/\n/g, '\\n'),
        });
        context.text = GARBLED_REPLACEMENT;
        return;
      }

      // ── Check 2: Length guidance (soft nudge, no truncation) ──
      const lineCount = text.split('\n').length;
      const isGroup = context.conversationType === 'group' ||
                      context.conversationType === '2' ||
                      context.chatType === 'group';
      const limit = isGroup ? LONG_THRESHOLD_GROUP : LONG_THRESHOLD;

      if (lineCount > limit) {
        context.text = text + LENGTH_GUIDANCE;
        await logEvent('output_guard_long', {
          lines: lineCount,
          limit,
          is_group: isGroup,
        });
        console.log(`[output-guard] Long output (${lineCount} lines, limit ${limit}) — guidance appended`);
      }
    },
  },
};
