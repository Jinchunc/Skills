#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Usage:
  cleanup_aws.sh [--plan|--apply]

Destroys the TiUP cluster, terminates EC2 cluster nodes, detaches and deletes
the MinIO EBS volume, revokes control-host MinIO ingress, and deletes the
cluster security group. Defaults to --plan.
USAGE
}

action="${1:---plan}"
case "$action" in
  --plan) apply=0 ;;
  --apply) apply=1 ;;
  --help) usage; exit 0 ;;
  *) usage; exit 1 ;;
esac

STATE_FILE="${STATE_FILE:-./tidbx-aws-multinode.state.env}"
load_state_file "$STATE_FILE"

require_env PROFILE REGION CLUSTER_NAME CONTROL_PUBLIC_IP CONTROL_SG CLUSTER_SG ALL_INSTANCE_IDS MINIO_VOLUME_ID

SSH_USER="${SSH_USER:-admin}"
SSH_OPTS_DEFAULT="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
SSH_OPTS="${SSH_OPTS:-$SSH_OPTS_DEFAULT}"
PRESERVE_CONTROL_HOST="${PRESERVE_CONTROL_HOST:-1}"

if [ "$apply" -eq 0 ]; then
  cat <<EOF
PLAN ONLY: no resources will be deleted.
To apply, rerun: STATE_FILE="$STATE_FILE" $0 --apply

Will delete:
  TiUP cluster: $CLUSTER_NAME via $SSH_USER@$CONTROL_PUBLIC_IP
  EC2 instances: $ALL_INSTANCE_IDS
  MinIO volume: $MINIO_VOLUME_ID
  cluster SG: $CLUSTER_SG
  control SG ingress 9000-9001 from cluster SG: $CONTROL_SG <- $CLUSTER_SG
Preserve control host: $PRESERVE_CONTROL_HOST
EOF
  if [ "$PRESERVE_CONTROL_HOST" != "1" ]; then
    cat <<EOF
  control instance: ${CONTROL_INSTANCE_ID:-<missing CONTROL_INSTANCE_ID>}
  control SG: $CONTROL_SG
EOF
  fi
  exit 0
fi

need_cmd aws
need_cmd ssh

ssh_args=()
if [ -n "$SSH_OPTS" ]; then
  # shellcheck disable=SC2206
  ssh_args=($SSH_OPTS)
fi
if [ -n "${SSH_KEY_PATH:-}" ]; then
  [ -f "$SSH_KEY_PATH" ] || die "missing SSH key: $SSH_KEY_PATH"
  ssh_args+=(-i "$SSH_KEY_PATH")
fi

if [ "$PRESERVE_CONTROL_HOST" != "1" ]; then
  require_env CONTROL_INSTANCE_ID
fi

ssh "${ssh_args[@]}" "$SSH_USER@$CONTROL_PUBLIC_IP" \
  "export PATH=\$HOME/.tiup/bin:\$PATH; tiup cluster destroy $CLUSTER_NAME -y"

aws --profile "$PROFILE" --region "$REGION" ec2 terminate-instances \
  --instance-ids $ALL_INSTANCE_IDS
aws --profile "$PROFILE" --region "$REGION" ec2 wait instance-terminated \
  --instance-ids $ALL_INSTANCE_IDS

ssh "${ssh_args[@]}" "$SSH_USER@$CONTROL_PUBLIC_IP" \
  'sudo systemctl stop minio 2>/dev/null || true; sudo umount /minio 2>/dev/null || true' || true
aws --profile "$PROFILE" --region "$REGION" ec2 detach-volume \
  --volume-id "$MINIO_VOLUME_ID" || true

aws --profile "$PROFILE" --region "$REGION" ec2 revoke-security-group-ingress \
  --group-id "$CONTROL_SG" \
  --ip-permissions "IpProtocol=tcp,FromPort=9000,ToPort=9001,UserIdGroupPairs=[{GroupId=$CLUSTER_SG}]" || true

aws --profile "$PROFILE" --region "$REGION" ec2 wait volume-available \
  --volume-ids "$MINIO_VOLUME_ID"
aws --profile "$PROFILE" --region "$REGION" ec2 delete-volume \
  --volume-id "$MINIO_VOLUME_ID"
aws --profile "$PROFILE" --region "$REGION" ec2 delete-security-group \
  --group-id "$CLUSTER_SG"

if [ "$PRESERVE_CONTROL_HOST" != "1" ]; then
  aws --profile "$PROFILE" --region "$REGION" ec2 terminate-instances \
    --instance-ids "$CONTROL_INSTANCE_ID"
  aws --profile "$PROFILE" --region "$REGION" ec2 wait instance-terminated \
    --instance-ids "$CONTROL_INSTANCE_ID"
  aws --profile "$PROFILE" --region "$REGION" ec2 delete-security-group \
    --group-id "$CONTROL_SG"
fi

log "Cleanup complete"
