# Top-Level Commands

Base command: `ticloud`

CLI tool to manage TiDB Cloud

## Direct Subcommands

- `ticloud ai` - Chat with TiDB Bot
- `ticloud auth` - Login and logout via TiDB Cloud API
- `ticloud completion` - Generate the autocompletion script for the specified shell
- `ticloud config` - Configure and manage your user profiles
- `ticloud project` - Manage projects
- `ticloud serverless` - Manage TiDB Cloud Serverless clusters
- `ticloud upgrade` - Upgrade the CLI to the latest version (sensitive)
