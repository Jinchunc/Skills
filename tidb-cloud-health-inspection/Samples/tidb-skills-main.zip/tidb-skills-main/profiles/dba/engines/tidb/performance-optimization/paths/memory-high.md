# PATH-MEMORY-HIGH (S1.10 Abnormally High Memory) <!-- Reason for change: unified as S1.x performance troubleshooting sub-number -->

> Entry condition: Memory usage deviates from baseline (continuous increase / sudden spike)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Identify Which Component Has High Memory

```
metrics:
  tidb_mem{tidb_cluster_id="{cluster_id}"}: process_resident_memory_bytes{job="tidb", tidb_cluster_id="{cluster_id}"}
  tikv_mem{tidb_cluster_id="{cluster_id}"}: process_resident_memory_bytes{job="tikv", tidb_cluster_id="{cluster_id}"}
```

### Step 2a: TiDB High Memory

```
Check for large SQL:
  → MODULE-SQL: slow_query_logs sorted by mem_max DESC

Check for connection count growth:
  tidb_server_connections{tidb_cluster_id="{cluster_id}"} by (instance)
  More connections = more session memory

Check for prepared statement leak:
  tidb_server_prepared_stmts{tidb_cluster_id="{cluster_id}"} by (instance)
  Continuous growth without decline → prepared statement leak

Continuous increase without decline → suspected memory leak → record trend + recommend restart
Increases with load → normal → check if memory quota is sufficient
```

→ [MODULE-SQL](../modules/sql-diagnosis.md)

### Step 2b: TiKV High Memory

```
Block cache:
  tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
  Should be stable near the configured value (default = system memory × 45%; Cloud 4c16g actual limit ~13GB, 8c32g actual limit ~28GB)

Region count:
  tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
  Every 10K Regions ≈ 500MB metadata memory (source: troubleshooting-guide.md); 100K Regions ≈ 5GB

Write buffer:
  tikv_engine_write_buffer_manager_memory_usage_bytes{tidb_cluster_id="{cluster_id}"} by (instance)

Compaction lagging → memtable accumulation:
  → MODULE-TIKV S2_WRITE_STALL

About to OOM → PATH-OOM
```

→ [MODULE-TIKV](../modules/tikv-fast-tune.md)

### Step 3: Baseline Comparison

Same time window historical data vs current → deviation magnitude + duration → DIAGNOSIS

---

## Data Source Call Templates

### Memory Usage
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"} by (instance)
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"} by (instance)
```

### TiKV Block Cache
```
query: tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Region Count
```
query: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiKV Write Buffer Memory
```
query: tikv_engine_write_buffer_manager_memory_usage_bytes{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiDB Connection Count
```
query: tidb_server_connections{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiDB Prepared Statements
```
query: tidb_server_prepared_stmts{tidb_cluster_id="{cluster_id}"} by (instance)
```

---

## Remediation References

When root cause is SQL-driven memory (Step 2a large SQL), load the relevant tuning reference:
- Full remediation routing table: [../modules/sql-diagnosis.md — Remediation section](../modules/sql-diagnosis.md#remediation--tuning-references)
- Join strategy optimization: [../references/sql-optimization.md](../references/sql-optimization.md)
- Subquery optimization: [../references/sql-optimization.md](../references/sql-optimization.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
