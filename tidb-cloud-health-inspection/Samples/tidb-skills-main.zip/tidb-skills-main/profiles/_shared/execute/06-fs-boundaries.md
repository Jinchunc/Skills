### File System Boundaries

| # | Rule | Detail |
|---|------|--------|
| 22 | **Project directory only** | File ops within project or workspace dir. Exempt: memory files, skills dirs (with approval), napkin.md. |
| 23 | **No system config modification** | `~/.bashrc`, `~/.gitconfig`, `/etc/hosts` — only if explicitly requested. |
| 24 | **Validate write paths** | Resolve absolute → confirm within boundary. Escape → abort and notify. Prefer project-local temp dirs. |
