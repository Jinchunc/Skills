# PATH-LATENCY-WRITE (S1.3 Write Latency Increase)

> Entry condition: User reports write operations (INSERT/UPDATE/DELETE) becoming slow

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range [start, end]

---

## Decision Tree

### Step 1: Confirm Write Latency Anomaly (Multi-Dimensional Detection)

```
metrics:
  write_p99:  histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type=~"kv_prewrite|kv_commit"}[2m])) by (le))
  write_p999: histogram_quantile(0.999, ...)

checks (any hit → YES):
  check 1: write_p99 vs baseline           → global write degradation (> 50ms or > baseline × 2)
  check 2: write_p999/write_p99 ratio  → tail expansion = some write requests abnormal
  check 3: per-instance write_p99 variance  → certain TiKV instance has slow writes
```

### Step 2: TiDB X Throttling Quick Check

> Only for TiDB X product line

→ [MODULE-RCU](../../knowledge/rcu-check.md)
Throttling detected → DIAGNOSIS → END

### Step 3: TiKV Write Path Diagnosis

→ [MODULE-TIKV](../modules/tikv-fast-tune.md) Write subtree (S1_BALANCE → S2_WRITE_STALL → S4_ASYNC_WRITE → ...)

### Step 4: Transaction Conflict Check

```
metrics:
  latch_wait: histogram_quantile(0.99, sum(rate(tikv_scheduler_latch_wait_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  lock_resolve: sum(rate(tidb_tikvclient_lock_resolver_actions_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

condition: latch_wait_p99 > 10ms or lock_resolve rate > 0 sustained for > 1min
YES → go to PATH-TXN-CONFLICT
```

### Step 5: TiDB Side Check

> Trigger: TiKV is normal but writes are still slow

→ [MODULE-TIDB](../modules/tidb-diagnosis.md) (connection balancing, goroutine pressure)

---

## Data Source Call Templates

### Write Latency P99/P999
```
query: histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type=~"kv_prewrite|kv_commit"}[2m])) by (le))
query: histogram_quantile(0.999, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type=~"kv_prewrite|kv_commit"}[2m])) by (le))
```

### Per-Instance Write Latency
```
query: histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type=~"kv_prewrite|kv_commit"}[2m])) by (le, instance))
```

---

## Remediation References

After completing the decision tree above, load the relevant reference for remediation guidance:

- TiKV write path troubleshooting: [../../knowledge/troubleshooting-guide.md](../../knowledge/troubleshooting-guide.md)
- Session/global variable tuning: [../references/session-variables.md](../references/session-variables.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
