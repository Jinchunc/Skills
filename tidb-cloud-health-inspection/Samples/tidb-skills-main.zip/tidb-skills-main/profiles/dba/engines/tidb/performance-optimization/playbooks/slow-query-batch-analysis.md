# PLAYBOOK: Slow Query Batch Analysis

> Proactive batch analysis of slow queries — find patterns, rank by impact, identify systemic vs individual issues.
> Differs from PATH-SQL-SLOW (reactive, single SQL) — this playbook processes ALL slow queries in a time window.

---

## When to Use

- Cluster inspection (S5) performance section
- "Why is the cluster slow?" without a specific SQL
- Periodic slow query review
- Post-incident: "What was affected during the outage window?"

## Prerequisites

1. **MODULE-CLUSTER-ID** completed
2. Time window [start, end] (default: last 24h)
3. O11Y access (slowlogs via DuckDB) or Clinic API fallback

---

## Phase 1: Harvest — Collect All Slow Queries

### Step 1.1: Multi-Dimension Top N

Run all 4 queries to get a complete picture. Each dimension reveals different problems.

**By Total Time Impact** (execution_time × frequency = total cluster time consumed):
```sql
SELECT digest, digest_text,
       COUNT(*) AS exec_count,
       AVG(query_time) AS avg_qt,
       MAX(query_time) AS max_qt,
       SUM(query_time) AS total_qt,
       AVG(process_keys) AS avg_proc_keys
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY total_qt DESC
LIMIT 20
```

**By Peak Latency** (worst-case user experience):
```sql
SELECT digest, digest_text,
       MAX(query_time) AS max_qt,
       COUNT(*) AS cnt,
       MAX(mem_max) AS max_mem
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY max_qt DESC
LIMIT 20
```

**By Frequency** (high-frequency moderate-slow queries often hurt more than rare extreme ones):
```sql
SELECT digest, digest_text,
       COUNT(*) AS cnt,
       AVG(query_time) AS avg_qt,
       SUM(query_time) AS total_qt
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY cnt DESC
LIMIT 20
```

**By Resource Consumption** (memory/disk heavy queries risk OOM):
```sql
SELECT digest, digest_text,
       MAX(mem_max) AS max_mem,
       MAX(disk_max) AS max_disk,
       MAX(total_keys) AS max_keys,
       COUNT(*) AS cnt
FROM slowlogs
WHERE date = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, digest_text
ORDER BY max_mem DESC
LIMIT 20
```

### Step 1.2: Deduplicate and Rank

Merge the 4 lists into a unified ranking:

| Priority | Criteria |
|----------|----------|
| **P0 — Critical** | total_qt > 30% of window duration, OR max_mem > 2GB, OR cnt > 1000 |
| **P1 — High** | Appears in 3+ Top N lists, OR total_qt > 10% of window |
| **P2 — Medium** | Appears in 2 Top N lists |
| **P3 — Low** | Appears in only 1 list |

Output: `ranked_digests[]` — ordered list of digests to analyze.

---

## Phase 2: Pattern Detection — Systemic vs Individual

### Step 2.1: Temporal Distribution

For each P0/P1 digest, check whether slowness is concentrated or spread:

```sql
SELECT digest,
       DATE_TRUNC('minute', to_timestamp(time)) AS minute_bucket,
       COUNT(*) AS cnt,
       AVG(query_time) AS avg_qt
FROM slowlogs
WHERE digest IN ({p0_p1_digests})
  AND "date" = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
GROUP BY digest, minute_bucket
ORDER BY minute_bucket
```

**Pattern Classification:**

| Pattern | Signature | Likely Cause |
|---------|-----------|-------------|
| **Spike** | 80%+ in a 5-min window | Infrastructure event (GC, compaction, scheduling) |
| **Steady** | Evenly distributed | Inherent SQL issue (missing index, bad plan) |
| **Periodic** | Repeating pattern | Cron job, batch processing, statistics collection |
| **Escalating** | Worsening over time | Data growth, MVCC accumulation, resource exhaustion |

### Step 2.2: Cross-Digest Correlation

If multiple digests spike at the same time → systemic issue (not individual SQL).

```
Check: Do 3+ digests share a spike window?
  YES → Systemic: Route to MODULE-DBTIME → MODULE-TIKV/TIDB/PD
  NO  → Individual: Analyze each digest via MODULE-SQL (SQL_ROOT_CAUSE)
```

### Step 2.3: Common Root Cause Signatures

| Signature across multiple digests | Root Cause | Next Step |
|-----------------------------------|-----------|-----------|
| All have high `cop_proc_avg` | TiKV overloaded | MODULE-TIKV |
| All have high `cop_wait_avg` | Coprocessor thread pool saturated | MODULE-TIKV R2A_COPR_THREADS |
| All have `backoff_types = txnLock` | Lock contention cascade | PATH-TXN-CONFLICT |
| All have `total_keys >> process_keys` | MVCC accumulation | MODULE-TIKV R6_GC |
| Spike correlates with compaction | Write stall | MODULE-TIKV (compaction subtree) |

---

## Phase 3: Per-Digest Deep Dive

For each P0/P1 digest (limit to top 5 to avoid analysis paralysis):

### Step 3.1: Execution Plan Retrieval

```sql
SELECT decoded_plan, query_time, total_keys, process_keys,
       mem_max, disk_max, backoff_types, cop_proc_avg, cop_wait_avg
FROM slowlogs
WHERE digest = '{digest}'
  AND "date" = '{date}'
  AND time BETWEEN {start_ts} AND {end_ts}
ORDER BY query_time DESC
LIMIT 5
```

### Step 3.2: Plan Stability Check

Compare plans across the time window:

```
Multiple decoded_plan values for the same digest?
  YES → Plan regression (statistics change, schema change, or optimizer behavior change)
       → Route to PLAYBOOK-EXECUTION-PLAN-COMPARE
  NO  → Plan is stable, root cause is elsewhere
```

### Step 3.3: Root Cause via MODULE-SQL

→ [MODULE-SQL](../modules/sql-diagnosis.md) SQL_ROOT_CAUSE decision tree for each digest.

---

## Phase 4: Report

### Output Format

```
## Slow Query Batch Analysis Report
Cluster: {cluster_id} | Window: {start} ~ {end}
Total slow queries: {count} | Unique digests: {unique}

### Summary
- Systemic issue detected: YES/NO
  - If YES: {root cause} affecting {N} digests
- Top impact digest: {digest_text} (total_qt: Xs, count: N)

### P0 Findings (Immediate Action)
| # | Digest | Pattern | Root Cause | Confidence | Recommendation |
|---|--------|---------|-----------|------------|----------------|

### P1 Findings (Planned Action)
| # | Digest | Pattern | Root Cause | Confidence | Recommendation |

### Systemic Observations
- {patterns detected across multiple queries}
- {infrastructure bottlenecks identified}

### Data Gaps
- {metrics/data that were unavailable}
```

---

## Relationship to Other Components

| Component | Relationship |
|-----------|-------------|
| PATH-SQL-SLOW | Single SQL reactive diagnosis; this playbook calls it for per-digest analysis |
| MODULE-SQL | Core analysis engine; this playbook orchestrates batch calls |
| MODULE-DBTIME | Called when systemic pattern detected |
| PLAYBOOK-EXECUTION-PLAN-COMPARE | Called when plan instability detected for a digest |
| S5 Inspection | This playbook is the "Optimization Items" section of inspection |
