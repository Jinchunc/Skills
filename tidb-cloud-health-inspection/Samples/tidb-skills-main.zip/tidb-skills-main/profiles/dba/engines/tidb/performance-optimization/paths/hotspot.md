# PATH-HOTSPOT (S1.15 Hotspot Imbalance) <!-- Modification reason: Unified as S1.x performance troubleshooting sub-number -->

> Entry condition: Load concentrated on a few instances, e.g. "requests concentrated on one TiKV / severely unbalanced load"

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm Imbalance

```
metrics:
  per_instance_qps: sum(rate(tikv_grpc_msg_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
  per_instance_cpu: rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m]) by (instance)
  per_instance_flow: sum(rate(tikv_engine_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

condition: An instance with QPS/CPU > average x 2 (or an instance with Slow Score reaching 100 -> PD auto-evicts leader, v7.5+)
```

### Step 2: Read Hotspot or Write Hotspot

**Write Hotspot:**
```
Check Region leader distribution:
  tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"} by instance

Check if auto-increment primary key / monotonically increasing index:
  -> MODULE-SQL: Check write Top SQL and involved tables
  -> DIAGNOSIS + recommendations:
    - SHARD_ROW_ID_BITS (suggest user to execute)
    - AUTO_RANDOM primary key
    - Randomize write keys
```

**Read Hotspot:**
```
Check if a specific Region has extremely high read QPS
Small table fully cached + follower read to mitigate
-> DIAGNOSIS + recommendations:
  - SET tidb_replica_read{tidb_cluster_id="{cluster_id}"} = 'follower' (suggest user to execute)
  - Enable TiFlash replicas for small hot tables to offload reads
```

### Step 3: Is PD Scheduling Taking Effect

```
metrics:
  sched_ops: pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"} (are there balance operations)

Scheduling in progress -> Wait for automatic balancing
Scheduling not in progress -> Check PD configuration:
  - Is balance-leader-scheduler enabled
  - Is store limit too low
-> MODULE-PD
```

---

## Data Source Call Templates

### Per-Instance QPS
```
query: sum(rate(tikv_grpc_msg_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
```

### Per-Instance CPU
```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (instance)
```

### Leader Distribution
```
query: tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"} by (instance)
```

### PD Scheduling Operations
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

---

## Remediation References

When root cause is write hotspot from sequential inserts (Step 2), load the relevant tuning reference:
- Index selection and key design: [../references/sql-optimization.md](../references/sql-optimization.md)
- Full remediation routing table: [../modules/sql-diagnosis.md — Remediation section](../modules/sql-diagnosis.md#remediation--tuning-references)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
