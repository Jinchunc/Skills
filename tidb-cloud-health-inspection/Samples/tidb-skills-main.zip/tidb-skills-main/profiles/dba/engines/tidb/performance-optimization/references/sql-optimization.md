# SQL Optimization

## 1. EXPLAIN Patterns

`EXPLAIN ANALYZE` is the primary tool for understanding how TiDB actually executes a query. It runs the query and reports actual row counts, execution time, and memory usage for each operator.

## Syntax

```sql
-- Basic (text format):
EXPLAIN ANALYZE SELECT ...;

-- Structured JSON format (better for programmatic analysis):
EXPLAIN FORMAT = "tidb_json" SELECT ...;

-- Estimate only (does NOT execute the query):
EXPLAIN SELECT ...;
```

**Use `EXPLAIN ANALYZE` for tuning.** Plain `EXPLAIN` shows estimates only, which may be wrong.

## Key columns in EXPLAIN ANALYZE output

| Column | Meaning |
|--------|---------|
| `id` | Operator name and position in the tree |
| `estRows` | Estimated row count from optimizer statistics |
| `actRows` | Actual row count observed during execution |
| `task` | Where the operator runs: `root` (TiDB), `cop[tikv]` (TiKV coprocessor), `cop[tiflash]` (TiFlash) |
| `access object` | Table, index, or partition being accessed |
| `execution info` | Wall time, loops, memory, disk usage, concurrency |
| `operator info` | Filter conditions, join keys, sort keys |

## What to look for

### 1. estRows vs actRows divergence

Large differences indicate stale or inaccurate statistics.

```
estRows: 100    actRows: 500000   ← Stats are wrong!
```

**Action:** Run `ANALYZE TABLE <table>;` (or with `ALL COLUMNS` if `@@tidb_analyze_column_options` is not `ALL`) and re-check.

### 2. Expensive operators (by wall time)

Look at `execution info` for `time:` values. The operator with the longest time is the bottleneck.

```
execution info: time:2.5s, loops:1, ...   ← This is the bottleneck
```

### 3. Full table scans on large tables

```
TableFullScan   table:orders   actRows:10000000
```

**Action:** Add an index or use a hint to force an index scan.

### 4. Hash join with large build side

```
HashJoin         actRows:50000
├── Build        actRows:5000000   ← Build side is huge
└── Probe        actRows:50000
```

**Action:** Consider `INL_JOIN` if the build side has an index, or `LEADING` to swap build/probe sides.

### 5. Unnecessary Sort operators

```
Sort             actRows:1000000
└── TableFullScan
```

If there's an index that provides the sort order, use `ORDER_INDEX` to eliminate the Sort.

### 6. Apply operator (correlated subquery)

```
Apply            actRows:1000
├── Outer        actRows:1000
└── Inner        actRows:1000   (executed 1000 times)
```

This means correlated execution. If `actRows` on the outer side is small, this is fine. If large, consider letting TiDB decorrelate (remove `NO_DECORRELATE`) or adding an index on the inner side.

## Operator reference

### Scan operators

| Operator | Meaning |
|----------|---------|
| `TableFullScan` | Full table scan — reads every row |
| `TableRangeScan` | Scans a range of the primary key |
| `IndexRangeScan` | Scans a range of an index |
| `IndexFullScan` | Scans the entire index |
| `IndexLookUp` | Two-phase: index scan → table lookup for remaining columns |

### Join operators

| Operator | Meaning |
|----------|---------|
| `HashJoin` | Hash join (look for Build and Probe children) |
| `IndexJoin` | Index nested loop join |
| `MergeJoin` | Sort-merge join |
| `Apply` | Correlated subquery execution (per-row) |

### Aggregation operators

| Operator | Meaning |
|----------|---------|
| `HashAgg` | Hash-based aggregation |
| `StreamAgg` | Stream aggregation (requires sorted input) |

### Other operators

| Operator | Meaning |
|----------|---------|
| `Sort` | Sorts rows (expensive for large datasets) |
| `TopN` | Sort + limit combined (more efficient than separate Sort + Limit) |
| `Selection` | Filters rows (WHERE conditions not pushed to scan) |
| `Projection` | Computes output columns |
| `Limit` | Returns only N rows |

## Diagnostic workflow

```
1. Run EXPLAIN ANALYZE
2. Find the operator with the highest wall time
3. Check estRows vs actRows for that operator and its children
   ├── Big divergence → ANALYZE TABLE <table>; (or with ALL COLUMNS), then re-run
   └── Stats are fine → Operator choice is the problem
4. Identify the pattern:
   ├── Full scan → Add index or USE_INDEX hint
   ├── Wrong join strategy → HASH_JOIN / INL_JOIN hint
   ├── Wrong join order → LEADING hint
   ├── Expensive correlated subquery → Check NO_DECORRELATE guidance
   └── Unnecessary Sort → ORDER_INDEX hint or add sorted index
5. Apply fix and re-run EXPLAIN ANALYZE to verify
```

---

## 2. Index Selection

Good index design is the single highest-impact tuning lever. TiDB's optimizer uses cost-based index selection, but it can choose poorly when stats are stale or cardinality is misestimated.

## Index hints

### USE_INDEX

Force the optimizer to use a specific index:

```sql
SELECT /*+ USE_INDEX(t, idx_status_created) */ *
FROM orders t
WHERE t.status = 'pending' AND t.created_at > '2024-01-01';
```

### IGNORE_INDEX

Prevent use of a specific index (useful for testing whether a different index or table scan is faster):

```sql
SELECT /*+ IGNORE_INDEX(t, idx_old) */ *
FROM orders t
WHERE t.status = 'pending';
```

### USE_INDEX_MERGE

Combine multiple indexes when a query filters on columns covered by different indexes:

```sql
-- Uses both idx_status and idx_region, merges results
SELECT /*+ USE_INDEX_MERGE(t, idx_status, idx_region) */ *
FROM orders t
WHERE t.status = 'pending' OR t.region = 'us-east';
```

Index merge is particularly useful for OR conditions that span different indexes.

### ORDER_INDEX / NO_ORDER_INDEX

Control whether the optimizer uses an index to provide sort order:

```sql
-- Force ordered scan: avoid a Sort operator by reading from index in order
SELECT /*+ ORDER_INDEX(t, idx_created) */ *
FROM orders t
ORDER BY t.created_at DESC
LIMIT 20;

-- Prevent ordered scan: if the optimizer incorrectly chooses a slow ordered scan
SELECT /*+ NO_ORDER_INDEX(t, idx_created) */ *
FROM orders t
WHERE t.status = 'pending'
ORDER BY t.created_at DESC
LIMIT 20;
```

## Composite index design

### Leftmost prefix rule

TiDB (like MySQL) can only use a composite index from the leftmost column onward. An index on `(a, b, c)` supports:
- Queries filtering on `a`
- Queries filtering on `a, b`
- Queries filtering on `a, b, c`
- But NOT queries filtering only on `b` or `c`

### Column ordering guidelines

1. **Equality columns first:** Columns in `=` conditions go leftmost.
2. **Range column last:** The column used in `>`, `<`, `BETWEEN`, or `LIKE 'prefix%'` goes after equality columns.
3. **High-selectivity columns first** (among equality columns): Reduces rows scanned early.

```sql
-- Query: WHERE status = 'active' AND region = 'us' AND created_at > '2024-01-01'
-- Best index: (status, region, created_at)
-- status and region are equality; created_at is range
```

### Covering indexes

If a query only needs columns in the index (plus the primary key), TiDB can serve it from the index alone without a table lookup:

```sql
-- If index is (status, created_at) and PK is id:
-- This query is "covered" — no table lookup needed
SELECT id, status, created_at FROM orders WHERE status = 'pending';
```

## Invisible indexes

Test the impact of dropping an index without actually dropping it:

```sql
-- Make index invisible (optimizer won't use it, but it's still maintained)
ALTER TABLE orders ALTER INDEX idx_old INVISIBLE;

-- Test queries... if performance is fine, drop it
DROP INDEX idx_old ON orders;

-- If queries regressed, make it visible again
ALTER TABLE orders ALTER INDEX idx_old VISIBLE;
```

## Diagnosing index selection issues

### Step 1: Check which index is used

```sql
EXPLAIN SELECT * FROM orders WHERE status = 'pending' AND region = 'us';
```

Look for `IndexRangeScan`, `IndexFullScan`, or `TableFullScan` in the plan.

### Step 2: Check index statistics

```sql
SHOW STATS_HEALTHY WHERE Table_name = 'orders';
SHOW INDEX FROM orders;
```

### Step 3: Compare index choices

```sql
-- Force each candidate index and compare EXPLAIN ANALYZE results
EXPLAIN ANALYZE SELECT /*+ USE_INDEX(orders, idx_status) */ * FROM orders WHERE ...;
EXPLAIN ANALYZE SELECT /*+ USE_INDEX(orders, idx_region) */ * FROM orders WHERE ...;
EXPLAIN ANALYZE SELECT /*+ USE_INDEX(orders, idx_status_region) */ * FROM orders WHERE ...;
```

## Common pitfalls

- **Too many indexes:** Each index adds write overhead and storage. Only create indexes that serve real query patterns.
- **Redundant indexes:** Index `(a, b)` makes a standalone index on `(a)` redundant. Audit with `SHOW INDEX`.
- **Low-selectivity leading column:** An index on `(gender, user_id)` is almost useless if the first column has only 2-3 distinct values and queries don't always filter on it.
- **Stale stats on new indexes:** After creating an index, run `ANALYZE TABLE <table_name>;` (or with `ALL COLUMNS` if `@@tidb_analyze_column_options` is not `ALL`) to collect stats for it. Otherwise the optimizer may not pick it.

---

## 3. Join Strategies

TiDB supports multiple join algorithms. The optimizer picks one based on cost estimation, but stale stats or cardinality misestimation can lead to a wrong choice.

## Available join algorithms

### Hash Join (`HASH_JOIN`)

- **How it works:** Builds a hash table on the smaller (build) side, probes with the larger (probe) side.
- **Best for:** Large equi-joins where neither side has a useful index on the join key.
- **Cost profile:** O(build + probe) in time, O(build side) in memory.
- **Watch out for:** Memory pressure when the build side is large. Check `MEMORY_QUOTA` or `tidb_mem_quota_query`.

### Index Nested Loop Join (`INL_JOIN`)

- **How it works:** For each row on the outer side, probes the inner side using an index lookup.
- **Best for:** Inner table has a good index on the join key; outer side is small to moderate.
- **Cost profile:** O(outer rows × index lookup cost). Very fast when outer side is small.
- **Watch out for:** Outer side cardinality misestimation. If outer side is actually large, this becomes expensive.

### Index Hash Join (`INL_HASH_JOIN`)

- **How it works:** Like INL_JOIN but uses hash matching on the inner side instead of pure index order.
- **Best for:** Similar to INL_JOIN but when inner side needs hash-based matching.

### Merge Join (`MERGE_JOIN`)

- **How it works:** Both sides sorted on join key, then merged in a single pass.
- **Best for:** Both sides already sorted (e.g., from index scans on the join key) or when data is naturally ordered.
- **Cost profile:** O(N + M) after sorting. Sorting cost matters if data isn't pre-sorted.

### Shuffle Hash Join (`SHUFFLE_JOIN`) — MPP only

- **How it works:** Redistributes (shuffles) both sides by join key across TiFlash nodes, then hash joins locally.
- **Best for:** Large-to-large joins in TiFlash where neither side is small enough to broadcast.

### Broadcast Join (`BROADCAST_JOIN`) — MPP only

- **How it works:** Broadcasts the smaller side to all TiFlash nodes, then joins locally.
- **Best for:** One side is small, the other is large. Avoids shuffling the large side.

## Decision guide

```
Both tables small (< 10K rows)?
├── Doesn't matter much. Any strategy works.
│
Is there a good index on the join key of one side?
├── YES → Is the other side small?
│         ├── YES → INL_JOIN (indexed side as inner)
│         └── NO  → Still consider INL_JOIN if indexed side is large but
│                   outer side is moderate. Otherwise HASH_JOIN.
└── NO  → HASH_JOIN (smaller side as build).
          └── Are both sides pre-sorted on join key?
              └── YES → Consider MERGE_JOIN.

Using TiFlash?
├── One side small → BROADCAST_JOIN
└── Both sides large → SHUFFLE_JOIN
```

## Forcing join strategy

```sql
-- Force hash join between orders and customers
SELECT /*+ HASH_JOIN(o, c) */ *
FROM orders o JOIN customers c ON o.cust_id = c.id;

-- Force index join with customers as inner (probed) side
SELECT /*+ INL_JOIN(c) */ *
FROM orders o JOIN customers c ON o.cust_id = c.id;

-- Force join order: join orders and items first, then customers
SELECT /*+ LEADING(o, i, c) */ *
FROM orders o
JOIN items i ON i.order_id = o.id
JOIN customers c ON c.id = o.cust_id;
```

## Common misoptimization patterns

### Pattern: Hash join with huge build side

**Symptom:** `EXPLAIN ANALYZE` shows `HashJoin` with a large `Build` side consuming excessive memory or spilling to disk.

**Fix:** If the inner table has an index on the join key, try `INL_JOIN`:

```sql
SELECT /*+ INL_JOIN(big_table) */ ...
FROM small_table s JOIN big_table b ON s.id = b.ref_id;
```

### Pattern: Index join on a non-selective outer side

**Symptom:** `EXPLAIN ANALYZE` shows `IndexJoin` with a large `actRows` on the outer (driving) side, causing millions of index probes.

**Fix:** Switch to `HASH_JOIN`:

```sql
SELECT /*+ HASH_JOIN(t1, t2) */ ...
FROM t1 JOIN t2 ON t1.id = t2.ref_id
WHERE t1.status = 'active';
```

### Pattern: Wrong join order in multi-way join

**Symptom:** Intermediate join produces a huge result that is then joined with a small table.

**Fix:** Use `LEADING` to force the small table earlier:

```sql
SELECT /*+ LEADING(small, medium, large) */ ...
FROM large l JOIN medium m ON ... JOIN small s ON ...;
```

---

## 4. Subquery Optimization

TiDB's optimizer decorrelates correlated subqueries by default, transforming them into joins. This is usually beneficial but not always. Especially in OLTP workloads. Understanding when to override this behavior is key to tuning subquery performance.

## How TiDB handles subqueries

1. **Decorrelation (default):** TiDB rewrites correlated subqueries (EXISTS, IN, scalar) into semi-joins, anti-semi-joins, or left outer joins. This allows the join to be executed with hash join or index join strategies.

2. **Correlated execution:** The subquery executes once per outer row. This is the fallback when decorrelation is disabled or not possible.

## NO_DECORRELATE

### Hint syntax

Place `NO_DECORRELATE()` inside the subquery's SELECT:

```sql
SELECT *
FROM orders o
WHERE EXISTS (
  SELECT /*+ NO_DECORRELATE() */ 1
  FROM returns r
  WHERE r.order_id = o.id
);
```

The hint applies to EXISTS, IN, and scalar correlated subqueries. TiDB will issue a warning if used on a subquery with no correlated columns (since there is nothing to decorrelate).

**Important:** When `NO_DECORRELATE()` is used on an EXISTS subquery, TiDB automatically injects a `LIMIT 1` into the subquery for early exit — it only needs to find one matching row per outer row.

### Session variable: `tidb_opt_enable_no_decorrelate_in_select`

| Property | Value |
|----------|-------|
| Scope | GLOBAL, SESSION |
| Default | OFF |
| Effect | Automatically applies NO_DECORRELATE behavior to correlated subqueries **in the SELECT list** (scalar subqueries) |

```sql
-- Enable for the session:
SET @@session.tidb_opt_enable_no_decorrelate_in_select = ON;

-- Enable globally:
SET GLOBAL tidb_opt_enable_no_decorrelate_in_select = ON;
```

**What this variable does:** Correlated subqueries in the SELECT list (scalar subqueries) are automatically kept as correlated execution (Apply) instead of being decorrelated into a left outer join. This also enables outer join elimination rules that can remove unnecessary Apply operators when the subquery result is not needed.

**When to use:**
- Your workload has many scalar subqueries in the SELECT list that are well-indexed on the correlation columns.
- The outer queries are generally selective.
- You want a session-wide or global policy rather than adding hints to every query.

**When NOT to use:**
- The SELECT-list subqueries reference large tables without indexes on the correlation columns — correlated execution will be slow.
- The outer queries return many rows — each row triggers a subquery probe.

**Note:** This variable only affects subqueries in the SELECT list. It does NOT affect EXISTS/IN subqueries in the WHERE clause — use the `NO_DECORRELATE()` hint directly for those.

### When to use NO_DECORRELATE

Use `NO_DECORRELATE()` (via hint or variable) when **all** of these are true:

- The **outer query is selective** — it produces few rows (after WHERE filtering), so the subquery executes only a small number of times.
- The **subquery has a good index** on the correlation column(s) — each correlated probe is a fast index lookup.
- The **inner table is large** — decorrelation would build a large hash table or produce a large semi-join build side.

In this scenario, correlated execution does N fast index lookups (where N is small), while decorrelation builds an expensive hash table over the entire inner table.

### When NOT to use NO_DECORRELATE

- The **outer query returns many rows** — correlated execution means many subquery probes, which is slow.
- The **subquery lacks indexes** on the correlation predicate — each probe is a full scan.
- The **inner table is small** — decorrelation into a hash join is cheap and often faster.

### Example: well-indexed EXISTS with selective outer query

```sql
-- Outer query filters orders to a small set; subquery probes returns by indexed order_id.
-- Decorrelation would hash-join the entire returns table. Correlated execution is cheaper.
SELECT *
FROM orders o
WHERE o.status = 'disputed'
  AND o.created_at > '2024-01-01'
  AND EXISTS (
    SELECT /*+ NO_DECORRELATE() */ 1
    FROM returns r
    WHERE r.order_id = o.id
      AND r.reason = 'defective'
  );
```

**Prerequisite:** An index on `returns(order_id, reason)` or at minimum `returns(order_id)`.

### Example: scalar subquery in SELECT list

```sql
-- With variable: automatically keeps the correlated scalar subquery as Apply
SET @@session.tidb_opt_enable_no_decorrelate_in_select = ON;

SELECT
  o.id,
  o.total,
  (SELECT MAX(r.created_at) FROM returns r WHERE r.order_id = o.id) AS last_return_date
FROM orders o
WHERE o.status = 'disputed';

-- Or with hint (works regardless of variable):
SELECT
  o.id,
  o.total,
  (SELECT /*+ NO_DECORRELATE() */ MAX(r.created_at) FROM returns r WHERE r.order_id = o.id) AS last_return_date
FROM orders o
WHERE o.status = 'disputed';
```

### Diagnostic: comparing with and without

```sql
-- Without hint (default decorrelation):
EXPLAIN ANALYZE
SELECT * FROM orders o
WHERE o.status = 'disputed'
  AND EXISTS (SELECT 1 FROM returns r WHERE r.order_id = o.id);

-- With hint (correlated execution):
EXPLAIN ANALYZE
SELECT * FROM orders o
WHERE o.status = 'disputed'
  AND EXISTS (SELECT /*+ NO_DECORRELATE() */ 1 FROM returns r WHERE r.order_id = o.id);
```

Compare total execution time and the operator tree. Look for:
- **With decorrelation:** `HashJoin` + `TableFullScan` on returns → expensive if returns is large.
- **With NO_DECORRELATE:** `Apply` + `IndexLookUp` on returns → cheap if outer rows are few. Note the automatic `Limit` operator inside the Apply for EXISTS subqueries.

## SEMI_JOIN_REWRITE

### What it does

Rewrites a semi-join into an inner join with aggregation (GROUP BY on the join keys). This transformation is:

```
-- Before (semi-join):
SELECT * FROM t WHERE EXISTS (SELECT 1 FROM s WHERE s.a = t.a);

-- After (inner join + dedup):
SELECT * FROM t JOIN (SELECT a FROM s GROUP BY a) s ON t.a = s.a;
```

The aggregation deduplicates the inner side on the join keys, converting the semi-join into a regular inner join. This unlocks additional join strategies and optimizations that may not be available for semi-joins.

### Hint syntax

Place `SEMI_JOIN_REWRITE()` inside the EXISTS subquery:

```sql
SELECT *
FROM orders o
WHERE EXISTS (
  SELECT /*+ SEMI_JOIN_REWRITE() */ 1
  FROM returns r
  WHERE r.order_id = o.id
);
```

### Session variable: `tidb_opt_enable_semi_join_rewrite`

| Property | Value |
|----------|-------|
| Scope | GLOBAL, SESSION |
| Default | OFF |
| Effect | Automatically applies SEMI_JOIN_REWRITE for all eligible semi-joins |

```sql
SET @@session.tidb_opt_enable_semi_join_rewrite = ON;
```

### When to use SEMI_JOIN_REWRITE

- The semi-join execution is slow (e.g., hash semi-join with a large build side).
- The inner side has **few duplicates on the join key** — the GROUP BY dedup cost is low.
- The rewritten inner join can use a better join strategy (e.g., index join) that wasn't available for the semi-join.

### When NOT to use SEMI_JOIN_REWRITE

- The inner side has **many duplicates on the join key** — the GROUP BY aggregation becomes expensive.
- The semi-join is already fast (hash semi-join with a small build side).
- The subquery is correlated (Apply) — SEMI_JOIN_REWRITE only works on **non-correlated** semi-joins (i.e., after decorrelation).

### Limitations

- **Only works for SemiJoin**, not LeftOuterSemiJoin. TiDB will warn: `SEMI_JOIN_REWRITE() is inapplicable for LeftOuterSemiJoin.`
- **Cannot have left conditions or other conditions** — only equal conditions on the join keys are supported.
- **Conflicts with NO_DECORRELATE:** If both hints are specified on the same subquery, TiDB disables both and warns: `NO_DECORRELATE() and SEMI_JOIN_REWRITE() are in conflict. Both will be ineffective.` This makes sense because NO_DECORRELATE keeps the subquery correlated (Apply), while SEMI_JOIN_REWRITE requires a decorrelated semi-join to rewrite.

### Example

```sql
-- The inner side (returns) has unique order_id values, so GROUP BY is cheap.
-- Rewriting to inner join allows the optimizer to use index join on orders.
SELECT *
FROM orders o
WHERE EXISTS (
  SELECT /*+ SEMI_JOIN_REWRITE() */ 1
  FROM returns r
  WHERE r.order_id = o.id
);

-- Equivalent rewritten plan:
-- SELECT * FROM orders o JOIN (SELECT order_id FROM returns GROUP BY order_id) r ON o.id = r.order_id;
```

## Semi-join patterns

When TiDB decorrelates an EXISTS subquery, it typically creates a **semi-join**. The execution strategy for the semi-join matters:

| Strategy | When it works well |
|----------|-------------------|
| Hash semi-join | Inner side fits in memory; no useful index on join key |
| Index semi-join (INL_JOIN) | Inner side has index on join key; outer side is moderate |
| Merge semi-join | Both sides sorted on join key |

You can combine hints:

```sql
-- Force index join for the semi-join after decorrelation
SELECT /*+ INL_JOIN(r) */ *
FROM orders o
WHERE EXISTS (SELECT 1 FROM returns r WHERE r.order_id = o.id);
```

## NOT EXISTS / NOT IN (anti-semi-join)

TiDB converts `NOT EXISTS` and `NOT IN` into anti-semi-joins. The same principles apply:
- Check whether decorrelation helps or hurts.
- `NO_DECORRELATE()` works for `NOT EXISTS` subqueries too.

**Caution with NOT IN:** `NOT IN` has NULL-handling semantics that can prevent optimization. Prefer `NOT EXISTS` when possible, as it avoids NULL edge cases and gives the optimizer more freedom.

## Decision flowchart

```
Is the subquery correlated?
├── NO  → TiDB handles it as an uncorrelated subquery (executed once). TiDB does not currently correlate an uncorrelated subquery. If performance is sub-optimal, a rewrite or other tuning options may be needed.
└── YES → Continue below.

Where is the subquery?
├── SELECT list (scalar subquery)
│   └── Is the outer query selective AND subquery well-indexed?
│       ├── YES → SET tidb_opt_enable_no_decorrelate_in_select = ON
│       │         (or use NO_DECORRELATE() hint on the subquery)
│       └── NO  → Let TiDB decorrelate (default).
│
└── WHERE clause (EXISTS / IN / NOT EXISTS / NOT IN)
    └── Is the outer query selective (few rows after filtering)?
        ├── YES → Does the subquery have a good index on correlation columns?
        │         ├── YES → Try NO_DECORRELATE(). Verify with EXPLAIN ANALYZE.
        │         └── NO  → Let TiDB decorrelate (default). Consider adding an index.
        └── NO  → Let TiDB decorrelate (default).
                  └── Is the semi-join strategy optimal?
                      ├── YES → Done.
                      ├── NO, and inner side has few duplicates on join key
                      │   → Try SEMI_JOIN_REWRITE() to convert to inner join + dedup.
                      └── NO  → Try INL_JOIN / HASH_JOIN hints on the semi-join tables.
```

## Summary: hints vs variables

| Mechanism | Scope | Applies to | Default |
|-----------|-------|------------|---------|
| `/*+ NO_DECORRELATE() */` | Per-subquery (hint) | EXISTS, IN, scalar subqueries in WHERE or SELECT | — |
| `tidb_opt_enable_no_decorrelate_in_select` | Session / Global | Scalar subqueries in the SELECT list only | OFF |
| `/*+ SEMI_JOIN_REWRITE() */` | Per-subquery (hint) | EXISTS subqueries (non-correlated semi-joins only) | — |
| `tidb_opt_enable_semi_join_rewrite` | Session / Global | All eligible semi-joins | OFF |

**Key rule:** `NO_DECORRELATE` and `SEMI_JOIN_REWRITE` are mutually exclusive on the same subquery. NO_DECORRELATE keeps the subquery correlated; SEMI_JOIN_REWRITE requires it to be decorrelated first. Specifying both cancels both.
