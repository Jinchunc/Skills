# PATH-STORE-FAILURE (TiKV Store Down / Offline)

> Entry condition: TiKV store disconnected / down / offline / tombstone / store not responding

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range
3. Affected store instance (if known)

---

## Decision Tree

### Step 1: Identify Store Status

```
metrics:
  store_status: pd_cluster_status{tidb_cluster_id="{cluster_id}", type=~"store_.*"}

All stores up → not a store failure → END
Any store disconnected/down/offline → Step 2
```

### Step 2: Classify Store State

| State | Meaning | Urgency |
|-------|---------|---------|
| `disconnected` | Heartbeat lost < 30min (default) | HIGH — may recover |
| `down` | Heartbeat lost > max-store-down-time (default 30min) | CRITICAL — PD starts migrating regions |
| `offline` | Manually taken offline / scaling down | EXPECTED if intentional |
| `tombstone` | Decommissioned, data fully migrated | No action needed |

### Branch A: Store Disconnected / Down

**A1: Check Process Alive**
```
metrics:
  uptime: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv", instance="{store_instance}"}

Uptime dropped → process restarted → check OOM → [PATH-OOM](oom.md)
Uptime not available → process dead → check host/container status
```

**A2: Check Network**
```
metrics:
  raft_msg_send_fail: sum(rate(tikv_server_raft_message_flush_total{tidb_cluster_id="{cluster_id}", type="drop"}[1m])) by (instance)

Send failures > 0 → network issue between TiKV nodes → [PATH-NET-LATENCY](../../performance-optimization/paths/net-latency.md)
```

**A3: Check Disk**
```
metrics:
  disk_util: rate(node_disk_io_time_seconds_total{tidb_cluster_id="{cluster_id}", instance=~"{store_instance}.*"}[1m])
  disk_used: tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="used", instance="{store_instance}"} / tikv_store_size_bytes{tidb_cluster_id="{cluster_id}", type="capacity", instance="{store_instance}"}

Disk 100% → no space left → [PATH-DISK-SPACE](../../performance-optimization/paths/disk-space.md)
Disk I/O 100% → stuck on I/O → [PATH-IO-HIGH](../../performance-optimization/paths/io-high.md)
```

### Branch B: Store Offline (Intentional)

- Verify: was this triggered by scaling operation or manual action?
- Check region migration progress: `pd_regions_status{type="pending-peer-region-count"}`
- If migration stalled → check target stores have capacity

### Step 3: Impact Assessment

```
metrics:
  region_count: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", instance="{store_instance}"}
  leader_count: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="leader", instance="{store_instance}"}

Regions on failed store → how many regions lost a replica
Leaders on failed store → transferred by PD automatically (check PD scheduling)
```

→ DIAGNOSIS + recommendations: restore store / verify data safety / monitor region migration

---

## Data Source Call Templates

### Store Status
```
query: pd_cluster_status{tidb_cluster_id="{cluster_id}", type=~"store_.*"}
```

### TiKV Process Uptime
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"} by (instance)
```

### Raft Message Drop Rate
```
query: sum(rate(tikv_server_raft_message_flush_total{tidb_cluster_id="{cluster_id}", type="drop"}[1m])) by (instance)
```

### Region Count on Store
```
query: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance, type)
```

### Pending Peer Regions (Migration Progress)
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type="pending-peer-region-count"}
```
