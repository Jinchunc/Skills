# Clinic API Reference

> Data access layer for TiDB Cloud performance diagnostics
> Unified query interface: cluster metadata, slow query logs, PromQL metrics, Loki logs, cluster events, table schema

---

## 1. Authentication

### Two Authentication Methods

| Method | Header | Description |
|------|--------|------|
| Bearer Token (recommended) | `Authorization: Bearer <api-key>` | Use API Key directly |
| Basic Auth | `Authorization: Basic base64(api_key:<api-key>)` | Username is fixed as `api_key` |

### Internal API Key

- Log in to [clinic.pingcap.com](https://clinic.pingcap.com) → User Profile → Create Access Key
- Must be an **internal user** (`internal=true`)
- Internal users can access **all** API endpoints
- Regular users can only access: `/clinic/api/v1/diag/{precreate,upload,flush}`

### Environment Variables

```bash
# .env
CLINIC_API_TOKEN="your-api-key-here"
```

Environment variable name: `CLINIC_API_TOKEN`

### Security Requirements

- Store securely, do not commit to code repositories
- Set expiration time
- Rotate keys regularly

---

## 2. Cluster Metadata

### Search Clusters: clinic_search_cluster_by_id

```
GET /clinic/api/v1/dashboard/clusters
```

| Parameter | Type | Required | Description |
|------|------|------|------|
| `query` | string | No | Fuzzy search: tenant name/ID, cluster name/ID |
| `cluster_id` | string | No | Exact cluster ID lookup (recommended when cluster ID is known) |
| `show_deleted` | boolean | No | Include deleted clusters (default false) |
| `cluster_status` | string | No | Status filter: `active`, `deleted`, etc. |
| `deploy_type_v2` | string | No | Type filter: `premium`, `dedicated`, `starter`, `resource_pool` |
| `sort` | string | No | Sort field |
| `order` | string | No | Sort order: `asc` or `desc` |
| `limit` | int | No | Items per page (default 10) |
| `page` | int | No | Page number (default 1) |

#### Exact Cluster Lookup (Recommended)

When you already know a cluster ID, use `cluster_id` instead of `query`. Direct `cluster_id` lookup is faster than `query` search and avoids fuzzy-match ambiguity and branch-record ordering issues.

```bash
curl -s "https://clinic.pingcap.com/clinic/api/v1/dashboard/clusters" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}" \
  -G \
  --data-urlencode "cluster_id=10314554245653732213" \
  --data-urlencode "show_deleted=true"
```

**Response fields**:

| Field | Description |
|------|------|
| `cluster_name` | Cluster display name |
| `region` | Deployment region |
| `provider` | Cloud provider (aws/gcp/azure) |
| `tier` | Product line: `dedicated` / `premium` / `starter` / `essential` |
| `status` | Cluster status |
| `org_id` | **Internal organization ID (not tenant_id!)** |
| `version` | TiDB version |
| `clusterDeployTypeV2` | Deployment type for the cluster |

**Important**: `query` is a fuzzy search; do not assume `items[0]` is the target cluster. When the cluster_id is known, prefer using the `cluster_id` parameter for exact lookup.

**Note on branch clusters**: Clinic may return branch cluster IDs in `bran-xxxx` format. If using `query`, be sure to filter with `select(.clusterID == $cluster_id)` before extracting fields.

### Get Cluster Details: clinic_get_cluster_by_id

```
GET /clinic/api/v1/orgs/{orgID}/clusters/{clusterID}
```

**Note**: `{orgID}` comes from the search API response and is an internal org ID, **not** the user's tenant_id.

### Get Resource Pool Components

```
GET /clinic/api/v1/orgs/{orgID}/clusters/{clusterID}/resource-pool/components
```

Supports `premium` and `byoc` type clusters. Returns component topology (TiDB, TiKV, PD, etc.).

| Use Case | Path | When |
|----------|------|------|
| **Current cluster** | `/clusters/{clusterID}/resource-pool/components` | Query the cluster you care about (e.g. premium tenant, byoc tenant) |
| **Resource pool** | `/clusters/{parentID}/resource-pool/components` | Query the underlying resource pool (cluster has `parentID` pointing to the pool) |

```bash
# Current cluster's components (e.g. premium cluster ID)
curl -s "https://clinic.pingcap.com/clinic/api/v1/orgs/${ORG_ID}/clusters/${CLUSTER_ID}/resource-pool/components" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}"

# Resource pool's components (use parentID from cluster metadata)
curl -s "https://clinic.pingcap.com/clinic/api/v1/orgs/${ORG_ID}/clusters/${PARENT_ID}/resource-pool/components" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}"
```

### ID Type Descriptions

| ID | User-visible | Description |
|----|----------|------|
| `tenantID` | Yes | User's tenant ID, the ID users reference |
| `orgID` | No | Clinic internal ID, used only in API paths |
| `clusterID` | Yes | Cluster ID, same in both user and API contexts |
| `parentID` | No | For Premium/BYOC tenant clusters, points to Resource Pool cluster |
| `clusterDeployTypeV2` | Yes | Deployment type for the cluster |

**Key point**: When users say "tenant ID", they mean `tenantID`. `orgID` is an internal ID that must be extracted from the search API before it can be used in the details API.

### Cluster Types and Topology

| Type | Deploy Type | Has Topology | How to Obtain |
|------|-------------|--------|----------|
| Dedicated | `dedicated` | Yes | `components` field in Get Cluster response |
| Resource Pool | `byoc resource pool`, `premium resource pool` | Yes | `/clusters/{clusterID}/resource-pool/components` API |
| Premium / BYOC | `premium`, `byoc` (with parentID) | Yes | `/clusters/{clusterID}/resource-pool/components` (current cluster) or `/clusters/{parentID}/resource-pool/components` (resource pool) |
| Starter/Serverless | `starter` | No | No topology (shared infrastructure) |

---

## 3. Data Proxy SQL Queries

### Endpoint

```
POST /data-proxy/query
```

### Request

```json
{
  "sql": "SELECT count(*) as cnt, date FROM clinic_data_proxy.slow_query_logs WHERE date = '20260301' GROUP BY date",
  "clusterId": "10054188880241765866",
  "timeout": 60
}
```

| Parameter | Type | Required | Description |
|------|------|------|------|
| `sql` | string | Yes | SQL query. Use **MySQL standard**; identifiers are auto-converted. MUST include date partition filter. Use vendor dialect only for dialect-specific functions |
| `clusterId` | string | Yes | Cluster ID |
| `timeout` | int | No | Query timeout (seconds) |

### SQL Dialect and Query Strategy

**Slow Query support by cloud vendor**:

| Vendor | Supported | Engine | Notes |
|--------|-----------|-------|------|
| AWS | Yes | Athena | Presto/Trino SQL |
| GCP | Yes | BigQuery | BigQuery SQL |
| Alibaba Cloud | Yes | AnalyticDB MySQL | MySQL standard |
| Azure | No | - | Not yet supported |

**Query strategy (recommended)**:
1. **Default**: Use **MySQL standard SQL**. Data Proxy **auto-converts identifiers** (table/column names) to the backend engine's dialect.
2. **Fallback**: Only when using **dialect-specific functions** that MySQL standard does not support, write those function expressions in the vendor dialect within the SQL.

| Vendor | Engine | When to use vendor dialect |
|--------|--------|----------------------------|
| AWS | Athena | Dialect-specific functions only |
| GCP | BigQuery | Dialect-specific functions only |
| Alibaba Cloud | AnalyticDB | MySQL native, no fallback needed |

**Identifier conversion (already supported)**:
- Table/column names: `clinic_data_proxy.slow_query_logs`, `date`, `digest` -- auto-converted
- Partition filter: `WHERE date = '20260319'` -- auto-converted
- No need to use `"db"."table"` for Athena or vendor-specific identifier syntax

**Dialect-specific functions** (only these require vendor SQL):
- When MySQL standard lacks a function or the engine interprets it differently, use the vendor's function syntax in the query

### Date Partition Filter Required

**Mandatory**: Every query WHERE clause must include a `date` partition filter:

```sql
WHERE date = '20260301'
-- or
WHERE date IN ('20260301', '20260302')
```

Missing partition filter will return an error:
```json
{"error":"query failed: SQL validation failed: missing partition filter in WHERE clause for columns: [date]. Please add WHERE conditions like: WHERE \"date\" = '...' or WHERE \"date\" IN (...)"}
```

### curl Example

```bash
# MySQL standard SQL - auto-converted to backend dialect
curl -s -X POST https://clinic.pingcap.com/data-proxy/query \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d '{
  "sql": "SELECT count(*) as cnt, date FROM clinic_data_proxy.slow_query_logs WHERE date IN ('\''20260201'\'','\''20260202'\'') GROUP BY date",
  "clusterId": "10054188880241765866",
  "timeout": 60
}'
```

### Response Format

```json
{
  "columns": ["_col0", "date"],
  "rows": [["109215","20260201"],["92298","20260202"]],
  "metadata": {
    "rowCount": 0,
    "bytesScanned": 0,
    "executionTime": "3.4s",
    "queryId": "56035f2a-b953-4f4a-ba8f-a8354d8fbbad",
    "engine": "athena",
    "vendor": "aws",
    "region": "us-east-1"
  }
}
```

### Table Schema Query

```
GET /data-proxy/schema
```

| Parameter | Type | Required | Description |
|------|------|------|------|
| `tables` | string | Yes | Table names, comma-separated (e.g., `slow_query_logs`) |
| `clusterId` | string | Yes | Cluster ID |

Response fields: `database`, `table`, `columns[]` (name/type/comment), `partitions[]` (name/type), `data_source`, `location`

### slow_query_logs Complete Fields

| Field | Type | Description |
|------|------|------|
| `id` | bigint | Unique ID |
| `time` | double | Execution timestamp (Unix) |
| `digest` | string | SQL normalization hash |
| `digest_text` | string | Normalized SQL text |
| `instance` | string | TiDB instance address |
| `query_time` | double | Total execution time |
| `parse_time` | double | Parse time |
| `compile_time` | double | Compile time |
| `rewrite_time` | double | Rewrite time |
| `cop_time` | double | Coprocessor total time |
| `cop_proc_avg` | double | Coprocessor average processing time |
| `cop_wait_avg` | double | Coprocessor average wait time |
| `process_time` | double | KV processing time |
| `wait_time` | double | KV wait time |
| `mem_max` | bigint | Maximum memory usage |
| `disk_max` | bigint | Maximum disk usage |
| `total_keys` | string | Total keys scanned |
| `process_keys` | string | Keys processed |
| `write_keys` | string | Keys written |
| `write_size` | string | Data written |
| `prewrite_time` | double | Prewrite time |
| `commit_time` | double | Commit time |
| `backoff_types` | string | Retry types |
| `result_rows` | bigint | Rows returned |
| `db` | string | Database name |
| `index_names` | string | Indexes used |
| `query` | string | Original SQL |
| `plan` | string | Execution plan |
| `decoded_plan` | string | Decoded execution plan (JSON) |
| `date` | string | Partition field (log date, YYYYMMDD) |

### Analysis Scenarios

#### Scenario 1: Top Slow SQL

```sql
SELECT
  digest,
  any_value(query) AS sample_sql,
  COUNT(*) AS exec_count,
  MAX(query_time) AS max_time,
  AVG(query_time) AS avg_time
FROM clinic_data_proxy.slow_query_logs
WHERE date = '20260301'
GROUP BY digest
ORDER BY max_time DESC
LIMIT 20
```

#### Scenario 2: Digest Analysis (detailed statistics for a specific SQL)

```sql
SELECT
  COUNT(*) AS total_queries,
  COUNT(DISTINCT digest) AS unique_sql,
  AVG(query_time) AS avg_query_time,
  MAX(query_time) AS max_query_time
FROM clinic_data_proxy.slow_query_logs
WHERE date = '20260301'
```

#### Scenario 3: Time Range Analysis

```sql
SELECT
  digest,
  any_value(query) AS sample_sql,
  COUNT(*) AS exec_count
FROM clinic_data_proxy.slow_query_logs
WHERE date IN ('20260301', '20260302')
GROUP BY digest
ORDER BY exec_count DESC
LIMIT 20
```

#### Scenario 4: High Resource Consumption Queries

```sql
SELECT
  digest,
  any_value(query) AS sample_sql,
  MAX(mem_max) AS max_mem,
  MAX(disk_max) AS max_disk,
  MAX(total_keys) AS max_keys,
  COUNT(*) AS exec_count
FROM clinic_data_proxy.slow_query_logs
WHERE date = '20260301'
  AND mem_max > 5368709120  -- 5GB
GROUP BY digest
ORDER BY max_mem DESC
LIMIT 20
```

Analysis key points:

| Metric | Issue |
|------|------|
| High total_keys, low process_keys | Full table scan |
| No index_names | Missing indexes |
| mem_max > 5GB | OOM risk |
| total_keys > 10M | Possible full table scan |

#### Scenario 5: Backoff Analysis

```sql
SELECT
  digest,
  any_value(query) AS sample_sql,
  any_value(backoff_types) AS backoff,
  COUNT(*) AS exec_count,
  AVG(query_time) AS avg_time
FROM clinic_data_proxy.slow_query_logs
WHERE date = '20260301'
  AND backoff_types IS NOT NULL
  AND backoff_types != ''
GROUP BY digest
ORDER BY exec_count DESC
LIMIT 20
```

#### Scenario 6: Large Scan SQL

```sql
SELECT
  digest,
  any_value(query) AS sample_sql,
  SUM(total_keys) AS scanned_rows
FROM clinic_data_proxy.slow_query_logs
WHERE date = '20260301'
GROUP BY digest
ORDER BY scanned_rows DESC
LIMIT 20
```

#### Scenario 7: High Frequency SQL

```sql
SELECT
  digest,
  any_value(query) AS sample_sql,
  COUNT(*) AS exec_count
FROM clinic_data_proxy.slow_query_logs
WHERE date = '20260301'
GROUP BY digest
ORDER BY exec_count DESC
LIMIT 20
```

---

## 4. PromQL Metrics Queries

### Endpoints

| Endpoint | Method | Description |
|------|------|------|
| `/data-proxy/metrics/{cluster_id}/api/v1/query_range` | GET/POST | Range query |
| `/data-proxy/metrics/{cluster_id}/api/v1/query` | GET/POST | Instant query |
| `/data-proxy/metrics/{cluster_id}/api/v1/series` | GET/POST | Series discovery |

### Two Data Sources

| Data Source | Metric Prefix | Description |
|--------|----------|------|
| **ClusterMetrics** (default) | `tidb_*`, `tikv_*`, `pd_*`, `process_*`, `tiflash_*` | Database runtime metrics |
| **DataPlane** | `node_*`, `container_*`, `kube_*` | K8s infrastructure metrics |

**Default**: All metrics use the ClusterMetrics endpoint unless they are in the DataPlane list.

**IMPORTANT**: `tidb_cluster_id` is auto-injected for non-starter/essential clusters. If you suspect the metric is from shared Resource Pool components (Premium/BYOC), and the query returns no data, try adding `{tidb_cluster_id="{parentID}"}` manually.

### Series Discovery

Use `/api/v1/series` to discover which labels exist for a metric on the target cluster. Recommended when a query returns no data.

```bash
CLUSTER_ID="..."
END=$(date +%s)
START=$((END - 600))

curl -s -G "https://clinic.pingcap.com/data-proxy/metrics/${CLUSTER_ID}/api/v1/series" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}" \
  --data-urlencode 'match[]=tidb_server_query_total{cluster_id="'"${CLUSTER_ID}"'"}' \
  --data-urlencode "start=${START}" \
  --data-urlencode "end=${END}" | jq '.data[0]'
```

If `series` shows the metric exists but your range query is empty, check time range and aggregation. If `series` itself returns empty, the metric is not available for that cluster.

### Range Query Parameters

| Parameter | Required | Description |
|------|------|------|
| `query` | Yes | PromQL expression |
| `start` | Yes | Start time (RFC3339 or Unix timestamp) |
| `end` | Yes | End time (RFC3339 or Unix timestamp) |
| `step` | Yes | Query step (e.g., `15s`, `1m`, `5m`) |
| `timeout` | No | Query timeout |

**Note**: `step=15s` provides the highest precision. Each series returns at most **11,000 data points**; increase step or shorten time range if exceeded.

### Instant Query Parameters

| Parameter | Required | Description |
|------|------|------|
| `query` | Yes | PromQL expression |
| `time` | No | Query time point (RFC3339 or Unix), defaults to now |
| `timeout` | No | Query timeout |

### curl Examples

```bash
# Range query
curl -X GET "https://clinic.pingcap.com/data-proxy/metrics/${CLUSTER_ID}/api/v1/query_range" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}" \
  -G \
  --data-urlencode "query=sum(rate(tidb_server_query_total[1m]))" \
  --data-urlencode "start=2026-03-06T21:00:00Z" \
  --data-urlencode "end=2026-03-06T22:00:00Z" \
  --data-urlencode "step=15s"

# Instant query
curl -X GET "https://clinic.pingcap.com/data-proxy/metrics/${CLUSTER_ID}/api/v1/query?query=sum(tidb_server_query_total)" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}"

# Instant query at a specific time point
curl -X GET "https://clinic.pingcap.com/data-proxy/metrics/${CLUSTER_ID}/api/v1/query?query=sum(tidb_server_query_total)&time=2026-03-06T22:00:00Z" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}"
```

### Response Format

```json
{
  "status": "success",
  "data": {
    "resultType": "matrix",
    "result": [
      {
        "metric": {"__name__": "tidb_server_query_total", "instance": "tidb-0:10080"},
        "values": [[1709766000, "12345.67"], [1709766015, "12350.23"]]
      }
    ]
  }
}
```

Label filtering: All queries use `tidb_cluster_id="{cluster_id}"` to scope to the cluster.

### Common PromQL Quick Reference

> For the full PromQL reference with normal ranges, anomaly interpretation, and symptom-to-template mapping, see [promql-templates.md](../../../engines/tidb/references/promql-templates.md). The queries below use `rate[2m]` as a safe default; adjust per SKILL.md Metrics Query Methodology (1m for ≤1d, 5m15s for >7d).

#### Latency

```promql
# Query Duration P99/P999
histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
histogram_quantile(0.999, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

# P95 Query Duration
histogram_quantile(0.95, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))

# Average Query Duration
sum(rate(tidb_server_handle_query_duration_seconds_sum{tidb_cluster_id="{cluster_id}"}[1m])) / sum(rate(tidb_server_handle_query_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[1m]))

# KV Request by type
histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))

# TiKV gRPC Duration
histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))

# TSO Wait
histogram_quantile(0.99, sum(rate(tidb_tikvclient_ts_future_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

# TiKV Scheduler Command Duration
histogram_quantile(0.99, sum(rate(tikv_scheduler_command_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))

# TiKV Coprocessor Duration
histogram_quantile(0.99, sum(rate(tikv_coprocessor_request_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))

# TiKV Raftstore Apply Log Duration
histogram_quantile(0.99, sum(rate(tikv_raftstore_apply_log_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))
```

#### Throughput

```promql
# TiDB Total QPS
sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m]))

# QPS by type (Select, Insert, Update, Delete)
sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[1m])) by (type)

# TiDB QPS by instance
sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

# TiKV gRPC QPS
sum(rate(tikv_grpc_msg_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)

# Statement Execution Count
sum(rate(tidb_executor_statement_total{tidb_cluster_id="{cluster_id}"}[1m])) by (type)

# Connections
tidb_server_connections{tidb_cluster_id="{cluster_id}"}
sum(tidb_server_connections{tidb_cluster_id="{cluster_id}"}) by (instance)
```

#### Resources

```promql
# TiDB CPU
rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m])
sum(rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m]))

# TiKV CPU
rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tikv"}[1m])

# TiDB Memory
process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"}

# TiKV Memory
process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"}

# TiKV Thread CPU (by thread pool)
sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])) by (name)

# Block Cache
tikv_engine_block_cache_size_bytes{tidb_cluster_id="{cluster_id}"}
```

#### Storage

```promql
# Store Size
sum(tikv_store_size_bytes{tidb_cluster_id="{cluster_id}"}) by (instance)
tikv_engine_size_bytes{tidb_cluster_id="{cluster_id}"} by (instance, db)

# Region Count
tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
sum(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"}) by (instance)

# Leader Count
sum(tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"}) by (instance)

# Compaction
sum(rate(tikv_engine_compaction_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

# GC
tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}"}
```

#### Errors

```promql
# gRPC Errors
sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

# TiDB Execute Errors
sum(rate(tidb_server_execute_error_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

# Backoff
sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

# Write Stall
tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}
```

#### PD Metrics

```promql
# Cluster Status
pd_cluster_status{tidb_cluster_id="{cluster_id}"}

# Region Status
pd_regions_status{tidb_cluster_id="{cluster_id}"}

# Scheduler Region Heartbeat
pd_scheduler_region_heartbeat{tidb_cluster_id="{cluster_id}"}

# Store Status
pd_scheduler_store_status{tidb_cluster_id="{cluster_id}"}
```

#### TiFlash Metrics

```promql
# Query Queue Size
tiflash_system_current_metric_QueryQueueSize{tidb_cluster_id="{cluster_id}"}

# Coprocessor Duration
histogram_quantile(0.99, sum(rate(tiflash_coprocessor_request_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))

# CPU
rate(tiflash_proxy_process_cpu_seconds_total{tidb_cluster_id="{cluster_id}"}[1m])

# Logical CPU Cores
tiflash_system_current_metric_LogicalCPUCores{tidb_cluster_id="{cluster_id}"}
```

---

## 5. Loki Log Queries

### Endpoints

| Endpoint | Method | Description |
|------|------|------|
| `/data-proxy/loki/{cluster_id}/api/v1/query_range` | GET | Range log query |
| `/data-proxy/loki/{cluster_id}/api/v1/query` | GET | Instant log query |
| `/data-proxy/loki/{cluster_id}/api/v1/labels` | GET | List all available labels |
| `/data-proxy/loki/{cluster_id}/api/v1/label/{name}/values` | GET | Get label value list |

### Timestamp Format: Nanoseconds

**Loki uses nanosecond timestamps** (Unix epoch * 10^9):

```bash
# Current time -> nanoseconds
date +%s%N

# macOS: seconds -> nanoseconds (macOS date does not support %N)
START_SEC=$(date -j -f '%Y-%m-%d %H:%M:%S' '2026-01-08 10:00:00' +%s)
START_NS="${START_SEC}000000000"

# Linux: direct nanoseconds
date -d '2026-01-08 10:00:00' +%s%N

# Convert seconds to nanoseconds
START_SEC=1773125534
START_NS="${START_SEC}000000000"
```

### Labels

**Important**: Use the `component` label, **not** `job`!

| Label | Description | Selectivity | Example Values |
|------|------|--------|--------|
| `component` | Component type | High | `tidb`, `tikv`, `pd`, `tiflash` |
| `container` | Container name | High | `tidb`, `tikv`, `pd`, `slowlog` |
| `instance` | Instance identifier | High | `tidb-0`, `tikv-1`, `pd-2` |
| `pod` | Pod name | High | `basic-tidb-0`, `basic-tikv-1` |
| `stream` | Log stream type | Low | `stdout`, `stderr` |

The `namespace` label is automatically set by the `cluster_id` in the API path; no need to specify it in queries.

### Label Discovery

```bash
# List all labels
curl -G "https://clinic.pingcap.com/data-proxy/loki/${CLUSTER_ID}/api/v1/labels" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}" \
  --data-urlencode "start=${START_NS}" \
  --data-urlencode "end=${END_NS}"

# Get component label values
curl -G "https://clinic.pingcap.com/data-proxy/loki/${CLUSTER_ID}/api/v1/label/component/values" \
  -H "Authorization: Bearer ${CLINIC_API_TOKEN}" \
  --data-urlencode "start=${START_NS}" \
  --data-urlencode "end=${END_NS}"
```

### Range Query Parameters

| Parameter | Required | Description |
|------|------|------|
| `query` | Yes | LogQL query expression |
| `start` | Yes | Start time (nanoseconds) |
| `end` | Yes | End time (nanoseconds) |
| `limit` | No | Maximum number of rows returned (default 100) |
| `direction` | No | Sort direction: `forward` or `backward` (default `backward`) |
| `step` | No | Aggregation query step (e.g., `1m`, `5m`) |

### LogQL Syntax

```logql
# Stream selectors
{component="tidb"}                           # All TiDB logs
{component="tikv"}                           # All TiKV logs
{component="pd"}                             # All PD logs
{component="tidb",instance="tidb-0"}         # Specific TiDB instance
{component="tidb",container="slowlog"}       # Slow log container

# Log filtering
{component="tidb"} |= "error"               # Contains "error"
{component="tidb"} != "info"                # Does not contain "info"
{component="tidb"} |~ "error|fatal"         # Regex match
{component="tidb"} !~ "debug"               # Regex not match
{component="tidb"} |~ "(?i)error|fatal"     # Case-insensitive regex

# JSON parsing
{component="tidb"} | json                   # Parse JSON logs
{component="tidb"} | json | level="error"   # Filter by JSON field
{component="tidb"} | json | duration > 1000 # Filter by numeric field
```

### Cluster Type Support

| Cluster Type | Loki Support |
|----------|-----------|
| Dedicated | **YES** |
| Premium | **YES** |
| Starter | **NO** |
| Essential | **NO** |

Starter and Essential use shared infrastructure and do not expose raw logs via Loki.

### Response Format

```json
{
  "status": "success",
  "data": {
    "resultType": "streams",
    "result": [
      {
        "stream": {
          "component": "tidb",
          "container": "tidb",
          "instance": "tidb-0"
        },
        "values": [
          ["1773125534000000000", "2026-01-08T10:05:34.000Z [INFO] server started"],
          ["1773125535000000000", "2026-01-08T10:05:35.000Z [ERROR] connection timeout"]
        ]
      }
    ]
  }
}
```

Each `values` entry is a tuple: `[timestamp_ns, log_line]`

### Alert-Driven Log Analysis

- When investigating from an alert, the query window MUST be anchored on the alert's trigger time (e.g. trigger ±15–30m), not on "now" — logs outside that window are noise.
- Data-service components (Import / DM / CDC / BR) are filtered by the `app` label, not `component` (e.g. `{app="dm"}`, `{app="cdc"}`); discover exact values via `/label/app/values` first.
- Start from the alerting rule's own expression/labels to derive the LogQL selector, then widen only if the window returns nothing.
- Keep `limit` small during triage (≤1000) and page with `direction=backward` from the trigger time.

---

## 6. Product Line Matrix

| Capability | Dedicated | Premium | Starter | Essential |
|------|-----------|---------|---------|-----------|
| Cluster Metadata | YES | YES | YES | YES |
| Data Proxy SQL | YES | YES | Partial | Partial |
| PromQL Metrics | Full | Full | Limited | Limited |
| Loki Logs | YES | YES | NO | NO |
| Table Schema | YES | YES | YES | YES |

### Essential/Starter Limitations

- **Metrics**: May return HTTP 500 errors; some metrics unavailable
- **Slow Query**: S3 data source URL may not be configured, causing Data Proxy SQL queries to fail
- **Logs**: Shared infrastructure; Loki log queries not supported

---

## 7. Known Limitations

1. **container_* metrics** -- K8s infrastructure metrics (CPU throttle, memory limit) are accessed via the DataPlane endpoint with limited coverage. Related checks are set to fail-open
2. **node_* metrics** -- OS-level metrics (TCP retransmissions, disk IOPS) may not be available. TiKV internal metrics are used as fallback
3. **Real-time availability** -- Clinic metrics may have a 1-2 minute delay
4. **Data retention** -- Slow query and metrics data have retention periods; expired data is not queryable
5. **DataPlane metrics** -- Some K8s-specific metrics require the DataPlane endpoint; `container_*` metric coverage needs verification
6. **Essential/Starter metrics** -- May return HTTP 500; metric collection may not be configured
7. **Slow query S3 URL** -- Some clusters (especially Essential/Starter) have no S3 data source URL configured; Data Proxy SQL is unavailable
8. **Loki query result limit** -- Single queries have an upper limit on the number of log entries returned (controlled via the `limit` parameter)
9. **Date partition mandatory requirement** -- Every Data Proxy SQL query WHERE clause must include a `date` partition filter; otherwise execution is rejected
10. **Metrics data point limit** -- query_range returns at most **11,000 data points** per series; increase step when the time range is too large

---

## 8. Troubleshooting

| Problem | Cause | Solution |
|------|------|----------|
| 401 Unauthorized | API Key is invalid or expired | Re-create API Key at clinic.pingcap.com User Profile |
| 403 Forbidden | Not an internal user | Contact admin to enable `internal=true` |
| Missing partition filter | SQL missing WHERE date clause | Add `WHERE date = '...'` or `WHERE date IN (...)` |
| Syntax error / invalidQuery | MySQL standard failed for backend engine | Retry with vendor dialect: Athena (double-quoted identifiers) for AWS, BigQuery syntax for GCP. AliCloud uses MySQL natively |
| Query timeout | Query is complex or data volume is large | Increase timeout, add filter conditions, use aggregation |
| `export: invalid option -f` (zsh) | Legacy helper script uses Bash-only function export | Update `clinic-token.sh` to the latest version |

---

## 9. Best Practices

### SQL Queries

1. **Must include partition filter**: Every Data Proxy SQL must have `WHERE date = '...'` or `WHERE date IN (...)`
2. **Use MySQL standard SQL**: Identifiers are auto-converted to the backend engine's dialect. Use vendor dialect only for dialect-specific functions
3. **Select only needed fields**: `SELECT digest, query_time` instead of `SELECT *`
4. **Control result set size**: Always use `LIMIT`; recommended `LIMIT 100`
5. **Use aggregation**: Prefer `GROUP BY digest` aggregation to avoid returning large volumes of raw records
6. **Set reasonable timeout**: Simple queries `timeout: 60`, complex queries `timeout: 120`

### Metrics Queries

1. **Step selection**: `step=15s` for highest precision; be aware of the 11,000 point limit
2. **Time range**: Increase step when querying long time ranges (e.g., 15s for 1 hour, 1m for 1 day, 5m for 1 week)
3. **Label filtering**: Use `tidb_cluster_id="{cluster_id}"` to scope the range
4. **Series discovery**: When a query returns no data, use `/api/v1/series` to verify whether the metric exists on the cluster

### Loki Log Queries

1. **Discover labels first**: Before querying, use `/labels` and `/label/{name}/values` to confirm available labels
2. **Use high-selectivity labels**: Prefer `component`, `container`, `instance`
3. **Combine labels**: `{component="tidb",instance="tidb-0"}` to narrow scope
4. **Limit time range**: Query 1-2 hour ranges for faster responses
5. **Set limit**: Always set a reasonable limit to avoid large responses
6. **Filter early**: Place `|=`, `|~` filters at the front of the query pipeline
7. **Parse on demand**: Only use `| json` when you need to filter by fields

### Environment Variables

| Variable | Description |
|------|------|
| `CLINIC_API_TOKEN` | Internal API Key (required) |
| `ENV_FILE` | .env file path (default `.env`) |

---

## 10. Cluster Events (Activity Hub)

Query cluster lifecycle events (backup, scaling, maintenance, changefeed, etc.).

### Endpoint

```
GET /clinic/api/v1/activityhub/applications/{application_id}/targets/{target_id}/activities
```

- **`application_id`** = Clinic internal **`orgID`** (NOT `tenantID`). Get it from cluster metadata:
  ```bash
  RESULT=$(clinic_search_cluster_by_id "${CLUSTER_ID}" "true")
  ORG_ID=$(echo "$RESULT" | jq -r ".items[] | select(.clusterID == \"${CLUSTER_ID}\") | .orgID")
  ```
- **`target_id`** = cluster ID

### Parameters

| Parameter | Location | Required | Description |
|-----------|----------|----------|-------------|
| `begin_ts` | query | Yes | Start time (Unix seconds) |
| `end_ts` | query | Yes | End time (Unix seconds) |
| `name` | query | No | Filter by event name (e.g., `backupcluster`) |
| `severity` | query | No | Minimum severity (default 0; -4 for debug) |
| `limit` | query | No | Result limit (min 20) |
| `cursor` | **header** | No | Pagination cursor from previous response |

Requires internal user auth. Response has `partial` (bool) and `cursor` (string) for pagination.

### Common Event Types

#### Dedicated Clusters

| DisplayName | Description |
|---|---|
| CreateCluster | Create cluster |
| ModifyClusterSize | Scale cluster |
| MaintenanceTask | Maintenance |
| PauseCluster / ResumeCluster | Pause/resume |
| BackupCluster | Backup (auto or manual) |
| ImportData | Data import |
| RestoreFromBackup | Restore |
| Create/Pause/Resume/Delete/Edit/Scale/FailedChangefeed | Changefeed (CDC) operations |
| InsufficientVMResource | VM resource shortage |

#### Serverless Clusters

| DisplayName | Description |
|---|---|
| CreateCluster | Create cluster |
| UpdateSpendingLimit | Spending limit change |
| ResourceLimitation | Resource limit hit |
| ImportData | Data import |
| CreateBranch / DeleteBranch | Branch operations |
| Enable/Disable/UpdatePublicEndpoint | Public endpoint operations |
| RestoreFromBackup | Restore |
| Create/Cancel/DeleteExport | Export operations |
| UpdateClusterCapacity | Capacity change |
| UpdateAuditLogConfig | Audit log config |

#### GitOps Events (catalog: `gitops`, source: `clinic`)

Lifecycle pairs: `upgrade`, `config-change`, `patch`, `scale`, `pause`, `resume`, `restore`, `import`, `backup` -- each with `:start` / `:finish` suffix.
