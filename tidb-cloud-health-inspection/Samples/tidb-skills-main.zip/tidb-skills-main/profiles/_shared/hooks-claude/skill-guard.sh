#!/usr/bin/env bash
# Skill-guard hook — detects skill content leakage in agent output.
# Claude Code PostToolUse hook: reads JSON from stdin.
# Exit 0 = pass, exit 2 + stderr = block.
#
# Three detection layers:
#   1. SKILL.md frontmatter (YAML with skill metadata fields)
#   2. <CONFIDENTIAL> markers and known warning text
#   3. Structural fingerprints (3+ skill-specific section headers)
set -euo pipefail

INPUT=$(cat)

# Extract content to scan
CONTENT=$(python3 -c "
import sys, json
d = json.load(sys.stdin)
out = d.get('tool_output', d.get('result', ''))
if isinstance(out, dict):
    out = json.dumps(out)
print(out[:20000] if out else '')
" <<< "$INPUT" 2>/dev/null || echo "")

if [ -z "$CONTENT" ]; then
  exit 0
fi

# Run detection
TRIGGERS=$(python3 -c "
import re, sys

text = sys.stdin.read()
triggers = []

# Layer 1: SKILL.md frontmatter
fm = re.search(r'---\s*\n(?=[\s\S]*?^name:\s*.+$)(?=[\s\S]*?^(?:description|category|discipline|version|scope|clearance|auto-trigger|user-invocable):\s*.+$)[\s\S]*?---', text, re.MULTILINE)
if fm:
    triggers.append('frontmatter')

# Layer 2: CONFIDENTIAL markers
conf_patterns = [
    r'</?CONFIDENTIAL>',
    r'STOP\s*[-—]\s*This file is proprietary',
    r'SKILL-PROTECTION',
]
for pat in conf_patterns:
    if re.search(pat, text, re.IGNORECASE):
        triggers.append('confidential_marker')
        break

# Layer 3: structural fingerprints
headers = [
    r'^#{1,3}\s+When to (?:Trigger|Use)',
    r'^#{1,3}\s+Anti-Patterns?',
    r'^#{1,3}\s+Terminal State',
    r'^#{1,3}\s+Boundary',
    r'^#{1,3}\s+Security Red Lines?',
    r'^#{1,3}\s+Fail-Open Rules?',
    r'^#{1,3}\s+Performance Constraints?',
    r'^#{1,3}\s+Routing',
    r'^#{1,3}\s+Pre-Flight Check',
    r'^#{1,3}\s+Implementation',
    r'^#{1,3}\s+Audit Requirements?',
]
count = sum(1 for h in headers if re.search(h, text, re.MULTILINE))
if count >= 3:
    triggers.append(f'skill_headers({count})')

if triggers:
    print(','.join(triggers))
" <<< "$CONTENT" 2>/dev/null || echo "")

if [ -n "$TRIGGERS" ]; then
  echo "[skill-guard] BLOCKED — skill content detected: ${TRIGGERS}" >&2
  # Log to audit
  AUDIT_DIR="${AUDIT_DIR:-${HOME}/.claude/audit}"
  if [ -d "$AUDIT_DIR" ] || mkdir -p "$AUDIT_DIR" 2>/dev/null; then
    TODAY=$(date -u +%Y-%m-%d)
    TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    TS="$TS" TRIGGERS="$TRIGGERS" python3 -c "
import json, os
print(json.dumps({'ts': os.environ['TS'], 'event': 'skill_content_blocked', 'triggers': os.environ['TRIGGERS']}, ensure_ascii=False))
" >> "${AUDIT_DIR}/audit-${TODAY}.jsonl" 2>/dev/null || true
  fi
  exit 2
fi

exit 0
