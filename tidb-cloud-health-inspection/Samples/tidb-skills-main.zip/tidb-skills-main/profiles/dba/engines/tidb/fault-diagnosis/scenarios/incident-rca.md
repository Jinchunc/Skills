# Incident RCA Generation (Post-Fault Documentation)

> After fault diagnosis (S2) is complete, generate a structured Root Cause Analysis document.
> Applies to any fault scenario (F1-F10) that has been resolved or mitigated.

---

## When to Use

- After completing S2 fault diagnosis and recovery
- User asks for "RCA", "incident report", "post-mortem", or "write up what happened"
- Scheduled post-incident review needs a structured document

---

## RCA Generation Workflow

### Step 1: Evidence Collection

Gather all evidence from the diagnosis session:

```
Sources (priority order):
  1. Clinic API metrics and queries executed during diagnosis
  2. Loki log search results (error/panic/fatal patterns)
  3. Slow query analysis results
  4. User-reported symptoms and timeline
  5. Configuration state at time of incident

For each evidence item, record:
  - Timestamp (exact or approximate)
  - Source (metric name, log line, user report)
  - Confidence: CONFIRMED (metric/log proof) | INFERRED (circumstantial) | REPORTED (user statement)
```

### Step 2: Timeline Reconstruction

Build chronological event sequence from collected evidence:

```
Timeline Rules:
  1. Start from earliest anomaly signal, not first user report
  2. Use exact timestamps when available (metric timestamps, log timestamps)
  3. When only Jira/chat comment timestamps are available, use those with annotation
  4. When precise time is unknown but ordering is clear, preserve sequence and mark "approximate"
  5. Group events under phase headings:

  Phases:
    TRIGGER    — What initiated the incident (config change, traffic spike, hardware failure)
    DETECTION  — When and how the issue was first noticed (alert, user report, monitoring)
    DIAGNOSIS  — Investigation steps taken, hypotheses explored
    MITIGATION — Immediate actions to restore service (restart, failover, config rollback)
    RECOVERY   — Full service restoration and verification
    FOLLOW-UP  — Post-incident actions, preventive measures

  Format each event:
    [HH:MM UTC] {phase} — {description} [CONFIRMED|INFERRED|REPORTED]
```

### Step 3: Root Cause Analysis

```
Analysis Rules:
  1. Distinguish symptom chain from root cause
     - Symptom: "P99 latency increased to 5s"
     - Proximate cause: "TiKV node OOM killed"
     - Root cause: "Block cache configured at 60% of memory, coprocessor task accumulation consumed remaining headroom"

  2. Follow the evidence chain, not assumptions
     - If root cause is established from metrics/logs → state directly
     - If root cause is inferred from circumstantial evidence → mark as inference
     - If root cause is unknown → state "TBD" with what is known and what additional investigation is needed

  3. MUST NOT:
     - Invent metrics, timestamps, or ticket numbers
     - Present inference as confirmed fact
     - Skip unknown gaps (state them explicitly)
     - Use hedging language without explaining what is uncertain
```

### Step 4: Document Generation

Use the RCA template below. Fill only what evidence supports. Use "TBD" for unsupported fields.

---

## RCA Document Template

```markdown
# RCA: {incident_title}

| Field | Value |
|-------|-------|
| Cluster | {cluster_name} ({cluster_id}) |
| Product Line | {product_line} |
| Version | {version} |
| Severity | {P0/P1/P2} |
| Duration | {start_time} — {end_time} ({duration}) |
| Impact | {user_impact_description} |
| Author | AI-generated (requires human review) |
| Status | DRAFT |

## Summary

{2-3 sentence incident summary: what happened, scope of impact, resolution}

## Timeline

| Time (UTC) | Phase | Event | Evidence |
|------------|-------|-------|----------|
| {HH:MM} | TRIGGER | {description} | {CONFIRMED/INFERRED/REPORTED} |
| {HH:MM} | DETECTION | {description} | {evidence_source} |
| ... | ... | ... | ... |

## Root Cause Analysis

### Symptom Chain
{Describe the observable symptoms in order of appearance}

### Proximate Cause
{Direct technical cause — what component failed and how}

### Root Cause
{Underlying reason — why the component failed}
{Mark confidence: CONFIRMED (metric/log evidence) or INFERRED (circumstantial)}

### Contributing Factors
- {Factor 1: e.g., insufficient memory headroom for workload spikes}
- {Factor 2: e.g., autoscaling not configured}

## Solution

### Immediate Mitigation
{What was done to restore service — with timestamps}

### Short-Term Fix
{Configuration changes, patches, or workarounds applied}

### Long-Term Prevention
| Action | Owner | Deadline | Status |
|--------|-------|----------|--------|
| {preventive action} | Suggest user action | {date} | TODO |
| {monitoring improvement} | Suggest user action | {date} | TODO |

## Metrics Evidence

<details>
<summary>Key Metrics Snapshots</summary>

| Metric | Pre-Incident | During Incident | Post-Recovery |
|--------|-------------|-----------------|---------------|
| {metric_name} | {baseline_value} | {anomaly_value} | {recovered_value} |

PromQL queries used:
- {query_1}
- {query_2}

</details>

## Open Questions

- {Any unresolved aspects of the investigation}
- {Additional data needed for confirmation}

## Lessons Learned

1. {Key takeaway for preventing similar incidents}
2. {Process improvement identified}
```

---

## Quality Gates

Before presenting the RCA:

| Gate | Check |
|------|-------|
| Timeline completeness | All major phases (trigger through recovery) have at least one event |
| Evidence tagging | Every claim tagged as CONFIRMED, INFERRED, or REPORTED |
| No fabrication | No invented timestamps, ticket numbers, metric values, or team names |
| Root cause clarity | Root cause clearly distinguished from symptoms and proximate cause |
| Actionable follow-ups | At least one preventive action with clear ownership suggestion |
| Honest unknowns | Unknown items marked TBD, not guessed |

---

## Multi-Issue RCA

When multiple related incidents need joint analysis:

```
1. Generate individual timeline for each incident
2. Merge into unified timeline, annotating which incident each event belongs to
3. Identify common root cause or causal chain between incidents
4. Single "Root Cause Analysis" section covering the shared cause
5. Separate "Solution" sections if fixes differ per incident
```

---

## Integration with S2 Fault Scenarios

After completing any S2 path (F1-F10):

```
S2 Output (existing):
  Fault -> Impact Scope -> Emergency Recovery Steps -> Root Cause -> Evidence -> Preventive Measures

S2 + RCA Output (enhanced):
  Fault -> Impact Scope -> Emergency Recovery Steps -> Root Cause -> Evidence -> Preventive Measures
  +
  "Would you like me to generate a structured RCA document for this incident?"
  -> If yes: Execute this module's workflow (Steps 1-4)
  -> Output: Complete RCA document using the template above
```

MUST offer RCA generation after every P0/P1 fault resolution. SHOULD offer for P2 faults.
