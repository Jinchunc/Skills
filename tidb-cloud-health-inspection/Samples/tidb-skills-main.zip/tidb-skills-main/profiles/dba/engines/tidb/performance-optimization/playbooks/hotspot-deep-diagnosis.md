# PLAYBOOK: Hotspot Deep Diagnosis

> Deep analysis of read/write hotspots at Region granularity.
> Extends PATH-HOTSPOT (instance-level detection) with Region-level root cause and targeted remediation.

---

## When to Use

- PATH-HOTSPOT confirmed instance imbalance
- "One TiKV is at 90% CPU, others at 20%"
- Write throughput limited by single Region
- Auto-split not working / Region too large
- PD scheduling appears stuck

## Prerequisites

1. **MODULE-CLUSTER-ID** completed
2. Time range
3. PATH-HOTSPOT Step 1 confirmed imbalance exists

> **Metrics reference**: Standard PromQL templates in [promql-templates.md](../../references/promql-templates.md). Hotspot-specific queries below extend those templates with per-instance and per-region breakdowns.

---

## Phase 1: Characterize the Hotspot

### Step 1.1: Hot Instance Identification

> Base metrics → promql-templates #3.1 (gRPC Get), #3.4 (Scheduler CPU), #3.5 (Raftstore CPU). Below adds per-instance breakdown.

```
metrics:
  # Per-instance QPS breakdown by gRPC type
  sum(rate(tikv_grpc_msg_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)

  # Per-instance CPU by thread pool
  sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~".*"}[1m])) by (instance, name)
```

Identify: `hot_instance` = instance with highest load.

### Step 1.2: Read vs Write Classification

```
metrics:
  # Read QPS per instance
  read_qps: sum(rate(tikv_grpc_msg_duration_seconds_count{tidb_cluster_id="{cluster_id}", type=~"kv_get|coprocessor|kv_batch_get"}[2m])) by (instance)

  # Write QPS per instance
  write_qps: sum(rate(tikv_grpc_msg_duration_seconds_count{tidb_cluster_id="{cluster_id}", type=~"kv_prewrite|kv_commit"}[2m])) by (instance)
```

| Result | Classification | Go To |
|--------|---------------|-------|
| Read QPS skewed | Read hotspot | Phase 2A |
| Write QPS skewed | Write hotspot | Phase 2B |
| Both skewed | Mixed hotspot | Phase 2A + 2B |

---

## Phase 2A: Read Hotspot Analysis

### Step 2A.1: Region-Level Read Distribution

```
metrics:
  # Top regions by read flow
  topk(20, sum(rate(tikv_region_read_bytes{tidb_cluster_id="{cluster_id}", instance="{hot_instance}"}[2m])) by (region_id))

  # Read keys per region
  topk(20, sum(rate(tikv_region_read_keys{tidb_cluster_id="{cluster_id}", instance="{hot_instance}"}[2m])) by (region_id))
```

### Step 2A.2: Hot Region Table Mapping

Diagnostic SQL (for user execution):
```sql
-- Map region to table (TIKV_REGION_STATUS contains DB_NAME/TABLE_NAME directly)
SELECT REGION_ID, DB_NAME, TABLE_NAME, IS_INDEX, INDEX_NAME,
       START_KEY, END_KEY,
       APPROXIMATE_SIZE, APPROXIMATE_KEYS
FROM information_schema.TIKV_REGION_STATUS
WHERE REGION_ID IN ({hot_region_ids})
ORDER BY APPROXIMATE_KEYS DESC;
```

> Note: `TIKV_REGION_STATUS` maps regions to tables via decoded start/end keys. For tables with many regions, filter by `TABLE_NAME` instead.

### Step 2A.3: Read Hotspot Root Cause

| Pattern | Root Cause | Recommendation |
|---------|-----------|----------------|
| Single small table, all reads to leader | Small hot table | Enable follower read: `SET GLOBAL tidb_replica_read = 'closest-replicas';` (for user execution) |
| Single large table, narrow key range | Hot row/range | Consider caching layer or TiFlash replica |
| Index region hot | Frequent index lookup | Covering index to reduce lookback (for user execution) |
| Coprocessor heavy | Analytical query on TiKV | TiFlash for OLAP queries |

---

## Phase 2B: Write Hotspot Analysis

### Step 2B.1: Region-Level Write Distribution

```
metrics:
  # Top regions by write flow
  topk(20, sum(rate(tikv_region_written_bytes{tidb_cluster_id="{cluster_id}", instance="{hot_instance}"}[2m])) by (region_id))

  # Raft propose per region
  topk(20, sum(rate(tikv_raftstore_propose_total{tidb_cluster_id="{cluster_id}", instance="{hot_instance}"}[2m])) by (region_id))
```

### Step 2B.2: Auto-Increment / Monotonic Key Detection

Diagnostic SQL (for user execution):
```sql
-- Check if hot table uses auto-increment PK
SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, EXTRA
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA NOT IN ('mysql', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')
  AND EXTRA LIKE '%auto_increment%';

-- Check table options
SELECT TABLE_SCHEMA, TABLE_NAME, TIDB_ROW_ID_SHARDING_INFO, AUTO_INCREMENT_ID
FROM information_schema.TABLES
WHERE TABLE_SCHEMA NOT IN ('mysql', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')
  AND TABLE_NAME IN ('{hot_tables}');
```

### Step 2B.3: Write Hotspot Root Cause

| Pattern | Root Cause | Recommendation |
|---------|-----------|----------------|
| Auto-increment PK, sequential writes | Monotonic key hotspot | `ALTER TABLE {t} AUTO_RANDOM(5);` or `SHARD_ROW_ID_BITS = 4` (for user execution) |
| Time-series data, latest partition hot | Time-ordered writes | Pre-split regions, increase Region size, or scatter |
| Index with monotonic values (timestamp, serial) | Index hotspot | Consider removing or redesigning the index |
| Single hot Region not splitting | Region too new or split disabled | Check PD split config (below) |

### Step 2B.4: Region Split/Merge Analysis

> Base metrics → promql-templates #3.8 (Region Count), #3.9 (Leader Count), #4.2 (Scheduling Rate)

```
metrics:
  # Split operations
  sum(rate(tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}", type="region"}[5m])) by (instance)

  # PD operator count
  sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

| Observation | Interpretation |
|-------------|---------------|
| Region count stable, hot region not splitting | Region size < split threshold, or split disabled |
| Split happening but hotspot persists | Writes faster than split can distribute |
| Merge happening on hot range | Merge fighting split — check `merge-schedule-limit` |

---

## Phase 3: PD Scheduling Deep Dive

### Step 3.1: Scheduling Status

> Base metrics → promql-templates #4.2 (Scheduling Rate), #4.3 (Store Status)

```
metrics:
  # Scheduler status
  pd_scheduler_status{tidb_cluster_id="{cluster_id}"}

  # Store limit (max operations per store)
  pd_schedule_store_limit{tidb_cluster_id="{cluster_id}"} by (store, type)

  # Pending operators
  pd_schedule_operators_count{tidb_cluster_id="{cluster_id}", type="waiting"}
```

### Step 3.2: Scheduling Blockers

| Symptom | Possible Blocker | Check |
|---------|-----------------|-------|
| No balance operators | Scheduler disabled | `pd_scheduler_status` = 0 for balance-leader/balance-region |
| Operators pending but not executing | Store limit too low | `pd_schedule_store_limit` < needed throughput |
| Operators failing | Target store unhealthy | Check store state and available space |
| Leaders rebalanced but hotspot persists | Write hotspot follows leader | Need Region-level solution, not leader transfer |

### Step 3.3: PD Configuration Review

Diagnostic (for user execution via pd-ctl or API):
```
# Check scheduling config
pd-ctl config show schedule

# Key parameters for hotspot:
# - hot-region-schedule-limit (default: 4, increase for faster rebalancing)
# - hot-region-cache-hits-threshold (default: 3)
# - leader-schedule-limit
# - region-schedule-limit
# - enable-placement-rules
```

---

## Phase 4: Remediation Plan

### Immediate Actions (ranked by impact)

| Priority | Action | Scope | Risk |
|----------|--------|-------|------|
| 1 | Increase `hot-region-schedule-limit` | PD config | Low — only speeds up scheduling |
| 2 | Pre-split hot regions | Specific table | Low — online operation |
| 3 | Enable follower read (read hotspot) | Session/Global | Low — read-only change |
| 4 | ALTER TABLE AUTO_RANDOM (write hotspot) | DDL | **Medium** — requires table recreation for existing data |
| 5 | Add TiFlash replica (read hotspot) | DDL | Low — async replication |

### Pre-Split Command Templates (for user execution)

```sql
-- Pre-split table into N regions
SPLIT TABLE {table} BETWEEN ({min_key}) AND ({max_key}) REGIONS {N};

-- Pre-split index
SPLIT TABLE {table} INDEX {index_name} BETWEEN ({min_val}) AND ({max_val}) REGIONS {N};

-- Scatter regions for a table
ALTER TABLE {table} ATTRIBUTES 'merge_option=deny';  -- prevent merge after split
```

---

## Report Format

```
## Hotspot Deep Diagnosis Report
Cluster: {cluster_id} | Window: {start} ~ {end}

### Hotspot Type: READ / WRITE / MIXED
Hot Instance: {instance} ({load_ratio}x average)

### Root Cause
{root_cause} — Confidence: {HIGH/MEDIUM/LOW}
Evidence: {metrics, region IDs, table names}

### Affected Regions
| Region ID | Table | Size | Keys | Read/Write Flow |
|-----------|-------|------|------|----------------|

### PD Scheduling Status
- Balance operators active: YES/NO
- Scheduling blockers: {if any}

### Remediation Plan (for user execution)
1. [Immediate] {action}
2. [Short-term] {action}
3. [Long-term] {action}
```

---

## Relationship to Other Components

| Component | Relationship |
|-----------|-------------|
| PATH-HOTSPOT | Instance-level detection; this playbook does Region-level deep dive |
| MODULE-TIKV | Called for TiKV-level resource analysis |
| MODULE-PD | Called for scheduling analysis |
| PATH-LATENCY-WRITE | Write hotspot often manifests as write latency increase |
| PATH-QPS-CEILING | Hotspot is a common cause of QPS plateau |
