# Shared Profile Components

Source organized by the **2N model** — 4 time scales × 2 dimensions (Capability + Constraint).

## Scale Directories (Instruction Content)

Each directory = one time scale from the 2N model. Files within are fine-grained by concern.
Build concatenates them per-scale, then maps to target output.

| Directory | 2N Scale | Constraint Name | What It Governs |
|-----------|----------|-----------------|-----------------|
| `instant/` | Instant | **Admit** | What enters the system — content protection, injection defense |
| `session/` | Session | **SHOULD** | How this session works — skill dispatch, instruction priority, meta-rules |
| `execute/` | Execute | **Clearance** | Action safety — failure handling, security, scope, FS boundaries, tool routing |
| `evolve/`  | Evolve  | **Integrity** | Growth & protection — proactive behavior, efficiency, data safety |

### Build Mapping

```
instant/*  →  Claude: CLAUDE.md (global)    OpenClaw: SOUL.md
session/*  ┐
execute/*  ├→ Claude: CLAUDE.md (global)    OpenClaw: AGENTS.md
evolve/*   ┘
```

## Workspace Files (Flat)

Shared templates, not organized by scale. OpenClaw only — Claude Code uses native equivalents.

| File | Purpose | OpenClaw | Claude |
|------|---------|----------|--------|
| `USER.md` | User preferences template | Standalone file (protected) | Not included (native auto-memory) |
| `MEMORY.md` | Long-term memory starter | Standalone file (protected) | Not included (native auto-memory) |

## Per-Profile Workspace Files

Located in `profiles/<profile>/`.

| File | 2N Role | OpenClaw | Claude |
|------|---------|----------|--------|
| `IDENTITY.md` | Instant capability (who am I) | Standalone (protected) | Appended to global CLAUDE.md |
| `TOOLS.md` | Execute capability (tool config) | Standalone (protected) | `.claude/CLAUDE.md` (project-level) |
| `HEARTBEAT.md` | Evolve capability (feedback loops) | Standalone (protected) | Not included |
| `BOOTSTRAP.md` | Lifecycle (first-run onboarding) | Standalone (protected) | Not included |

"Protected" = install only if absent; never overwrite user customizations.

## Claude Code Specific Files

| File | Purpose | Source |
|------|---------|--------|
| `.claude/settings.json` | Hook configuration (audit, redact, skill-guard) | Generated from `hooks-claude/*.sh` |
| `.claude/hooks/*.sh` | Shell-based hook scripts | `hooks-claude/` directory |
| `.mcp.json` | MCP server recommendations | Generated from TOOLS.md |
| `.claude-plugin/plugin.json` | Plugin manifest | Generated from profile YAML |

## Hooks

Runtime defense-in-depth mechanisms, shared across all profiles. Two implementations per target:

| Hook | Purpose | Layer |
|------|---------|-------|
| `audit` | Logs all agent operations (tool calls, messages) to daily JSONL files | Compliance |
| `redact` | Strips credentials, tokens, and PII from outbound content | Data protection |
| `skill-guard` | Detects and blocks skill content leakage in outbound messages | Content protection |

**OpenClaw** (`hooks-openclaw/`): Each hook = `HOOK.md` + `handler.ts` (TypeScript). Installed to `workspace/hooks/`.

**Claude Code** (`hooks-claude/`): Each hook = `*.sh` (shell script). Wired via `.claude/settings.json` PreToolUse/PostToolUse events.

**Hooks vs Skills vs Agent Rules:**
- Agent rules (AGENTS.md) = prompt-layer behavioral constraints the model follows
- Skills = domain methodology loaded on dispatch
- Hooks = runtime code that runs regardless of model behavior (defense-in-depth)

## Skills

Located in `skills/` (repo root). Referenced by `<profile>.yaml`. Skills span multiple 2N scales — they are cross-scale capability modules, not bound to a single time scale.
