# FAULT-CLUSTER-UNAVAIL (F2 Cluster Unavailable)

> Entry condition: Entire cluster unreachable / All queries timeout
> Severity level: **P0** (Complete outage)
> Data source: Clinic API, all PromQL filtered with `tidb_cluster_id="{cluster_id}"`
> Note: When the cluster is completely unavailable, Clinic metrics may also be uncollectable; each step includes a fallback diagnostic method

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Fault start time (precise to the minute)
3. Client error message (connection refused / timeout / specific error code)

---

## Decision Tree

### Step 1: Confirm Fault Scope

**Goal**: Distinguish between "true cluster-level fault" and "client-side perceived unavailability"

```
Checks:
  a. Client error type classification:
     - "connection refused"       → All TiDB instances unreachable
     - "context deadline exceeded" → Query timeout (TiDB connectable but cannot return results)
     - "no available connection"   → Connection pool exhausted
     - "rpc error: region unavailable" → TiKV layer issue

  b. Are all clients affected:
     - Only a single client → Client-side network/configuration issue → Not a cluster fault
     - All clients → Continue to Step 2

  c. Clinic cluster status:
     Data source: clinic_search_cluster_by_id
     Check: status field
     - status != "active" → Cluster may be in maintenance/abnormal state

fallback (when Clinic is unavailable):
  Suggest user action:
    - Try connecting from a different network
    - telnet {tidb_host{tidb_cluster_id="{cluster_id}"}} 4000 to confirm port reachability
    - curl -s http://{tidb_host{tidb_cluster_id="{cluster_id}"}}:10080/status to check TiDB HTTP port
```

→ All clients unavailable → Step 2
→ Only partially unavailable → Refer to [PATH-CONN-FAIL](../paths/conn-fail.md)

### Step 2: PD Status Check (Highest Priority)

**Rationale**: PD is the cluster brain — when PD majority is down, the entire cluster halts (no TSO, no scheduling)

```
metrics:
  pd_cluster_status{tidb_cluster_id="{cluster_id}"}: pd_cluster_status{tidb_cluster_id="{cluster_id}"}
  tso_handle_p99: histogram_quantile(0.99,
    sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{
      tidb_cluster_id="{cluster_id}", type="tso"}[2m])) by (le))
  pd_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m])
  pd_uptime{tidb_cluster_id="{cluster_id}"}: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="pd"}
  etcd_wal_fsync: histogram_quantile(0.99,
    sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

Checks:
  2a. PD instance alive count:
      - Less than 2 of 3 instances alive → "PD majority lost" → Emergency Recovery 1
      - All alive → 2b

  2b. TSO latency:
      - tso_handle_p99 > 100ms → "TSO latency spike, all queries blocked"
      - tso_handle_p99 > 1s   → "TSO completely stalled"
      → Check etcd_wal_fsync > 10ms → "PD disk performance issue"
      → Check pd_cpu{tidb_cluster_id="{cluster_id}"} > 90% → "PD CPU overloaded"

  2c. PD Leader stability:
      pd_tso_events{tidb_cluster_id="{cluster_id}", type="save"} changing frequently
      → "Frequent PD leader switching causing TSO interruption"

fallback (when metrics are unavailable):
  Suggest user action:
    - curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/members to check PD member status
    - curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/leader to check current leader
    - curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/health to check etcd health status
```

→ PD abnormal → Emergency Recovery Priority 1
→ PD normal → Step 3

### Step 3: TiKV Storage Layer Check

**Rationale**: All TiKV down → No data can be served; Partial down → If Region replicas are insufficient, service is also unavailable

```
metrics:
  store_status: pd_scheduler_store_status{tidb_cluster_id="{cluster_id}"}
  tikv_uptime{tidb_cluster_id="{cluster_id}"}: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
  region_available: pd_regions_status{tidb_cluster_id="{cluster_id}"}
  grpc_errors: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
  server_busy: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}", type="server_is_busy"}[2m]))

Checks:
  3a. TiKV alive status:
      - All TiKV down → "All TiKV unavailable" → Emergency Recovery 2
      - Partial down → 3b

  3b. Region availability:
      - pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"} > 0 → Some Regions missing replicas
      - pd_regions_status{tidb_cluster_id="{cluster_id}", type="down-peer-region-count"} massively increasing → Region peers unreachable
      - PD disconnect store timeout = 20s, stores not responding for over 20s are marked as down

  3c. ServerIsBusy rejection (tikv#15800, tikv#17392):
      server_busy > 0 → "TiKV rejecting requests due to memory limit (ServerIsBusy)"
      → Although TiKV is alive, a large number of requests are rejected → Manifests as cluster unavailability
      → Check: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"} approaching memory limit

  3d. Single TiKV down causing partial Region unavailability:
      - In a 3-replica configuration, 2 TiKV nodes down → Some Regions cannot serve
      - Check replica configuration: pd_config_status{tidb_cluster_id="{cluster_id}"} or PD API

fallback (when metrics are unavailable):
  Suggest user action:
    - curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/stores to view all store statuses
    - Look for stores with state: "Down" or "Offline"
    - curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/regions/check/miss-peer to view Regions with missing replicas
```

→ TiKV abnormal → Emergency Recovery Priority 2
→ TiKV normal → Step 4

### Step 4: TiDB Compute Layer Check

**Rationale**: Connection pool exhaustion / TiDB process hang → Client perceives cluster as unavailable

```
metrics:
  tidb_uptime{tidb_cluster_id="{cluster_id}"}: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tidb"}
  connections: tidb_server_connections{tidb_cluster_id="{cluster_id}"} by (instance)
  tidb_cpu{tidb_cluster_id="{cluster_id}"}: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="tidb"}[1m])
  tidb_mem{tidb_cluster_id="{cluster_id}"}: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tidb"}
  query_total: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

Checks:
  4a. TiDB instance alive:
      - All TiDB down → "All TiDB instances unavailable" → Emergency Recovery 3
      - Partial down → Load shifts to surviving instances → Possible avalanche

  4b. Connection pool exhaustion:
      - connections approaching max-connections → "Connections maxed out"
      - query_total = 0 but connections high → "Connections full but no queries completing (all blocked)"
      → Suggest user action: SHOW PROCESSLIST to view blocked sessions

  4c. TiDB process hang:
      - tidb_cpu{tidb_cluster_id="{cluster_id}"} ≈ 0 but process alive → Possible GC pause or deadlock
      - tidb_cpu{tidb_cluster_id="{cluster_id}"} > 95% → CPU maxed out, unable to process new requests

  4d. TiDB disconnected from PD/TiKV:
      - TiDB alive but cannot obtain TSO → Review Step 2
      - TiDB alive but all KV requests failing → Review Step 3

fallback (when metrics are unavailable):
  Suggest user action:
    - curl -s http://{tidb_host{tidb_cluster_id="{cluster_id}"}}:10080/status to check TiDB health status
    - curl -s http://{tidb_host{tidb_cluster_id="{cluster_id}"}}:10080/info to view TiDB instance info
    - mysql -h {tidb_host{tidb_cluster_id="{cluster_id}"}} -P 4000 -e "SHOW PROCESSLIST" (if connectable)
```

→ TiDB abnormal → Emergency Recovery Priority 3
→ TiDB normal → Step 5

### Step 5: Network Layer Check

**Rationale**: Network partition can cause split-brain; cross-component network failures cause the cluster to appear unavailable

```
metrics:
  backoff: sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
  kv_request_err: sum(rate(tidb_tikvclient_request_seconds_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type, store)

Checks:
  5a. TiDB → TiKV network:
      - backoff with large amounts of regionMiss / tikvRPC → TiDB cannot access TiKV
      - kv_request all timing out → Network not reachable

  5b. TiDB → PD network:
      - tso_wait extremely high but PD-side tso_handle normal → TiDB to PD network latency
      → Refer to [PATH-NET-LATENCY](../../performance-optimization/paths/net-latency.md)

  5c. TiKV → PD network:
      - TiKV heartbeat timeout → PD marks store as down (20s timeout)
      - But TiKV process is actually alive → Network partition

  5d. Network partition (split-brain):
      - Some TiKV can connect to PD, some cannot → Region leader election anomaly
      - Manifestation: Some queries succeed, some timeout

fallback (when metrics are unavailable):
  Suggest user action:
    - ping/telnet TiKV nodes from TiDB node (port 20160)
    - ping/telnet PD nodes from TiDB node (port 2379)
    - ping/telnet PD nodes from TiKV node (port 2379)
    - Check if security group/firewall rules have changed
```

→ Network abnormal → Locate the specific breakpoint → Suggest user action to fix the network
→ Network normal → Review Steps 2-4, check for anything missed

---

## Emergency Recovery Priorities

> All recovery operations are marked "Suggest user action"; the diagnostic side only provides guidance

### Priority 1: PD Recovery (Highest Priority)

```
Cause: PD majority lost → Entire cluster halted

Suggest user action:
  1. Confirm PD member status:
     curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/members

  2. If PD instance can be restarted:
     Restart the failed PD instance, wait for it to join the cluster (usually recovers within 30s)

  3. If PD data is corrupted (extreme case):
     Use the pd-recover tool to recover (requires intact TiKV data)
     Reference: https://docs.pingcap.com/tidb/stable/pd-recover

  4. TSO latency spike (PD alive but TSO slow):
     - Check PD node disk IO (etcd WAL fsync)
     - Check PD node CPU load
     - If necessary, trigger PD leader switch:
       curl -X POST http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/leader/resign
```

### Priority 2: TiKV Recovery

```
Cause: TiKV unavailable → Cannot read or write data

Suggest user action:
  1. Confirm TiKV process status:
     curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/stores

  2. TiKV process has exited:
     - Check TiKV logs for panic / OOM information
     - Restart TiKV instance

  3. TiKV ServerIsBusy:
     - Check memory usage, confirm if memory limit rejection was triggered
     - Short-term: Restart TiKV to release memory
     - Long-term: Adjust memory-usage-limit or scale up

  4. Insufficient Region replicas:
     - Wait for PD to automatically schedule replica addition (requires surviving TiKV)
     - Check: curl http://{pd_host{tidb_cluster_id="{cluster_id}"}}:2379/pd/api/v1/regions/check/miss-peer
```

### Priority 3: TiDB Recovery

```
Cause: TiDB unavailable → Clients cannot connect

Suggest user action:
  1. Restart the failed TiDB instance (TiDB is stateless, restart cost is minimal)

  2. Connection pool exhaustion:
     - KILL long-blocked sessions
     - Check application-side connection pool configuration (maxIdle, maxOpen, maxLifetime)

  3. TiDB CPU maxed out:
     - Check if large queries are consuming all CPU
     - KILL abnormal queries to recover
```

---

## Loki Log Search Templates

> Applicable: Dedicated / Premium clusters

```logql
# PD anomaly logs
{component="pd"} |~ "(?i)leader changed|campaign|resign|lost leader"

# TiKV anomaly logs
{component="tikv"} |~ "(?i)panic|fatal|server is busy|memory|OOM|store heartbeat"

# TiDB connection/timeout logs
{component="tidb"} |~ "(?i)connection refused|context deadline|rpc error|no available"

# Region unavailable logs
{component="tikv"} |~ "(?i)region unavailable|not leader|peer not found"
```

---

## Data Source Call Templates

### Cluster Status
```
Data source: clinic_search_cluster_by_id
Parameters: cluster_id = "{cluster_id}"
Check: status field
```

### PD Member Alive
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="pd"}
```

### PD TSO Latency
```
query: histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{tidb_cluster_id="{cluster_id}", type="tso"}[2m])) by (le))
```

### etcd WAL Fsync Latency
```
query: histogram_quantile(0.99, sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### PD CPU
```
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="pd"}[1m])
```

### TiKV Store Status
```
query: pd_scheduler_store_status{tidb_cluster_id="{cluster_id}"} by (instance, type)
```

### TiKV Alive Detection
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
```

### Region Availability
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}"} by (type)
```

### ServerIsBusy Frequency
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}", type="server_is_busy"}[2m]))
```

### TiKV Memory
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="tikv"} by (instance)
```

### TiDB Alive Detection
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tidb"}
```

### TiDB Connection Count
```
query: tidb_server_connections{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiDB QPS
```
query: sum(rate(tidb_server_query_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
```

### Backoff Distribution
```
query: sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### gRPC Errors
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance, type)
```
