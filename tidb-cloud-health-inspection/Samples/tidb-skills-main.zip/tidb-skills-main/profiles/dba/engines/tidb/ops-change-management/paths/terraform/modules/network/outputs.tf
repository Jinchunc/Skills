output "vpc_id" {
  value       = module.vpc.vpc_id
  description = "Created VPC ID."
}

output "private_subnet_ids" {
  value       = module.vpc.private_subnets
  description = "Private subnet IDs."
}

output "public_subnet_ids" {
  value       = module.vpc.public_subnets
  description = "Public subnet IDs."
}

output "private_route_table_ids" {
  value       = module.vpc.private_route_table_ids
  description = "Private subnet route table IDs (for gateway endpoints)."
}
