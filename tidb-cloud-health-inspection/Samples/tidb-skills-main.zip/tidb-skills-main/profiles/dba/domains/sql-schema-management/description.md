# Domain 6: SQL 与 Schema 管理 (SQL & Schema Management)

> Status: **Partial**
> Tier: C (Engine-strong)

## Core

表结构设计 + SQL 审核 + DDL 变更评估。事前指导为主。

## Scenarios

### 设计
- 表结构设计
- 索引策略
- 分区方案选择
- 范式/反范式选择

### 审核
- 上线前 SQL 规范扫描（全表扫描、隐式转换、未命中索引）
- 执行计划预评估
- SQL 改写建议
- 跨引擎兼容性检查

### 变更
- DDL 变更影响评估（锁表时间、数据回填量）
- 回滚方案生成

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | — (engine skill not yet built; domain has shared methodology only) | Gap |
| MySQL | — | Not yet built |
| PostgreSQL | — | Not yet built |
| MongoDB | — | Not yet built |

## Key Checks (to build)

- 表结构合理性
- 索引覆盖度
- 分区策略评估
- 隐式转换检测
- 大结果集预警
- 笛卡尔积检测
- 执行计划代价估算
- DDL 锁时间估算

## Routing Note

- 上线前 SQL 事前审核 → 本域
- 已上线 SQL 事后慢查询诊断 → 域2 (performance-optimization)
- 表结构优化（分区方案/反范式） → 本域
- 容量驱动归档（大表 TTL） → 域8 (resource-cost-manager)
