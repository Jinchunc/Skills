variable "cluster_name" {
  type        = string
  description = "EKS cluster name."
}

variable "cluster_admin_principal_arn" {
  type        = string
  description = "IAM principal ARN granted cluster admin access. Accepts any IAM role/user ARN (e.g. the ARN from `aws sts get-caller-identity`, or an `AWSReservedSSO_*` role ARN). Empty string falls back to the caller's own ARN."
  default     = ""
}

variable "readonly_principal_arns" {
  type        = list(string)
  description = "Additional IAM principal ARNs with read-only EKS access."
  default     = []
}

variable "tags" {
  type        = map(string)
  description = "Common tags."
  default     = {}
}
