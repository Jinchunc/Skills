variable "cluster_name" {
  type        = string
  description = "EKS cluster name."
}

variable "ebs_csi_role_arn" {
  type        = string
  description = "IAM role ARN for EBS CSI addon."
}

variable "enable_ingress_nginx" {
  type        = bool
  description = "Install ingress-nginx via Helm."
  default     = false
}

variable "enable_metrics_server" {
  type        = bool
  description = "Install metrics-server via Helm."
  default     = true
}

variable "metrics_server_chart_version" {
  type        = string
  description = "Helm chart version for metrics-server."
  default     = "3.12.2"
}

variable "ingress_nginx_chart_version" {
  type        = string
  description = "Helm chart version for ingress-nginx."
  default     = "4.11.2"
}

variable "metrics_server_values" {
  type        = list(string)
  description = "Additional Helm values for the metrics-server release (list of YAML strings)."
  default     = []
}

variable "ingress_nginx_values" {
  type        = list(string)
  description = "Additional Helm values for the ingress-nginx release (list of YAML strings)."
  default     = []
}

variable "tags" {
  type        = map(string)
  description = "Common tags."
  default     = {}
}
