# Serverless Audit Log

Base command: `ticloud serverless audit-log`

Manage TiDB Cloud Serverless database audit logging

## Direct Subcommands

- `ticloud serverless audit-log config` - Manage TiDB Cloud Serverless database audit logging configuration
- `ticloud serverless audit-log describe` - Describe the database audit logging configuration
- `ticloud serverless audit-log disable` - Disable the database audit logging (dangerous)
- `ticloud serverless audit-log download` - Download the database audit log files (sensitive)
- `ticloud serverless audit-log enable` - Enable the database audit logging (sensitive)
- `ticloud serverless audit-log filter-rule` - Manage TiDB Cloud Serverless database audit logging filter rules

## Confirmation Required

- `ticloud serverless audit-log disable`
