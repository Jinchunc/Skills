# Projects

Base command: `ticloud project`

Manage projects

## Direct Subcommands

- `ticloud project list` - List all accessible projects (human-output)
