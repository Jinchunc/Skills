output "s3_irsa_role_arn" {
  value       = module.tidb_x_s3_irsa_role.iam_role_arn
  description = "ARN of the IRSA IAM role annotated onto the tidb-x-s3 ServiceAccount."
}

output "operator_namespace" {
  value       = var.operator_namespace
  description = "Kubernetes namespace where tidb-operator is deployed."
}

output "cluster_namespace" {
  value       = var.cluster_namespace
  description = "Kubernetes namespace where the TiDB cluster CRD instances live."
}

output "cluster_name" {
  value       = var.cluster_name
  description = "Name of the deployed TiDB cluster."
}
