# Domain 8: 资源与成本 (Resource & Cost Management)

> Status: **Gap**
> Tier: A (Engine-agnostic)

## Core

实例生命周期 + 容量规划 + 成本分析。

## Scenarios

- 多维度实例筛选与查询
- 存储增长趋势预测与扩容规划
- 计费单元用量分析（provider-specific billing-unit，如 serverless 产品的计量单位）
- 实例规格 right-sizing
- 闲置/孤儿资源识别
- 成本趋势预测与分摊
- 大表识别与数据归档策略（TTL/分区归档）
- EOL/到期预警

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | — (engine skill not yet built) | Gap |
| MySQL | — | Not yet built |
| PostgreSQL | — | Not yet built |
| MongoDB | — | Not yet built |

## Key Checks (to build)

- 实例清单（状态/版本/规格/区域）
- 存储增长外推（几天后满）
- 计费单元余量预测（provider-specific billing-unit throttling 风险）
- 闲置/孤儿资源检测
- right-sizing 模拟
- TTL/分区归档策略建议
- 成本分摊报表

## Routing Note

- 容量驱动归档（大表 TTL） → 本域
- 表结构优化（分区方案选择） → 域6 (sql-schema-management)
- 资源容量趋势预测 → 本域
- 当前资源瓶颈定位 → 域2 (performance-optimization)
