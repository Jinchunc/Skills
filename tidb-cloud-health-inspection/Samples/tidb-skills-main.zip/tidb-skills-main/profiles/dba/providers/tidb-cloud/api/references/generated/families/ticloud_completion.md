# Shell Completion

Base command: `ticloud completion`

Generate the autocompletion script for the specified shell

## Direct Subcommands

- `ticloud completion bash` - Generate the autocompletion script for bash
- `ticloud completion fish` - Generate the autocompletion script for fish
- `ticloud completion powershell` - Generate the autocompletion script for powershell
- `ticloud completion zsh` - Generate the autocompletion script for zsh
