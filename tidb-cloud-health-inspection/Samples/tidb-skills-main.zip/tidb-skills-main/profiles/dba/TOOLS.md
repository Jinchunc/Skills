# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics -- the stuff that's unique to your setup.

## Databases

- **Primary engine:**
- **Version:**
- **Connection string location:** _(env var name, secrets manager path)_
- **Replica topology:**

## Database Instances

_(List your database instances, their roles, and access details.)_

| Name | Engine | Role | Host/Port |
|------|--------|------|-----------|
| | | primary | |
| | | replica | |

## Migration Tools

- **Tool:** _(Flyway/Liquibase/Alembic/raw SQL)_
- **Migration directory:**
- **Naming convention:**

<!-- SHIPPED — DO NOT MODIFY THIS SECTION -->
## Runtime Capabilities (shipped)

This agent runtime provides the following credentials and helpers out of the box:

| Capability | Env var / path | What it enables |
|------------|----------------|-----------------|
| Clinic internal API | `CLINIC_API_TOKEN` | Cluster search/enumeration, cluster metadata, PromQL metrics, Loki logs, slow queries, events |
| Clinic helper CLI | `clinic.sh` (available at `/opt/hermes/bin` in the hermes runtime) | curl wrapper for the Clinic API with Bearer auth injected |
| O11Y data layer | `GITHUB_PAT` | Direct S3/Delta Lake/Prometheus/Loki access via the O11Y backend |

Entry points worth knowing:

- **Org-wide fleet overview** ("整理某 org 下所有集群的整体情况"): follow
  `engines/tidb/instance-inspection/playbooks/org-fleet-overview.md` —
  enumerates via the Clinic search API with pagination, collects lightweight
  per-cluster data, and produces an aggregated fleet report.
- Single-cluster deep inspection: `engines/tidb/instance-inspection/checklist.md`.

## Recommended MCP Servers

These complement your skills:

- **postgres-mcp** (crystaldba) -- PG health analysis, index tuning
- **dbhub** (bytebase) -- multi-database gateway
- **genai-toolbox** (Google) -- 15+ DB connection pool
- **mongodb-mcp** -- official MongoDB operations
- **mcp-redis** -- full data type support + vector search
- **mcp-clickhouse** -- official OLAP operations
- **mcp-server-neon** -- branch management + schema migration

## Monitoring

- **Slow query log location:**
- **Performance dashboard:**
- **Alerting thresholds:**

---

Add whatever helps you do your job. This is your cheat sheet.
