# Serverless Import

Base command: `ticloud serverless import`

Manage TiDB Cloud Serverless data imports

## Direct Subcommands

- `ticloud serverless import cancel` - Cancel a data import task (dangerous)
- `ticloud serverless import describe` - Describe a data import task
- `ticloud serverless import list` - List data import tasks (human-output)
- `ticloud serverless import start` - Start a data import task

## Confirmation Required

- `ticloud serverless import cancel`
