# PATH-QUERY-ERROR (S3.1 Query Error)

> Entry condition: User encounters query errors (region unavailable / tikv timeout / server is busy)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range, error message

---

## Decision Tree

### Step 1: Error Classification

```
metrics:
  exec_error:  sum(rate(tidb_server_execute_error_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type, instance)
  grpc_fail:   sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type, instance)
  backoff:     sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)

Classification (route by type label):
  type=~"not_leader|stale_epoch|region_not_found|server_is_busy.*region.*"  → Step 2a (region_error)
  type=~"tikvRPC|pdRPC|txnLockFast"                                         → Step 2b (timeout_error)
  type=~"server_is_busy"                                                     → Step 2c (busy_error)
  Other                                                                      → Step 2d
```

### Step 2a: Region Error

> region unavailable / not leader / epoch not match

```
metrics:
  sched_ops:    sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
  region_count: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)
  pending_peer: pd_regions_status{tidb_cluster_id="{cluster_id}", type="pending-peer-region-count"}
  missing_peer: pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"}
  uptime:       time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}

condition:
  pending_peer > 100 → Region health abnormal (threshold from ../../knowledge/product-lines/dedicated.md)
  missing_peer > 0 persisting > 5min → Replica missing
  A TiKV uptime < 300s → Recently restarted
```
- → [MODULE-PD](../../performance-optimization/modules/pd-diagnosis.md)

### Step 2b: Timeout Error

> tikv timeout / kv request timeout

```
metrics:
  grpc_p99:  histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))
  grpc_p999: histogram_quantile(0.999, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))

condition:
  grpc_p99 > 1s → Latency is indeed high → Go to [PATH-LATENCY-GLOBAL](../../performance-optimization/paths/latency-global.md)
  grpc_p99 < 100ms but client reports timeout → Check client timeout configuration (KV single request timeout default 60s)
```

### Step 2c: Busy Error

> server is busy / raftstore is busy / scheduler is busy

→ [PATH-THROTTLE](../../performance-optimization/paths/throttle.md)
→ [MODULE-TIKV](../../performance-optimization/modules/tikv-fast-tune.md) W_RAFTSTORE / W_SCHEDULER

### Step 2d: Other Errors

- Check error details in Loki logs
- Classify by error code + search knowledge base

→ DIAGNOSIS → END

---

## Data Source Call Templates

### Execution Errors
```
query: sum(rate(tidb_server_execute_error_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type, instance)
```

### gRPC Request Failures
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type, instance)
```

### Backoff Statistics
```
query: sum(rate(tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### gRPC Latency P99
```
query: histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))
```

### PD Scheduling Operations
```
query: sum(rate(pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### Region Health Status
```
query: pd_regions_status{tidb_cluster_id="{cluster_id}"} by (type)
```

### TiKV Uptime
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
```
