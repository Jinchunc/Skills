# FAULT-REGION-UNAVAIL (F3 Region Unavailable)

> Entry condition: "region is unavailable" error / Partial data inaccessible
> Severity level: **P0** (Data unavailable, impacts business reads and writes)
> Data source: Clinic API, all PromQL filtered with `tidb_cluster_id="{cluster_id}"`

---

## Prerequisites

1. **MODULE-CLUSTER-ID**: Obtain cluster_id, product_line, version, topology
2. Time range + `region_id` from error message
3. Record affected tables/key range (if obtainable from error logs)

---

## Decision Tree

### Step 1: Confirm Region Status

```
query_region_count:
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="region_count"}

query_missing_peers:
  pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"}

query_down_peers:
  pd_regions_status{tidb_cluster_id="{cluster_id}", type="down-peer-region-count"}

query_pending_peers:
  pd_regions_status{tidb_cluster_id="{cluster_id}", type="pending-peer-region-count"}

query_empty_regions:
  pd_regions_status{tidb_cluster_id="{cluster_id}", type="empty-region-count"}

Judgment:
  missing_peers > 0  → Region replicas missing (some replicas cannot be scheduled)
  down_peers > 0     → Region replicas offline (TiKV node unreachable)
  pending_peers > 0  → Region replicas syncing (may be recovering)

Key thresholds:
  - max-peer-down-duration = 10 minutes (peer marked as down after timeout)
  - PD disconnect store timeout = 20 seconds (store disconnection determination)
```

**The essence of Region unavailability**: The majority of a Region's replicas are simultaneously unavailable, Raft cannot elect a Leader, and all reads/writes on that Region are blocked.

→ If missing_peers or down_peers is significantly > 0, continue to Step 2

---

### Step 2: Multiple Regions or Single Region

```
Check method:
  a. Does the error log contain only a single region_id → Single Region issue
  b. Multiple different region_ids in errors → Multiple Region issue
  c. down_peers magnitude:
     - < 10 and concentrated on the same store → Possibly a single node partial issue
     - > 100 or across multiple stores → Node down or network partition

Routing:
  Single Region issue  → Step 5 (Data corruption check)
  Multiple Regions + concentrated on few stores → Step 3 (TiKV node status)
  Multiple Regions + scattered → Step 4 (Network partition check)
```

---

### Step 3: TiKV Node Status Check

```
query_store_status:
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="store_up_count"}
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="store_down_count"}
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="store_offline_count"}
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="store_tombstone_count"}

query_uptime:
  time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
  by (instance)

Checks:
  a. store_down_count > 0 → There are TiKV nodes down
     → Record the down store_id and instance
     → Jump to: FAULT-NODE-DOWN to investigate node down root cause

  b. All stores status up but there are down_peers:
     → Possible network partition → Step 4
     → Or process pseudo-death (OOM killed, hung) → Check TiKV logs

  c. store_offline_count > 0:
     → There are stores being decommissioned (scale-in operation in progress)
     → If region migration is not complete during decommissioning, it may be temporarily unavailable

  d. Recent restart (uptime < 10min):
     → Region leaders are being re-elected
     → Wait for automatic recovery (usually < 1 minute)
```

→ If node down is confirmed, refer to **FAULT-NODE-DOWN** for node-level issues
→ If all nodes are online but region unavailable persists, continue to Step 4

---

### Step 4: Network Partition Check

```
query_raft_drop:
  sum(rate(tikv_server_raft_message_recv_total{tidb_cluster_id="{cluster_id}",
    type="drop"}[2m])) by (instance)

query_raft_drop_by_reason:
  sum(rate(tikv_server_raft_message_recv_total{tidb_cluster_id="{cluster_id}",
    type="drop"}[2m])) by (instance, reason)

query_unreachable:
  sum(rate(tikv_server_report_failure_msg_total{tidb_cluster_id="{cluster_id}",
    type="unreachable"}[2m])) by (instance, store_id)

query_snapshot_sending:
  sum(rate(tikv_raftstore_snapshot_traffic_total{tidb_cluster_id="{cluster_id}",
    type="sending"}[2m])) by (instance)

Checks:
  a. raft drop messages > 0:
     - reason="region-overlap" → Stale region / orphan peer exists
       → Step 5 Scenario C (orphan peer cleanup)
     - reason="stale" → Old messages, usually harmless
     - Other reasons → Record, may be normal behavior during region split/merge

  b. Unreachable store reports:
     - Continuously reporting a store as unreachable → Network partition or that store's process is abnormal
     - Intermittent → Network jitter

  c. Search TiKV logs for:
     "leader missing longer than abnormal_leader_missing_duration"
     → That region has had no leader for a long time, possibly a stale peer blocking election
```

---

### Step 5: Data Corruption Check

```
Check TiKV logs for critical errors:
  a. "corruption" / "checksum mismatch" / "bad sst"
     → SST file corruption → Scenario B (Data corruption recovery)

  b. "raft entry is missing" / "entry index out of range"
     → Raft log corruption → Scenario B

  c. "region not found" + region_id does not exist in pd-ctl region
     → Region metadata lost → Scenario B

  d. No clear corruption logs:
     → Possibly orphan peer or region epoch mismatch
     → Scenario C (orphan peer cleanup)
```

---

## Emergency Recovery

### Scenario A: Caused by TiKV Node Down

**Prerequisite**: TiKV nodes are down and majority replicas are unavailable

```
Recovery path:

1. If the down node can be recovered:
   - Suggest user action: Restart the down TiKV node
   - Wait for region leader election to complete (usually < 1 minute)
   - Monitor: down_peers count should continuously decrease to 0

2. If the down node cannot be recovered but majority is still alive:
   - PD will automatically add replicas after max-peer-down-duration (10 minutes)
   - Monitor: pending_peers increasing (indicates replicas being added)
   - Monitor: missing_peers should gradually decrease

3. If the down node cannot be recovered and majority is lost:
   → Jump to Scenario B (unsafe-recover)
```

→ For node-level root cause investigation, refer to **FAULT-NODE-DOWN**

---

### Scenario B: Data Corruption / Majority Lost Recovery

**Prerequisite**: Majority replicas of a Region are unavailable, automatic recovery is not possible

#### B1: SST File Corruption Repair

```
Suggest user action (requires ops permissions):

Step 1: Detect corrupted SST files
  tikv-ctl --data-dir /path/to/tikv-data bad-ssts

Step 2: Attempt repair
  ldb repair --db=/path/to/tikv-data/db

Step 3: If repair fails
  - Tombstone the corrupted store
  - Recover region data from other replicas

Note: SST repair may cause data loss; must confirm backup is available
```

#### B2: Online Unsafe Recovery (pd-ctl)

```
Applicable conditions:
  - Cluster is still online
  - Some TiKV stores are permanently lost
  - Majority replicas of affected regions are unavailable

Suggest user action:

Step 1: Confirm unrecoverable stores
  pd-ctl store  # List all store statuses

Step 2: Execute unsafe remove-failed-stores
  pd-ctl unsafe remove-failed-stores <store_id1>,<store_id2>,...

Step 3: Monitor recovery progress
  pd-ctl unsafe remove-failed-stores show

Mechanism explanation:
  - PD will force-create new leaders on surviving replicas for regions that lost majority
  - May lose the latest uncommitted Raft logs (small data loss risk)
  - After recovery, region replica count will be insufficient; PD will automatically add replicas

Note:
  - This operation is irreversible
  - Must confirm the stores are truly unrecoverable before operating
  - Check data consistency after the operation
```

---

### Scenario C: Orphan Peer Cleanup

**Prerequisite**: Stale region / orphan peer blocking normal region election

```
Diagnosis:

Step 1: Scan region status
  pd-ctl region scan --limit=1000 | Search for abnormal regions

Step 2: Compare with TiKV historical logs
  Search "leader missing longer than abnormal_leader_missing_duration"
  Search "region-overlap" drop messages
  → Identify the store_id and region_id of orphan peers

Cleanup (suggest user action):

Option 1: Tombstone orphan region on the problematic store
  tikv-ctl --data-dir /path/to/tikv-data tombstone -r <region_id>

Option 2: If orphan peer causes widespread unavailability
  pd-ctl unsafe remove-failed-stores (same as Scenario B2)

Option 3: Manually recreate region (extreme case)
  tikv-ctl --data-dir /path/to/tikv-data recreate-region \
    -r <region_id> -s <store_id>
```

---

### Scenario D: Region Metadata Storm (Large Clusters)

**Prerequisite**: Large cluster (Region count > 500K) experiencing batch region unavailable

```
Reference: tikv#18532

Symptoms:
  - Large number of regions simultaneously reporting unavailable
  - PD heartbeat backlog
  - TiKV raftstore CPU spikes

query_region_count:
  pd_cluster_status{tidb_cluster_id="{cluster_id}", type="region_count"}

query_heartbeat_latency:
  histogram_quantile(0.99,
    sum(rate(pd_scheduler_region_heartbeat_latency_seconds_bucket{
      tidb_cluster_id="{cluster_id}"}[2m])) by (le))

query_raftstore_cpu:
  sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}",
    name=~"raftstore.*"}[1m])) by (instance)

Judgment:
  region_count > 500000 + heartbeat_latency > 5s
  → Region metadata processing bottleneck

Mitigation (suggest user action):
  a. Merge empty Regions: pd-ctl config set enable-merge=true
  b. Increase heartbeat capacity: pd-ctl config set region-schedule-limit=2048
  c. Long-term solution: Enable Titan / Split cluster / Upgrade to version with region merge optimization
```

---

## Data Source Call Templates

### Region Status Overview

```
query: pd_regions_status{tidb_cluster_id="{cluster_id}"}
```

### Down Peer Count

```
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type="down-peer-region-count"}
```

### Missing Peer Count

```
query: pd_regions_status{tidb_cluster_id="{cluster_id}", type="miss-peer-region-count"}
```

### Store Status

```
query: pd_cluster_status{tidb_cluster_id="{cluster_id}", type="store_down_count"}
```

### Raft Message Drop

```
query: sum(rate(tikv_server_raft_message_recv_total{tidb_cluster_id="{cluster_id}", type="drop"}[2m])) by (instance, reason)
```

### Unreachable Store Reports

```
query: sum(rate(tikv_server_report_failure_msg_total{tidb_cluster_id="{cluster_id}", type="unreachable"}[2m])) by (instance, store_id)
```

### TiKV Instance Uptime

```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
```

### Region Heartbeat Latency

```
query: histogram_quantile(0.99, sum(rate(pd_scheduler_region_heartbeat_latency_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Raftstore CPU

```
query: sum(rate(tikv_thread_cpu_seconds_total{tidb_cluster_id="{cluster_id}", name=~"raftstore.*"}[1m])) by (instance)
```
