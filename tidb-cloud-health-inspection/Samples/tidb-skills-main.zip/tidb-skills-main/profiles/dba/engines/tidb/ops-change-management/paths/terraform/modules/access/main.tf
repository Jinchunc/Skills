data "aws_caller_identity" "current" {}

# When the caller is an STS assumed-role session, resolve the underlying IAM
# role ARN. The raw STS ARN (arn:aws:sts::…:assumed-role/Role/session) is not a
# valid principal for EKS access entries and changes per session, which would
# cause perpetual drift on the access entry resource.
data "aws_iam_session_context" "current" {
  count = can(regex(":assumed-role/", data.aws_caller_identity.current.arn)) ? 1 : 0
  arn   = data.aws_caller_identity.current.arn
}

locals {
  # Prefer an explicit IAM principal ARN because SSO-backed assumed roles include
  # a reserved path that cannot be safely reconstructed from the STS ARN alone.
  cluster_admin_principal_arn = var.cluster_admin_principal_arn != "" ? var.cluster_admin_principal_arn : (
    length(data.aws_iam_session_context.current) > 0
    ? data.aws_iam_session_context.current[0].issuer_arn
    : data.aws_caller_identity.current.arn
  )
}

resource "aws_eks_access_entry" "cluster_admin" {
  cluster_name  = var.cluster_name
  principal_arn = local.cluster_admin_principal_arn
  type          = "STANDARD"

  tags = var.tags
}

resource "aws_eks_access_policy_association" "cluster_admin" {
  cluster_name  = var.cluster_name
  principal_arn = aws_eks_access_entry.cluster_admin.principal_arn
  policy_arn    = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy"

  access_scope {
    type = "cluster"
  }
}

resource "aws_eks_access_entry" "readonly" {
  for_each = toset(var.readonly_principal_arns)

  cluster_name  = var.cluster_name
  principal_arn = each.key
  type          = "STANDARD"
  tags          = var.tags
}

resource "aws_eks_access_policy_association" "readonly" {
  for_each = toset(var.readonly_principal_arns)

  cluster_name  = var.cluster_name
  principal_arn = each.value
  policy_arn    = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy"

  access_scope {
    type = "cluster"
  }
}
