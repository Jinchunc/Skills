# FAULT-CDC-LAG (F9 TiCDC Replication Anomaly)

> Entry condition: changefeed lag increasing / replication interrupted / changefeed error
> Severity level: P1 (replication lag continuously increasing) → P0 (replication completely interrupted / changefeed failed)
> Applicable product line: Primarily Dedicated (TiCDC component requires independent deployment; Starter/Essential do not support TiCDC)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. changefeed ID
3. Downstream type (MySQL / Kafka / S3)
4. Time range

> **Field correction:** TiCDC requires every table to have PK or NOT NULL UK. Virtual generated column indexes do not count. SEQUENCE DDL is not replicated (#4). See [field-corrections.md](../../knowledge/field-corrections.md).

---

## Decision Tree

### Step 1: Confirm CDC Status

```
metrics:
  changefeed_status: max(ticdc_owner_status{tidb_cluster_id="{cluster_id}"}) by (changefeed)
    # 0=Normal, 1=Error, 2=Failed, 3=Stopped, 4=Finished, -1=Unknown
  checkpoint_lag: max(ticdc_owner_checkpoint_ts_lag{tidb_cluster_id="{cluster_id}"}) by (changefeed)
  resolved_ts_lag: max(ticdc_owner_resolved_ts_lag{tidb_cluster_id="{cluster_id}"}) by (changefeed)

Judgment:
  status = 2 (Failed) → P0 replication interrupted → Step 5 (TiCDC error logs)
  status = 1 (Error)  → P1 replication anomaly → Step 2
  status = 3 (Stopped) → User manually paused or auto-stopped → Confirm if expected
  checkpoint_lag continuously increasing → Step 2
  checkpoint_lag stable < 10s → Replication normal → END
```

### Step 2: Resolved-TS Check

```
metrics:
  owner_resolved_lag: max(ticdc_owner_resolved_ts_lag{tidb_cluster_id="{cluster_id}"}) by (changefeed)
  processor_resolved_lag: max(ticdc_processor_resolved_ts_lag{tidb_cluster_id="{cluster_id}"}) by (instance, changefeed)

Judgment:
  resolved_ts_lag frozen (not advancing) → Step 3 (upstream TiKV issue)
  resolved_ts_lag advancing normally but checkpoint_lag increasing → Step 4 (downstream issue)
  resolved_ts_lag slowly increasing → Possibly blocked by large transaction → Step 3
```

**Key concept**: resolved-ts represents TiKV informing TiCDC that "all data changes before this timestamp have been sent." A frozen resolved-ts means TiCDC cannot obtain upstream change progress.

### Step 3: Upstream TiKV Check

**3a: TiKV Health Status**
```
metrics:
  uptime: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
  region_count: tikv_raftstore_region_count{tidb_cluster_id="{cluster_id}"} by (instance)

Checks:
  TiKV instance restarted → CDC needs to reconnect after restart, brief lag is normal
  TiKV instance unavailable → FAULT-NODE-DOWN
```

**3b: Large transaction blocking resolved-ts**
```
metrics:
  resolved_ts_min: tikv_resolved_ts_min_resolved_ts_gap_seconds{tidb_cluster_id="{cluster_id}"} by (instance)

If loki_available:
  Search keywords:
    {component="tikv"} |~ "(?i)resolved-ts|advance.*resolve|min_resolved_ts"
    {component="tikv"} |~ "(?i)lock.*resolve|large.*txn"

Judgment:
  A TiKV instance has abnormally large resolved-ts gap → Long uncommitted transaction on that instance
  → DIAGNOSIS: Large/long transaction blocking resolved-ts advancement
  → Suggest user action: Check and terminate long transactions; optimize business logic to avoid oversized transactions
```

**3c: GC Safepoint blocked by CDC**
```
metrics:
  gc_safepoint: tikv_gcworker_autogc_safe_point{tidb_cluster_id="{cluster_id}"}

If loki_available:
  Search keywords:
    {component="tidb"} |~ "(?i)gc.*safepoint.*blocked|service_gc_safepoint"
    {component="ticdc"} |~ "(?i)gc.*safepoint|service.*safepoint"

Judgment:
  GC safepoint not advancing for a long time → CDC changefeed checkpoint is blocking GC
  → Note: This is a bidirectional relationship — CDC blocking GC causes MVCC version accumulation,
    and MVCC accumulation may slow down TiKV scans, further slowing CDC
  → Suggest user action: If changefeed is deprecated, delete the changefeed to release GC safepoint
```

**3d: Frequent Region Leader transfers**
```
metrics:
  leader_change: sum(rate(tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

Frequent leader changes → CDC needs to reconnect to leader → Brief resolved-ts stall
→ PATH-HOTSPOT / FAULT-LEADER-DROP
```

### Step 4: Downstream Check

**4a: Sink Throughput**
```
metrics:
  sink_rows: sum(rate(ticdc_sink_table_sink_total_rows_count{tidb_cluster_id="{cluster_id}"}[1m])) by (changefeed, instance)
  mounter_rows: sum(rate(ticdc_mounter_total_rows_count{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, changefeed)
  puller_events: sum(rate(ticdc_puller_txn_collect_event_count{tidb_cluster_id="{cluster_id}", type!="resolved"}[1m])) by (changefeed, instance, type)
  sorter_events: sum(rate(ticdc_sorter_output_event_count{tidb_cluster_id="{cluster_id}"}[1m])) by (changefeed, instance, type)

Judgment:
  puller_events normal but sink_rows much lower than puller → Downstream write bottleneck → 4b
  puller_events itself low → Low upstream data volume or upstream issue → Step 3
  mounter_rows normal but sink_rows low → Sink blocked → 4b
```

**4b: Downstream Connectivity and Performance**
```
Branch by downstream type:

MySQL downstream:
  → Suggest user action: Check if downstream MySQL connection is normal, check for lock waits
  → Suggest user action: Check downstream MySQL slow queries, check for DDL blocking
  → Common causes: Unique index conflict on downstream table / High downstream load causing slow writes

Kafka downstream:
  → Suggest user action: Check if Kafka broker is healthy, check if partitions are writable
  → Suggest user action: Check if topic partition count is sufficient
  → Common causes: Kafka broker unreachable / Partition leader switching / Message body too large

S3 downstream:
  → Suggest user action: Check S3 bucket permissions and network connectivity
  → Common causes: IAM permission change / Bucket does not exist / Network timeout
```

If loki_available:
```
Search keywords:
  {component="ticdc"} |~ "(?i)sink.*error|sink.*fail|downstream|write.*timeout"
  {component="ticdc"} |~ "(?i)kafka.*error|mysql.*error|s3.*error"
```

### Step 5: TiCDC Self-Check

**5a: TiCDC Resource Status**
```
metrics:
  cdc_cpu: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="ticdc"}[1m])
  cdc_cpu_limit: ticdc_server_go_max_procs{tidb_cluster_id="{cluster_id}", job="ticdc"}
  cdc_mem_rss: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="ticdc"}
  cdc_mem_heap: go_memstats_heap_alloc_bytes{tidb_cluster_id="{cluster_id}", job="ticdc"}
  cdc_goroutines: go_goroutines{tidb_cluster_id="{cluster_id}", job="ticdc"}

Judgment:
  CPU usage approaching limit → TiCDC CPU bottleneck → Suggest user action: Scale out TiCDC nodes
  RSS continuously rising → Possible OOM → 5b
  goroutines abnormally increasing → Possible goroutine leak → 5c
```

**5b: TiCDC OOM Risk**
```
RSS approaching container/node memory limit → P0 OOM risk

Common OOM causes:
  1. Large transactions: A single transaction contains massive row changes → TiCDC needs to cache the entire transaction in memory
  2. old-value cache: Downstream requires old values (e.g., MySQL sink) → Additional memory overhead
  3. sink buffer accumulation: Slow downstream writes → Data pending to be sent accumulates in memory

If loki_available:
  Search keywords:
    {component="ticdc"} |~ "(?i)OOM|out of memory|killed|memory exceed"
    {component="ticdc"} |~ "(?i)large.*txn|transaction.*too.*large"

→ DIAGNOSIS: TiCDC insufficient memory
→ Suggest user action:
  - Split large transactions, avoid writing too many rows in a single transaction
  - Scale up TiCDC memory or add TiCDC nodes
  - Check if old-value can be disabled (only when downstream does not need old values)
```

**5c: TiCDC Error Logs**
```
If loki_available:
  Search keywords:
    {component="ticdc"} |~ "(?i)error|panic|fatal|fail"
    {component="ticdc"} |~ "(?i)owner.*changed|capture.*exit|processor.*exit"
    {component="ticdc"} |~ "(?i)ErrReachMaxTry|ErrChangeFeedRetry|ErrKVClient"

  Typical error patterns:
    "ErrKVClient" → TiCDC communication anomaly with TiKV → Check network
    "owner changed" → TiCDC owner node switch → Brief lag is normal
    "processor exit" → Processor exited abnormally → Check memory/logs
    "ErrReachMaxTry" → Retries exhausted → Check downstream connectivity

→ Locate root cause based on error type
```

---

## Emergency Recovery Steps

> All operations below are marked "Suggest user action"; diagnostic engineers do not execute directly.

### P0: Replication Completely Interrupted (changefeed failed)

1. **Suggest user action**: View changefeed error information
   ```bash
   ticloud changefeed describe --changefeed-id {changefeed_id}
   ```

2. **Suggest user action**: Attempt to resume changefeed
   ```bash
   ticloud changefeed resume --changefeed-id {changefeed_id}
   ```

3. If resume fails, determine based on error information:
   - Downstream unreachable → Suggest user action: Fix downstream connection first, then resume
   - OOM → Suggest user action: Scale up TiCDC then resume
   - GC has advanced past checkpoint → **Data loss risk** → Suggest user action: Recreate changefeed and re-sync from the latest checkpoint

### P1: Replication Lag Continuously Increasing

1. Locate the bottleneck (resolved-ts / sink / TiCDC resources)
2. Execute corresponding recovery based on the bottleneck:
   - Large transaction blocking → Suggest user action: Wait for the transaction to complete or terminate long transactions
   - Slow downstream → Suggest user action: Optimize downstream performance or scale up downstream
   - Insufficient TiCDC resources → Suggest user action: Scale up TiCDC

---

## Data Source Call Templates

### Changefeed Status
```
query: max(ticdc_owner_status{tidb_cluster_id="{cluster_id}"}) by (changefeed)
```

### Changefeed Checkpoint Lag
```
query: max(ticdc_owner_checkpoint_ts_lag{tidb_cluster_id="{cluster_id}"}) by (changefeed)
```

### Changefeed Resolved-TS Lag (Owner)
```
query: max(ticdc_owner_resolved_ts_lag{tidb_cluster_id="{cluster_id}"}) by (changefeed)
```

### Changefeed Resolved-TS Lag (Processor)
```
query: max(ticdc_processor_resolved_ts_lag{tidb_cluster_id="{cluster_id}"}) by (instance, changefeed)
```

### TiKV Resolved-TS Gap
```
query: tikv_resolved_ts_min_resolved_ts_gap_seconds{tidb_cluster_id="{cluster_id}"} by (instance)
```

### GC Safepoint
```
query: tikv_gcworker_autogc_safe_point{tidb_cluster_id="{cluster_id}"}
```

### TiKV Uptime (Detect Restarts)
```
query: time() - process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tikv"}
```

### TiKV Leader Distribution
```
query: tikv_raftstore_leader_count{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiCDC CPU Usage
```
query: rate(process_cpu_seconds_total{tidb_cluster_id="{cluster_id}", job="ticdc"}[1m])
```

### TiCDC Memory RSS
```
query: process_resident_memory_bytes{tidb_cluster_id="{cluster_id}", job="ticdc"} by (instance)
```

### TiCDC Heap Memory
```
query: go_memstats_heap_alloc_bytes{tidb_cluster_id="{cluster_id}", job="ticdc"} by (instance)
```

### TiCDC Goroutines
```
query: go_goroutines{tidb_cluster_id="{cluster_id}", job="ticdc"} by (instance)
```

### Puller Events (Data Pull Rate)
```
query: sum(rate(ticdc_puller_txn_collect_event_count{tidb_cluster_id="{cluster_id}", type!="resolved"}[1m])) by (changefeed, instance, type)
```

### Sorter Output Events
```
query: sum(rate(ticdc_sorter_output_event_count{tidb_cluster_id="{cluster_id}"}[1m])) by (changefeed, instance, type)
```

### Mounter Rows (Data Encoding/Decoding Rate)
```
query: sum(rate(ticdc_mounter_total_rows_count{tidb_cluster_id="{cluster_id}"}[1m])) by (instance, changefeed)
```

### Sink Rows (Downstream Write Rate)
```
query: sum(rate(ticdc_sink_table_sink_total_rows_count{tidb_cluster_id="{cluster_id}"}[1m])) by (changefeed, instance)
```

### Loki Log Search Templates

**TiCDC Error Logs**
```
{component="ticdc", tidb_cluster_id="{cluster_id}"} |~ "(?i)error|panic|fatal|fail"
```

**TiCDC OOM / Memory Related**
```
{component="ticdc", tidb_cluster_id="{cluster_id}"} |~ "(?i)OOM|out of memory|killed|memory exceed|large.*txn"
```

**TiCDC Sink Errors**
```
{component="ticdc", tidb_cluster_id="{cluster_id}"} |~ "(?i)sink.*error|sink.*fail|downstream|write.*timeout"
```

**TiKV Resolved-TS Related**
```
{component="tikv", tidb_cluster_id="{cluster_id}"} |~ "(?i)resolved-ts|advance.*resolve|min_resolved_ts"
```

**GC Safepoint Related**
```
{component="tidb", tidb_cluster_id="{cluster_id}"} |~ "(?i)gc.*safepoint.*blocked|service_gc_safepoint"
```
