# FAULT-DDL-STUCK (F7 DDL Stuck)

> Entry condition: ALTER TABLE / ADD INDEX not completing for a long time, schema change stuck

**Severity level**: P1-P2 (depending on whether it blocks production writes)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. DDL type (ALTER TABLE / ADD INDEX / ADD COLUMN / DROP INDEX, etc.)
3. DDL start time, elapsed duration
4. Target table name and estimated row count

---

## Background

TiDB DDL uses an Online Schema Change algorithm similar to F1. Schema changes go through multiple state transitions (none → delete only → write only → write reorganization → public). Each state transition requires waiting for all TiDB instances' schema lease to expire (default 45s). DDL jobs are executed serially by the unique DDL Owner node in the cluster.

---

## Decision Tree

### Step 1: Confirm DDL Status

**Generate SQL for user to execute (Safety red line: diagnostic SQL to be executed by user)**

```sql
-- View current DDL job status
ADMIN SHOW DDL JOBS;

-- View running DDLs
ADMIN SHOW DDL JOBS WHERE state = 'running' OR state = 'queueing';

-- View DDL detailed status (schema_state column is key)
SELECT * FROM mysql.tidb_ddl_job ORDER BY job_id DESC LIMIT 20;
```

```
Analysis points:
  state column:
    - "running"  → DDL is executing, go to Step 2
    - "queueing" → DDL is queued waiting, check DDLs ahead of it
    - "syncing"  → Waiting for schema to sync to all TiDB instances, go to Step 2
    - "cancelling" / "rollback" → DDL is being cancelled/rolled back
    - "none" + no change for a long time → DDL Owner may be abnormal, go to Step 2

  schema_state column:
    - "delete only" / "write only" → Schema state transition phase, check if stuck for a long time
    - "write reorganization" → ADD INDEX backfill phase, go to Step 4
    - "public" → Should have completed, abnormal situation

  row_count column (ADD INDEX type DDLs):
    - Observe if row_count grows between two queries
    - Not growing → Backfill stuck, go to Step 4
    - Growing slowly → Resource bottleneck, go to Step 5
```

### Step 2: Check DDL Owner

```sql
-- View current DDL Owner
ADMIN SHOW DDL;
```

```
Analysis:
  OWNER_ID column: TiDB instance ID of the current DDL Owner
  Checks:
    - Is the Owner instance healthy and alive
    - Is the Owner switching frequently (Owner switch interrupts DDL execution)
```

```
metrics:
  tidb_up{tidb_cluster_id="{cluster_id}"}:     up{job="tidb", tidb_cluster_id="{cluster_id}"}
  owner_gauge: tidb_ddl_worker_total_count{tidb_cluster_id="{cluster_id}"}

Analysis:
  Instances with up == 0 → TiDB node down
  If the DDL Owner's instance is down → Need to wait for Owner re-election (usually 10-30s)
  Owner election depends on PD (etcd); if PD is unavailable, Owner election fails → Go to Step 2b
```

#### Step 2b: PD Connectivity Check

```
metrics:
  pd_tso_wait{tidb_cluster_id="{cluster_id}"}:  histogram_quantile(0.99, sum(rate(tidb_tikvclient_ts_future_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  pd_tso_rpc{tidb_cluster_id="{cluster_id}"}:   histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{type="tso", tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  pd_leader{tidb_cluster_id="{cluster_id}"}:    pd_server_is_leader{tidb_cluster_id="{cluster_id}"}

Analysis:
  pd_tso_wait_p99{tidb_cluster_id="{cluster_id}"} > 100ms → PD responding slowly, DDL state transitions depend on TSO
  pd_leader{tidb_cluster_id="{cluster_id}"} has no leader → PD election issue, DDL Owner election will also be blocked
  → DIAGNOSIS: Prioritize restoring PD availability
```

### Step 3: Check Blocking Transactions

DDL schema state transitions need to wait for all running transactions on all TiDB instances to perceive the new schema version. Long transactions block state transitions.

**Generate SQL for user to execute:**

```sql
-- View long transactions (may block schema state transitions)
SELECT * FROM information_schema.CLUSTER_TIDB_TRX
WHERE STATE = 'Idle' AND CURRENT_SQL_DIGEST IS NOT NULL
ORDER BY TRX_CREATED_TIMESTAMP ASC
LIMIT 20;

-- View duration of all active transactions
SELECT
  INSTANCE,
  ID AS TRX_ID,
  STATE,
  CURRENT_SQL_DIGEST,
  TIMESTAMPDIFF(SECOND, TRX_CREATED_TIMESTAMP, NOW()) AS duration_sec
FROM information_schema.CLUSTER_TIDB_TRX
WHERE TIMESTAMPDIFF(SECOND, TRX_CREATED_TIMESTAMP, NOW()) > 60
ORDER BY duration_sec DESC
LIMIT 20;
```

```
Analysis:
  Transactions with duration_sec > schema_lease (default 45s):
    - May block DDL schema state transitions
    - Pay special attention to long transactions that existed before the DDL started

  → DIAGNOSIS:
    - Confirm if long transactions can be safely KILLed
    - Suggest user action: KILL <connection_id> (requires user confirmation before execution)
    - If application-side transaction not committed → Suggest application-side check connection pool
```

### Step 4: ADD INDEX Special Checks

#### Step 4a: fast_reorg and dist_task Status

**Generate SQL for user to execute:**

```sql
-- Check fast_reorg configuration
SELECT @@global.tidb_ddl_enable_fast_reorg;

-- Check dist_task configuration
SELECT @@global.tidb_enable_dist_task;
```

```
Known issue: fast_reorg=ON + dist_task=OFF combination
  Symptom: TiKV panic, log shows "assertion failed: self.0 > 0" (start_ts=0)
  Cause: When fast_reorg is enabled but distributed task is disabled, certain code paths pass start_ts=0

  → DIAGNOSIS (emergency workaround — ORDER MATTERS, see field-corrections.md #3):
    SET GLOBAL tidb_enable_dist_task = OFF;          -- MUST disable dist_task FIRST
    SET GLOBAL tidb_ddl_enable_fast_reorg = OFF;     -- THEN disable fast_reorg
    -- If order is reversed, DDL operations will hang indefinitely
    ADMIN CANCEL DDL JOBS <job_id>;
    -- Re-execute the DDL statement
```

#### Step 4b: Backfill Progress Check

**Generate SQL for user to execute:**

```sql
-- View ADD INDEX backfill progress
ADMIN SHOW DDL JOBS WHERE job_type LIKE '%add index%';

-- Observe row_count changes (execute twice, 30s apart)
SELECT JOB_ID, DB_NAME, TABLE_NAME, JOB_TYPE, SCHEMA_STATE, ROW_COUNT, STATE
FROM mysql.tidb_ddl_job
WHERE JOB_TYPE LIKE '%add index%' AND STATE = 'running';
```

```
Analysis:
  row_count not growing (no change between two queries):
    - fast_reorg issue → Step 4a
    - TiKV under too much pressure → Step 5
    - Target table has many delete markers (tombstone) → Compaction blocking backfill

  row_count growing slowly:
    - Very large number of table rows → Normal but slow, estimate remaining time
    - TiKV I/O occupied by other workloads → Step 5
```

#### Step 4c: Distributed Task Status (when dist_task=ON)

**Generate SQL for user to execute:**

```sql
-- View distributed DDL subtask status
SELECT * FROM mysql.tidb_ddl_reorg WHERE job_id = <job_id>;

-- View dist framework task status (TiDB >= v7.1)
SELECT * FROM mysql.tidb_global_task ORDER BY id DESC LIMIT 10;
SELECT * FROM mysql.tidb_global_task_history ORDER BY id DESC LIMIT 10;
```

### Step 5: Resource Bottleneck Check

#### Step 5a: TiKV CPU / I/O

```
metrics:
  tikv_cpu{tidb_cluster_id="{cluster_id}"}:       rate(process_cpu_seconds_total{job="tikv", tidb_cluster_id="{cluster_id}"}[1m])
  tikv_io_util{tidb_cluster_id="{cluster_id}"}:   rate(tikv_engine_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])
  tikv_write_stall{tidb_cluster_id="{cluster_id}"}: tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}
  tikv_pending_compaction{tidb_cluster_id="{cluster_id}"}: tikv_engine_pending_compaction_bytes{tidb_cluster_id="{cluster_id}"}

Analysis:
  tikv_cpu{tidb_cluster_id="{cluster_id}"} > 80% → CPU is the ADD INDEX backfill bottleneck
  write_stall > 0 → RocksDB write stall, backfill writes are blocked
  pending_compaction continuously growing → Compaction cannot keep up with backfill write speed
```

#### Step 5b: Coprocessor Contention (ANALYZE Concurrency)

```
metrics:
  cop_running:  sum(tikv_coprocessor_request_duration_seconds_count{tidb_cluster_id="{cluster_id}"})
  cop_wait_p99: histogram_quantile(0.99, sum(rate(tikv_coprocessor_request_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))

Analysis:
  cop_wait_p99 > 1s → Coprocessor task queuing is severe
  If ANALYZE is running concurrently → ANALYZE's full table scan consumes significant Coprocessor resources

  → DIAGNOSIS:
    - Pause ANALYZE: KILL <analyze_process_id>
    - Or reduce concurrency: SET GLOBAL tidb_build_stats_concurrency = 1;
    - Avoid running ANALYZE during DDL backfill
```

#### Step 5c: DDL Concurrency Tuning

**Generate SQL for user to execute:**

```sql
-- View DDL backfill concurrency and batch size
SELECT @@global.tidb_ddl_reorg_worker_cnt;
SELECT @@global.tidb_ddl_reorg_batch_size;
```

```
Analysis:
  tidb_ddl_reorg_worker_cnt (default 4):
    - If TiKV CPU/IO has headroom → Can increase to speed up backfill
    - If TiKV is already fully loaded → Decrease to avoid impacting online workload

  tidb_ddl_reorg_batch_size (default 256):
    - Too large: Single backfill transaction too large, may trigger TiKV raft limits
    - Too small: Backfill speed is slow

  → DIAGNOSIS (tuning suggestions, for user to execute):
    -- Speed up (when TiKV resources are sufficient):
    SET GLOBAL tidb_ddl_reorg_worker_cnt = 8;
    SET GLOBAL tidb_ddl_reorg_batch_size = 512;

    -- Slow down (to avoid impacting online workload):
    SET GLOBAL tidb_ddl_reorg_worker_cnt = 2;
    SET GLOBAL tidb_ddl_reorg_batch_size = 128;
```

---

## Emergency Operation Guide

### Cancel Stuck DDL

**Generate SQL for user to execute (requires user confirmation before operating):**

```sql
-- Cancel specified DDL job
ADMIN CANCEL DDL JOBS <job_id>;

-- Confirm cancellation succeeded
ADMIN SHOW DDL JOBS WHERE job_id = <job_id>;
```

Note: After CANCEL, the DDL will roll back completed work. ADD INDEX needs to be re-executed after cancellation.

---

## Data Source Call Templates

### TiDB Instance Alive Status
```
query: up{job="tidb", tidb_cluster_id="{cluster_id}"}
```

### PD TSO Wait P99
```
query: histogram_quantile(0.99, sum(rate(tidb_tikvclient_ts_future_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### PD TSO RPC Duration P99
```
query: histogram_quantile(0.99, sum(rate(pd_client_request_handle_requests_duration_seconds_bucket{type="tso", tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### PD Leader Status
```
query: pd_server_is_leader{tidb_cluster_id="{cluster_id}"}
```

### TiKV CPU Usage
```
query: rate(process_cpu_seconds_total{job="tikv", tidb_cluster_id="{cluster_id}"}[1m])
```

### TiKV Write Stall
```
query: tikv_engine_write_stall{tidb_cluster_id="{cluster_id}"}
```

### TiKV Pending Compaction Bytes
```
query: tikv_engine_pending_compaction_bytes{tidb_cluster_id="{cluster_id}"}
```

### Coprocessor Wait Duration P99
```
query: histogram_quantile(0.99, sum(rate(tikv_coprocessor_request_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))
```

### TiKV Engine Flow (I/O Throughput)
```
query: sum(rate(tikv_engine_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])) by (type, instance)
```

### DDL Related Logs (Loki)
```logql
{component="tidb"} |= "ddl" |= "error"
{component="tidb"} |= "DDL" |= "job" |= "running"
{component="tikv"} |= "assertion failed" |= "self.0"
```
