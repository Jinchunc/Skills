# PATH-LATENCY-JITTER (S1.4 Intermittent Latency Jitter)

> Entry condition: Latency is not persistently high, but fluctuates periodically or randomly, e.g., "latency goes up and down, spikes every few minutes"

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range [start, end]

---

## Decision Tree

### Step 1: Confirm Jitter Pattern

```
metrics:
  p99:  histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))   step=15s
  p999: histogram_quantile(0.999, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le)) step=15s

analysis:
  - p99 time series coefficient of variation (CV > 30% → significant jitter)
  - p999/p99 ratio time series: ratio itself is fluctuating = tail varies in size
  - periodic (fixed interval) vs random
```

### Step 2: Periodic Jitter

> Trigger: Step 1 identified fixed-interval jitter

Check common periodic causes in parallel:

| Check Item | Metric | Criteria |
|--------|--------|------|
| Compaction | `tikv_engine_compaction_flow_bytes{tidb_cluster_id="{cluster_id}"}` | compaction peaks align with latency peaks |
| GC | `tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}"}` | GC execution aligns with latency peaks |
| PD scheduling | `pd_schedule_operators_count{tidb_cluster_id="{cluster_id}"}` | Region migration aligns with latency peaks |
| Statistics collection | `tidb_statistics_auto_analyze_total{tidb_cluster_id="{cluster_id}"}` | auto analyze aligns with latency peaks |

Match a specific cycle → DIAGNOSIS (note the specific periodic cause) → END

### Step 3: Random Jitter

→ [MODULE-TIKV](../modules/tikv-fast-tune.md) PRE_INFRA_CHECK
  - CPU throttle? → Container-level CPU limit causing intermittent stalls
  - Memory pressure? → GC/swap causing intermittent slowness
  - Disk jitter? → IO latency intermittently spikes

→ Inter-instance balance check: whether a specific instance is intermittently slow (instance-level p99 time series)

→ Network check:
  - gRPC reconnection frequency: `tikv_grpc_connections{tidb_cluster_id="{cluster_id}"}` changes
  - PD leader switch: `pd_tso_events{tidb_cluster_id="{cluster_id}", type="save"}`

→ DIAGNOSIS → END

---

## Data Source Call Templates

### P99 High-Precision Time Series (step=15s)
```
query: histogram_quantile(0.99, sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[1m])) by (le))
step: 15
```

### Compaction Traffic
```
query: sum(rate(tikv_engine_compaction_flow_bytes{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### GC Keys
```
query: sum(rate(tikv_gcworker_gc_keys{tidb_cluster_id="{cluster_id}"}[2m]))
```

---

## Remediation References

- Stats health and auto-analyze scheduling: [../references/stats-management.md](../references/stats-management.md)
- TiKV troubleshooting (compaction, GC): [../../knowledge/troubleshooting-guide.md](../../knowledge/troubleshooting-guide.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
