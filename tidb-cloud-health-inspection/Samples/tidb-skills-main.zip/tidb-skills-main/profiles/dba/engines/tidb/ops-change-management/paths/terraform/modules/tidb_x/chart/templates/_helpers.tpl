{{/*
Helper templates for the tidb-x-cluster chart.

Each component's spec content is rendered at zero indentation inside a
{{- define "..." -}} block. The caller uses `| nindent N` to place the
content at the correct indentation level inside the parent resource.

Design contract for config / extra_spec helpers:
  - `config`     → raw TOML string; rendered as a `config: |` block scalar
                   with 2 extra spaces of indentation inside the helper so
                   that after `nindent 6` it lands at 8-space indentation.
  - `extra_spec` → raw YAML string; injected directly alongside other spec
                   fields. The caller must provide the surrounding context.
*/}}

{{/*
tidb-x-cluster.componentSpec
Generic spec block for components that have storage volumes.
Arguments (passed as a dict via `include`):
  .image      - image repository (without tag)
  .version    - resolved image tag
  .config     - raw TOML config string (may be empty)
  .extra_spec - raw YAML spec overlay (may be empty)
  .storage    - PVC size string
  .mode       - optional mode string (e.g. "ms" for PD microservices)
*/}}
{{- define "tidb-x-cluster.componentSpec" -}}
version: {{ .version }}
image: "{{ .image }}:{{ .version }}"
{{- if .mode }}
mode: {{ .mode | quote }}
{{- end }}
{{- if .extra_spec }}
{{ .extra_spec | trimSuffix "\n" }}
{{- end }}
volumes:
  - name: data
    mounts:
      - type: data
    storage: {{ .storage }}
{{- if .config }}
config: |
{{ .config | trimSuffix "\n" | indent 2 }}
{{- end }}
{{- end }}

{{/*
tidb-x-cluster.componentSpecNoStorage
Spec block for components that do not use persistent volumes (TiDB, TiProxy,
TSOGroup, SchedulingGroup).
*/}}
{{- define "tidb-x-cluster.componentSpecNoStorage" -}}
version: {{ .version }}
image: "{{ .image }}:{{ .version }}"
{{- if .config }}
config: |
{{ .config | trimSuffix "\n" | indent 2 }}
{{- end }}
{{- end }}
