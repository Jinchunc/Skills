# Domain 4: 备份恢复 (Backup & Recovery)

> Status: **Gap**
> Tier: A (Engine-agnostic)

## Core

备份策略评估与容灾验证。保障业务连续性。

## Scenarios

- 评估备份策略有效性与执行成功率
- RPO/RTO 验证
- PITR 覆盖范围检查
- 跨区域副本状态检查
- 恢复演练记录与评估
- 集群高可用配置和容灾能力检查

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | — | Not yet built |
| MySQL | — | Not yet built |
| PostgreSQL | — | Not yet built |
| MongoDB | — | Not yet built |

## Key Checks (to build)

- 备份成功率
- RPO/RTO 是否满足 SLA
- PITR 覆盖范围（时间窗口）
- 跨区域副本状态与延迟
- 最近一次恢复演练时间与结果

## Routing Note

- 备份策略评估与恢复验证 → 本域
- 备份策略参数变更执行 → 域5 (ops-change-management)
