#!/bin/bash

log() {
  printf '[%s] %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" >&2
}

die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

need_cmd() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1 || die "missing required command: $cmd"
}

require_env() {
  local missing=()
  local name
  for name in "$@"; do
    if [ -z "${!name:-}" ]; then
      missing+=("$name")
    fi
  done
  if [ "${#missing[@]}" -gt 0 ]; then
    die "missing required environment variables: ${missing[*]}"
  fi
}

timeout_cmd() {
  if command -v timeout >/dev/null 2>&1; then
    printf 'timeout\n'
    return 0
  fi
  if command -v gtimeout >/dev/null 2>&1; then
    printf 'gtimeout\n'
    return 0
  fi
  return 1
}

run_step_log_file() {
  local name="$1"
  local log_dir="${RUN_LOG_DIR:-./run-logs}"
  local safe_name
  local timestamp

  mkdir -p "$log_dir"
  safe_name="$(printf '%s' "$name" | tr -cs '[:alnum:]_.-' '_' | sed 's/^_//; s/_$//')"
  if [ -z "$safe_name" ]; then
    safe_name="step"
  fi
  timestamp="$(date -u '+%Y%m%dT%H%M%SZ')"
  printf '%s/%s_%s.log\n' "$log_dir" "$timestamp" "$safe_name"
}

run_step_diagnostics() {
  local name="$1"
  local status="$2"
  local log_file="$3"

  log "===== ${name} failed status=${status}; log=${log_file} ====="
  case "$status" in
    124|137|143)
      log "step likely timed out or was killed; watchdog kill-after=${RUN_STEP_KILL_AFTER:-30s}"
      ;;
  esac

  if [ -n "${RUN_STEP_DIAGNOSTIC_CMD:-}" ]; then
    log "===== ${name} diagnostics ====="
    bash -lc "$RUN_STEP_DIAGNOSTIC_CMD" 2>&1 | tee -a "$log_file" || true
  fi
}

run_step() {
  local name="$1"
  local timeout_seconds="$2"
  shift 2

  local cmd
  local log_file
  local status
  local had_errexit=0

  cmd="$(timeout_cmd)" || die "install GNU timeout/coreutils before running long steps"
  log_file="$(run_step_log_file "$name")"
  log "===== ${name} timeout=${timeout_seconds}s log=${log_file} ====="

  case "$-" in
    *e*)
      had_errexit=1
      set +e
      ;;
  esac

  "$cmd" --kill-after="${RUN_STEP_KILL_AFTER:-30s}" --preserve-status "$timeout_seconds" "$@" \
    2>&1 | tee -a "$log_file"
  status=${PIPESTATUS[0]}

  if [ "$had_errexit" -eq 1 ]; then
    set -e
  fi

  if [ "$status" -ne 0 ]; then
    run_step_diagnostics "$name" "$status" "$log_file"
    return "$status"
  fi

  log "===== ${name} completed log=${log_file} ====="
}

write_state() {
  local state_file="$1"
  local key="$2"
  local value="$3"
  local tmp_file

  mkdir -p "$(dirname "$state_file")"
  tmp_file="${state_file}.tmp"
  if [ -f "$state_file" ]; then
    grep -v "^${key}=" "$state_file" > "$tmp_file" || true
  else
    : > "$tmp_file"
  fi
  printf '%s=%q\n' "$key" "$value" >> "$tmp_file"
  mv "$tmp_file" "$state_file"
}

load_state_file() {
  local state_file="$1"
  if [ -f "$state_file" ]; then
    # shellcheck disable=SC1090
    . "$state_file"
  fi
}

export -f log
export -f die
export -f need_cmd
export -f require_env
export -f timeout_cmd
export -f run_step_log_file
export -f run_step_diagnostics
export -f run_step
export -f write_state
export -f load_state_file
