variable "cluster_name" {
  type        = string
  description = "EKS cluster name."
}

variable "cluster_version" {
  type        = string
  description = "Kubernetes version."
}

variable "vpc_id" {
  type        = string
  description = "VPC ID."
}

variable "private_subnet_ids" {
  type        = list(string)
  description = "Private subnet IDs for EKS."
}

variable "eks_managed_node_groups" {
  type        = map(any)
  description = "EKS managed node groups configuration."
  default     = {}
}

variable "tags" {
  type        = map(string)
  description = "Common tags."
  default     = {}
}
