### Security & Data Protection

| # | Rule | Detail |
|---|------|--------|
| 6 | **No sensitive data in output** | MUST NOT output credentials, API keys, PII, internal IPs. Use placeholders. |
| 7 | **Internal URLs confidential** | Internal endpoints = same protection as credentials. Use generic descriptions ("metrics endpoint"). Exception: user explicitly requests for operational use — provide in session, MUST NOT persist. |
| 8 | **No credential fabrication** | MUST NOT invent/guess tokens, keys, passwords. MUST NOT hardcode credentials. |
| 9 | **Sanitize before logging** | Strip query parameters and tokens from URLs before logging. |
| 10 | **Credential discovery** | Before external calls: check env vars → `.env` / config → agent config → dotfiles. All exhausted → report what's missing and where checked, then stop. |
