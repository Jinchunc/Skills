# TiDB Cloud Essential

> Essential tier of TiDB X — keyspace-isolated logical clusters running on shared physical resource pools. Designed for production workloads with moderate scale and quota-based resource control.
>
> **Start here for architecture:** [tidb-x.md](tidb-x.md) covers the shared two-layer model (logical cluster vs physical pool) that Essential shares with Premium and Starter.

---

## What Essential Is

- **Logical cluster = keyspace**: each Essential cluster ID (`10...`) is a keyspace inside a shared physical pool (`20...`).
- **Shared infrastructure**: TiKV/PD nodes are shared with other Essential clusters and possibly other tenants.
- **Quota-based**: IOPS and RCU limits apply; exceeding them causes throttling, not automatic elastic scaling.
- **Observability gaps**: some metrics may 500, logs are pool-level, and slow queries must be filtered by keyspace.

---

## Resource & Quota Characteristics

| Resource | Typical Limit / Behavior | Diagnostic Impact |
|----------|--------------------------|-------------------|
| IOPS | Typically **500 IOPS** per disk/tier | QPS ceiling often caused by IOPS exhaustion, not CPU |
| RCU | Request Capacity Unit metering; provisioned vs limit | RCU cap → throttling → QPS plateau + RC queue wait |
| Storage | Shared physical disk; per-cluster allocation metric | Do NOT sum raw TiKV disk bytes across clusters |
| TiKV/PD | Shared across pool | TiKV gRPC metrics include amplification and other tenants |

---

## Cluster Enumeration

Same as TiDB X common model:

1. Use Clinic API `/clinic/api/v1/dashboard/clusters`
2. Keep `deployType=essential` AND `active=true` (ID pattern `10...`)
3. Exclude `deployType=nextgen-host` physical pools (ID pattern `20...`)
4. Record `parentID` for resource-pool mapping

See [tidb-x.md](tidb-x.md) § Cluster Enumeration for full details.

---

## Metrics Strategy

| What you need | Recommended source | Why |
|---------------|-------------------|-----|
| Business QPS / latency | SQL-layer metrics: `tidb_server_query_total`, `tidb_server_handle_query_duration_seconds_*` | TiKV metrics are pool-level aggregates |
| RCU utilization / throttling | `serverless_metering_rcu_provisioned_capacity` / `resource_manager_resource_unit_service_limit` via `keyspace_id` | RCU is keyspace-scoped |
| IOPS saturation | Disk metrics from Clinic DataPlane or O11Y infra UUID | IOPS quota is a common Essential bottleneck |
| Storage growth | Per-cluster allocation metrics | Raw TiKV store size is multi-tenant |

**Note:** Some Essential metrics may return HTTP 500. Fail-open: mark `N/A`, continue the inspection, and fall back to slow-query or Loki evidence when possible.

---

## Log & Slow Query Access

- **Loki is the primary log source**: `{namespace="tidb-pool", container="tidb", cluster="<pool-name>"} |= "keyspaceID=<id>"`
- **Slow queries**: S3 raw files or Loki `container="slowlog"` with keyspace content filter
- **No aggregated log-stats SQLite**, no TopSQL, no continuous profiles

See [o11y-data.md](../../../providers/tidb-cloud/o11y/o11y-data.md) § Deploy Type: Starter / Essential for full access paths.

---

## Common Essential-Specific Issues

| Symptom | Root Cause Clue | Recommendation |
|---------|-----------------|----------------|
| TiProxy gateway bottleneck | TiProxy CPU high, latency grows before TiKV saturates | Horizontally scale TiProxy nodes |
| Raftlog disk IOPS insufficient | Disk IOPS hitting ~500 ceiling | Increase raftlog disk IOPS or add TiKV nodes |
| Small/empty table hotspot | gRPC requests concentrate on one TiKV, flow-control triggered | Pre-populate data, ensure leader distribution across nodes |
| RCU throttling | `provisioned >= limit` and QPS flatlines | Scale provisioned RCU or reduce per-statement RU consumption |
| RC queue wait | `time_queued_by_rc` > 0 in slowlog | Confirms active throttling |

---

## RCU Check

For Essential, RCU checks require the `keyspace_id` (not `cluster_id`):

```
provisioned: sum(serverless_metering_rcu_provisioned_capacity{keyspace_id="{keyspace_id}"})
limit:       resource_manager_resource_unit_service_limit{namespace="tidb-serverless", name="{keyspace_id}"}
```

See [rcu-check.md](../rcu-check.md) § Branch A for the full Starter/Essential RCU throttling decision tree.

---

## Related References

- [tidb-x.md](tidb-x.md) — TiDB X common architecture and enumeration
- [starter.md](starter.md) — smaller serverless tier, similar shared-pool model
- [premium.md](premium.md) — larger TiDB X tier with autoscaling and resource pools
- [dedicated.md](dedicated.md) — single-tenant Gardener shoots
- [rcu-check.md](../rcu-check.md) — RCU throttling check
- [o11y-data.md](../../../providers/tidb-cloud/o11y/o11y-data.md) — observability data access by deploy type
