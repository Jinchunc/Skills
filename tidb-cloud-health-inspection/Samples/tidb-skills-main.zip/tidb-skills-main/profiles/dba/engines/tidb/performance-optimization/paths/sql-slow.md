# PATH-SQL-SLOW (S1.2 Single SQL Becomes Slow)

> Entry condition: User specified a particular SQL or digest, e.g., "This SELECT used to take 50ms, now it takes 5s"

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. SQL text or digest provided by the user
3. Time range [start, end]

---

## Decision Tree

### Step 1: Retrieve Slow Query Records and Execution Plan

→ [MODULE-SQL](../modules/sql-diagnosis.md) (SQL_IDENTIFY + SQL_PLAN_ANALYSIS)

Output: target_digest, execution plan, statistics summary

### Step 2: Execution Plan Root Cause Analysis

→ [MODULE-SQL](../modules/sql-diagnosis.md) (SQL_ROOT_CAUSE decision tree)

| Node | Condition | Root Cause | Confidence |
|------|-----------|------------|------------|
| 1 | actRows vs estRows > 10x | Stale statistics | HIGH |
| 2 | TableFullScan + process_keys > 10K | Missing index | HIGH |
| 3 | cop_proc_avg > 100ms | Coprocessor bottleneck | MEDIUM |
| 4 | backoff contains txnLock | Lock contention | HIGH |
| 5 | mem_max > 1GB | Large query memory overflow | MEDIUM |
| 6 | total_keys/process_keys > 10x | MVCC accumulation | MEDIUM |
| 7 | Implicit type conversion | Index invalidation | LOW |

Hit → DIAGNOSIS → load remediation reference from [MODULE-SQL Remediation table](../modules/sql-diagnosis.md#remediation--tuning-references) → apply fix → verify → END
None hit → Step 3

### Step 3: Check Infrastructure

→ [MODULE-DBTIME](../modules/db-time.md) (Check if there is an overall issue)

| Result | Action |
|--------|--------|
| Overall also slow | SQL is part of an overall issue → Route by component (MODULE-TIKV/TIDB/PD) |
| Overall normal | Issue is limited to this SQL → Suggest user run EXPLAIN ANALYZE and share results + consider SQL Binding |

---

## Data Source Call Templates

### Slow Query by Specific Digest
```sql
SELECT digest, digest_text, COUNT(*) AS cnt, MAX(query_time) AS max_qt,
       MAX(mem_max) AS max_mem, MAX(total_keys) AS max_keys
FROM slow_query_logs
WHERE digest = '{digest}' AND time BETWEEN '{start}' AND '{end}'
GROUP BY digest, digest_text
```

### Execution Plan Details
```sql
SELECT time, query_time, decoded_plan, total_keys, process_keys,
       mem_max, disk_max, backoff_types, cop_proc_avg, cop_wait_avg
FROM slow_query_logs
WHERE digest = '{digest}' AND time BETWEEN '{start}' AND '{end}'
ORDER BY query_time DESC LIMIT 5
```
