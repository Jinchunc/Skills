variable "name" {
  type        = string
  description = "Prefix for endpoint resource names."
}

variable "vpc_id" {
  type        = string
  description = "VPC ID."
}

variable "aws_region" {
  type        = string
  description = "AWS region for service names."
}

variable "interface_subnet_ids" {
  type        = list(string)
  description = "Subnets that host interface endpoints. Use only the AZs where workloads actually run to avoid idle per-AZ endpoint charges."
}

variable "private_route_table_ids" {
  type        = list(string)
  description = "Route tables to attach the S3 gateway endpoint."
}

variable "allowed_security_group_ids" {
  type        = list(string)
  description = "Security groups allowed to reach interface endpoints on 443 (e.g. EKS node and cluster SGs)."
}

variable "interface_services" {
  type        = list(string)
  description = "AWS service suffixes to provision as interface endpoints. Keep this lean and add endpoints only when workloads actually use them."
  default = [
    "ecr.api",
    "ecr.dkr",
    "sts",
    "ec2",
  ]
}

variable "tags" {
  type        = map(string)
  description = "Common tags."
  default     = {}
}
