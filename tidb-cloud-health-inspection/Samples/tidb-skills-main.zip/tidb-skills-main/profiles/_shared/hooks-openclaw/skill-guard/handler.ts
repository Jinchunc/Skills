// Skill-Guard Hook — defense-in-depth protection for skill content
//
// Even if prompt-layer protection (SOUL.md) is bypassed via prompt injection,
// this hook detects skill content in outbound messages and replaces it with
// a refusal notice.
//
// Detection layers:
//   1. SKILL.md frontmatter (YAML with skill-specific metadata fields)
//   2. <CONFIDENTIAL> markers and known warning text
//   3. Structural fingerprints (multiple skill-specific section headers)

import { appendFile, writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';

const AUDIT_DIR = process.env.AUDIT_DIR || '/data/audit';

const REFUSAL =
  '[SKILL-GUARD] This content is protected and cannot be shared. ' +
  'I can describe what a skill does in general terms, but I cannot output its internal instructions.';

// --- Detection Layer 1: SKILL.md Frontmatter ---
// Matches YAML frontmatter containing skill metadata fields.
// Requires `name:` plus at least one other skill-specific field.
const FRONTMATTER_RE =
  /---\s*\n(?=[\s\S]*?^name:\s*.+$)(?=[\s\S]*?^(?:description|category|discipline|version|scope|clearance|auto-trigger|user-invocable):\s*.+$)[\s\S]*?---/m;

// --- Detection Layer 2: CONFIDENTIAL Markers ---
const CONFIDENTIAL_PATTERNS = [
  /<\/?CONFIDENTIAL>/i,
  /STOP\s*[-—]\s*This file is proprietary/i,
  /SKILL-PROTECTION/i,
];

// --- Detection Layer 3: Structural Fingerprints ---
// Skill files use distinctive section headers. If 3+ appear in one message,
// it's almost certainly skill content being leaked.
const SKILL_HEADERS = [
  /^#{1,3}\s+When to (?:Trigger|Use)/m,
  /^#{1,3}\s+Anti-Patterns?/m,
  /^#{1,3}\s+Terminal State/m,
  /^#{1,3}\s+Boundary/m,
  /^#{1,3}\s+Security Red Lines?/m,
  /^#{1,3}\s+Fail-Open Rules?/m,
  /^#{1,3}\s+Performance Constraints?/m,
  /^#{1,3}\s+Routing/m,
  /^#{1,3}\s+Pre-Flight Check/m,
  /^#{1,3}\s+Filesystem Convention/m,
  /^#{1,3}\s+Implementation/m,
  /^#{1,3}\s+Audit Requirements?/m,
];
const SKILL_HEADER_THRESHOLD = 3;

interface DetectionResult {
  blocked: boolean;
  triggers: string[];
}

function detectSkillContent(text: string): DetectionResult {
  const triggers: string[] = [];

  // Layer 1: frontmatter
  if (FRONTMATTER_RE.test(text)) {
    triggers.push('frontmatter');
  }

  // Layer 2: CONFIDENTIAL markers
  for (const pattern of CONFIDENTIAL_PATTERNS) {
    if (pattern.test(text)) {
      triggers.push('confidential_marker');
      break;
    }
  }

  // Layer 3: structural fingerprints
  let headerCount = 0;
  for (const header of SKILL_HEADERS) {
    if (header.test(text)) {
      headerCount++;
    }
  }
  if (headerCount >= SKILL_HEADER_THRESHOLD) {
    triggers.push(`skill_headers(${headerCount})`);
  }

  return {
    blocked: triggers.length > 0,
    triggers,
  };
}

async function ensureDir(dir: string): Promise<void> {
  if (!existsSync(dir)) {
    await mkdir(dir, { recursive: true });
  }
}

async function logBlock(
  triggers: string[],
  preview: string,
): Promise<void> {
  const entry =
    JSON.stringify({
      ts: new Date().toISOString(),
      event: 'skill_content_blocked',
      triggers,
      preview: preview.substring(0, 200).replace(/\n/g, '\\n'),
    }) + '\n';

  const today = new Date().toISOString().split('T')[0];
  const filePath = join(AUDIT_DIR, `audit-${today}.jsonl`);

  try {
    await ensureDir(AUDIT_DIR);
    if (existsSync(filePath)) {
      await appendFile(filePath, entry, 'utf-8');
    } else {
      await writeFile(filePath, entry, 'utf-8');
    }
  } catch {
    // Audit failure must not block the guard itself
    console.error('[skill-guard] Failed to write audit log');
  }
}

export default {
  name: 'skill-guard',
  version: '1.0.0',

  hooks: {
    message: async (context: Record<string, unknown>) => {
      if (context.direction === 'out' && context.text) {
        const { blocked, triggers } = detectSkillContent(
          context.text as string,
        );

        if (blocked) {
          console.log(
            `[skill-guard] BLOCKED — triggers: ${triggers.join(', ')}`,
          );
          await logBlock(triggers, context.text as string);
          context.text = REFUSAL;
        }
      }
    },
  },
};
