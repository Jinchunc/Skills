# ── Operator ─────────────────────────────────────────────────────────────────

variable "operator_namespace" {
  type        = string
  description = "Kubernetes namespace for the TiDB Operator deployment."
  default     = "tidb-x-admin"
}

variable "operator_chart_version" {
  type        = string
  description = "tidb-operator Helm chart version (OCI: ghcr.io/pingcap/charts/tidb-operator)."
  default     = "v2.1.0-alpha.15"
}

variable "operator_image" {
  type        = string
  description = "tidb-operator container image repository (without tag)."
  default     = "pingcap/tidb-operator"
}

variable "operator_image_tag" {
  type        = string
  description = "tidb-operator container image tag. Defaults to operator_chart_version when empty."
  default     = ""
}

# ── Cluster identity ──────────────────────────────────────────────────────────

variable "cluster_name" {
  type        = string
  description = "Name of the TiDB cluster (used in CRD metadata and service names)."
  default     = "tidb-x-onebox"
}

variable "cluster_namespace" {
  type        = string
  description = "Kubernetes namespace where the TiDB cluster CRD instances live."
  default     = "tidb-x-cluster"
}

variable "cluster_version" {
  type        = string
  description = "Default component version used when a component does not specify its own."
  default     = "v8.5.4-nextgen.202510.1"
}

# ── S3 storage backend ────────────────────────────────────────────────────────

variable "s3_bucket_name" {
  type        = string
  description = "S3 bucket used by TiKV/TiFlash for object storage."
  default     = "tidb-x-onebox-data"
}

variable "s3_create_bucket" {
  type        = bool
  description = "Whether Terraform should create the S3 bucket. Set false when the bucket is pre-created."
  default     = false
}

variable "s3_service_account" {
  type        = string
  description = "Kubernetes ServiceAccount name annotated with the IRSA role ARN for S3 access."
  default     = "tidb-x-s3"
}

# ── IRSA (IAM Roles for Service Accounts) ────────────────────────────────────

variable "eks_cluster_name" {
  type        = string
  description = "EKS cluster name, used to name the IRSA IAM role."
}

variable "oidc_provider_arn" {
  type        = string
  description = "ARN of the EKS OIDC provider, required to create the IRSA role."
}

variable "aws_region" {
  type        = string
  description = "AWS region, used for S3 bucket creation and endpoint URIs."
}

# ── PD component ─────────────────────────────────────────────────────────────

variable "pd_image" {
  type        = string
  description = "Container image repository for PD (without tag)."
}

variable "pd_version" {
  type        = string
  description = "PD image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "pd_replicas" {
  type        = number
  description = "Number of PD replicas."
  default     = 1
}

variable "pd_storage" {
  type        = string
  description = "PVC storage size for PD data."
  default     = "20Gi"
}

variable "pd_config" {
  type        = string
  description = "Raw TOML configuration passed to PD via the CRD spec.config block."
  default     = ""
}

variable "pd_extra_spec" {
  type        = string
  description = "Raw YAML fragment injected into the PDGroup spec.template.spec (e.g. overlay)."
  default     = ""
}

# ── TiKV component ────────────────────────────────────────────────────────────

variable "tikv_image" {
  type        = string
  description = "Container image repository for TiKV (without tag)."
}

variable "tikv_version" {
  type        = string
  description = "TiKV image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "tikv_replicas" {
  type        = number
  description = "Number of TiKV replicas."
  default     = 1
}

variable "tikv_storage" {
  type        = string
  description = "PVC storage size for TiKV data."
  default     = "100Gi"
}

variable "tikv_config" {
  type        = string
  description = "Raw TOML configuration passed to TiKV via the CRD spec.config block."
  default     = ""
}

variable "tikv_extra_spec" {
  type        = string
  description = "Raw YAML fragment injected into the TiKVGroup spec.template.spec (e.g. S3 env overlay)."
  default     = ""
}

# ── TiDB component ───────────────────────────────────────────────────────────

variable "tidb_image" {
  type        = string
  description = "Container image repository for TiDB (without tag)."
}

variable "tidb_version" {
  type        = string
  description = "TiDB image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "tidb_replicas" {
  type        = number
  description = "Number of TiDB replicas."
  default     = 1
}

variable "tidb_config" {
  type        = string
  description = "Raw TOML configuration passed to TiDB via the CRD spec.config block."
  default     = ""
}

# ── PD TSO microservice ───────────────────────────────────────────────────────
# When enabled, PD runs in microservices mode and delegates TSO to a dedicated
# TSOGroup. Both pd_tso and pd_scheduling must be enabled together.

variable "pd_tso_enabled" {
  type        = bool
  description = "Enable the TSO microservice (TSOGroup). Enables pd mode=ms on PDGroup."
  default     = true
}

variable "pd_tso_image" {
  type        = string
  description = "Container image repository for TSO (usually same as PD image)."
  default     = ""
}

variable "pd_tso_version" {
  type        = string
  description = "TSO image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "pd_tso_replicas" {
  type        = number
  description = "Number of TSOGroup replicas."
  default     = 1
}

# ── PD Scheduling microservice ────────────────────────────────────────────────

variable "pd_scheduling_enabled" {
  type        = bool
  description = "Enable the Scheduling microservice (SchedulingGroup). Enables pd mode=ms on PDGroup."
  default     = true
}

variable "pd_scheduling_image" {
  type        = string
  description = "Container image repository for the Scheduling service (usually same as PD image)."
  default     = ""
}

variable "pd_scheduling_version" {
  type        = string
  description = "Scheduling image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "pd_scheduling_replicas" {
  type        = number
  description = "Number of SchedulingGroup replicas."
  default     = 1
}

# ── TiProxy ──────────────────────────────────────────────────────────────────

variable "tiproxy_enabled" {
  type        = bool
  description = "Enable TiProxy (SQL proxy with session-level connection routing)."
  default     = true
}

variable "tiproxy_image" {
  type        = string
  description = "Container image repository for TiProxy (without tag)."
  default     = ""
}

variable "tiproxy_version" {
  type        = string
  description = "TiProxy image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "tiproxy_replicas" {
  type        = number
  description = "Number of TiProxyGroup replicas."
  default     = 1
}

# ── TiFlash write node ────────────────────────────────────────────────────────
# Disaggregated TiFlash write node — stores write-ahead logs and indexes in S3.

variable "tiflash_write_enabled" {
  type        = bool
  description = "Enable TiFlash write nodes."
  default     = true
}

variable "tiflash_write_image" {
  type        = string
  description = "Container image repository for TiFlash (without tag)."
  default     = ""
}

variable "tiflash_write_version" {
  type        = string
  description = "TiFlash write image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "tiflash_write_replicas" {
  type        = number
  description = "Number of TiFlashGroup write replicas."
  default     = 1
}

variable "tiflash_write_storage" {
  type        = string
  description = "PVC storage size for TiFlash write data."
  default     = "100Gi"
}

variable "tiflash_write_config" {
  type        = string
  description = "Raw TOML configuration for TiFlash write nodes."
  default     = ""
}

variable "tiflash_write_extra_spec" {
  type        = string
  description = "Raw YAML fragment injected into the TiFlashGroup (write) spec.template.spec."
  default     = ""
}

# ── TiFlash compute node ──────────────────────────────────────────────────────
# Disaggregated TiFlash compute node — reads from S3, no local persistent data.

variable "tiflash_compute_enabled" {
  type        = bool
  description = "Enable TiFlash compute nodes."
  default     = true
}

variable "tiflash_compute_image" {
  type        = string
  description = "Container image repository for TiFlash compute (without tag)."
  default     = ""
}

variable "tiflash_compute_version" {
  type        = string
  description = "TiFlash compute image tag / version. Falls back to var.cluster_version when empty."
  default     = ""
}

variable "tiflash_compute_replicas" {
  type        = number
  description = "Number of TiFlashGroup compute replicas."
  default     = 1
}

variable "tiflash_compute_storage" {
  type        = string
  description = "PVC storage size for TiFlash compute local cache."
  default     = "100Gi"
}

variable "tiflash_compute_config" {
  type        = string
  description = "Raw TOML configuration for TiFlash compute nodes."
  default     = ""
}

variable "tiflash_compute_extra_spec" {
  type        = string
  description = "Raw YAML fragment injected into the TiFlashGroup (compute) spec.template.spec."
  default     = ""
}

# ── Common ────────────────────────────────────────────────────────────────────

variable "tags" {
  type        = map(string)
  description = "Tags applied to all AWS resources created by this module."
  default     = {}
}
