# Serverless Changefeed

Base command: `ticloud serverless changefeed`

Manage TiDB Cloud Serverless changefeeds

## Direct Subcommands

- `ticloud serverless changefeed create` - Create a changefeed
- `ticloud serverless changefeed delete` - Delete a changefeed (dangerous)
- `ticloud serverless changefeed describe` - Describe a changefeed
- `ticloud serverless changefeed edit` - Edit a changefeed (sensitive)
- `ticloud serverless changefeed list` - List changefeeds (human-output)
- `ticloud serverless changefeed pause` - Pause a changefeed (sensitive)
- `ticloud serverless changefeed resume` - Resume a paused changefeed (sensitive)
- `ticloud serverless changefeed template` - Show changefeed Kafka, MySQL and Filter JSON templates

## Confirmation Required

- `ticloud serverless changefeed delete`
