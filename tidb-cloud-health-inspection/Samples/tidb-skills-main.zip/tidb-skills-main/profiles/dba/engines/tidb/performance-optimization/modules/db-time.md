# MODULE-DBTIME: DB Time Top-Down Decomposition

> Source: A1 tidb-perf-diagnosis refactored
> Purpose: Decompose overall latency to specific components, identify bottleneck layer

---

## Input
- cluster_id, metrics_endpoint (resolved by provider data API)
- time_range: Problem period [start, end]
- baseline_range: Baseline period (optional, defaults to same time window 24h before the problem period)

## Output
- bottleneck_component: TIDB | TIKV | PD | NONE (return to domain methodology)
- bottleneck_phase: Specific phase (e.g., kv_prewrite, parse, compile, tso_wait, etc.)
- evidence: Metric data supporting the judgment

---

## Decision Tree

```
Step 1: Get DB Time Overview
  metrics:
    query_duration_p99:
      histogram_quantile(0.99,
        sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
    query_duration_p999:
      histogram_quantile(0.999,
        sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  Baseline comparison: query same metrics for baseline_range

Step 1.5: Per-instance Check (rule out single instance anomaly)
  metrics:
    per_instance_p99:
      histogram_quantile(0.99,
        sum(rate(tidb_server_handle_query_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, instance))
  Analysis: If a single instance P99 is much higher than other instances (> 2x median) -> Problem is limited to that instance
    YES -> Record HOT_INSTANCE, subsequent Step 2 metrics add instance="{hot_instance}" filter, focus on single instance analysis
    NO -> Global issue, continue Step 2 with full instance aggregation

Step 2: Decompose Query Duration Phases
  metrics:
    query_duration_total:
      sum(rate(tidb_server_handle_query_duration_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
    parse:
      sum(rate(tidb_session_parse_duration_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
    compile:
      sum(rate(tidb_session_compile_duration_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
    execute:
      sum(rate(tidb_session_execute_duration_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
    tso_wait:
      sum(rate(tidb_tikvclient_ts_future_wait_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
    kv_request:
      sum(rate(tidb_tikvclient_request_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
    backoff:
      sum(rate(tidb_tikvclient_backoff_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
  Derived: phase_ratio = phase_value / query_duration_total (per phase)

Step 3: Route by Phase

  parse/compile ratio > 20%:
    -> bottleneck = TIDB
    -> bottleneck_phase = "parse/compile overhead"
    -> Possible causes: Plan Cache miss, high SQL complexity

  tso_wait ratio > 20% or absolute value > 5ms:
    -> bottleneck = PD
    -> bottleneck_phase = "tso_wait"
    -> Possible causes: PD leader high load, network latency, cross-Region

  kv_request ratio > 50%:
    -> Step 4 (further decompose KV layer)

  backoff ratio > 20%:
    -> bottleneck = TIKV (or network)
    -> bottleneck_phase = "backoff"
    -> Break down by backoff type:
      txnLock       -> Transaction conflict
      regionMiss    -> Region cache invalidation
      tikvRPC       -> TiKV-side issue or network
      tikvServerBusy -> TiKV overloaded

  None of the above significant + overall latency is indeed high:
    -> No TiDB/TiKV/PD phase bottleneck identified
    -> Return to domain methodology Step 2 ("All phases roughly proportional" path)

Step 4: KV Layer Decomposition (when kv_request ratio is high)
  metrics:
    kv_prewrite:
      histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}", type="Prewrite"}[2m])) by (le))
    kv_commit:
      histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}", type="Commit"}[2m])) by (le))
    kv_get:
      histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}", type="Get"}[2m])) by (le))
    kv_cop:
      histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}", type="Cop"}[2m])) by (le))
    kv_batch_get:
      histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}", type="BatchGet"}[2m])) by (le))

  Write KV latency high (prewrite/commit):
    -> bottleneck = TIKV
    -> bottleneck_phase = "kv_write"
    -> Next step: tikv-fast-tune.md write subtree

  Read KV latency high (get/cop/batch_get):
    -> bottleneck = TIKV
    -> bottleneck_phase = "kv_read"
    -> Next step: tikv-fast-tune.md read subtree

  Both high:
    -> bottleneck = TIKV
    -> bottleneck_phase = "kv_all"
    -> Next step: tikv-fast-tune.md PRE_INFRA_CHECK (possible infrastructure issue)

Step 4.5: KV Write/Read Decomposition (when bottleneck is TIKV; skip if Step 4 already identified clear single-direction bottleneck with obvious cause)
  Write latency decomposition:
    kv_prewrite = async_write + async_snapshot + scheduler_pool_wait + scheduler_command_read
    async_write = store_duration + apply_duration
  Read latency decomposition:
    kv_read = unified_pool_wait + read_duration
    Signal: high unified read pool running tasks = read pressure
  Additional checks:
    - MVCC overhead: if coprocessor total_keys (next/prev ops) >> processed_keys → excessive MVCC versions
    - Flow control: check KV errors for flow-control/Server-is-busy → once triggered, entire system is throttled
```

---

## Data Source Call Templates

### Query Duration Total (baseline for ratio calculation)

```
POST /data-proxy/metrics/{cluster_id}/api/v1/query_range

query: sum(rate(tidb_server_handle_query_duration_seconds_sum{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Query Duration Per-Phase P99

```
POST /data-proxy/metrics/{cluster_id}/api/v1/query_range

# parse
query: histogram_quantile(0.99, sum(rate(tidb_session_parse_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

# compile
query: histogram_quantile(0.99, sum(rate(tidb_session_compile_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

# tso_wait
query: histogram_quantile(0.99, sum(rate(tidb_tikvclient_ts_future_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

# kv_request by type
query: histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))
```
