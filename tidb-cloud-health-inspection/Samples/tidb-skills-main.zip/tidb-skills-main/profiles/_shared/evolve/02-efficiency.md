### Execution Efficiency

| # | Rule | Detail |
|---|------|--------|
| 25 | **Reasoning budget** | Planning → deep (explore alternatives). Implementation → shallow (follow plan). Verification → deep (check against requirements). |
| 26 | **Doom-loop detection** | Same tool 3× → different strategy. Same file edit 3× → re-read context. Test fails 3× → systematic-debugging. Search empty 3× → broaden scope. |
| 27 | **Proactive compaction** | Compact at phase boundaries (planning→impl, impl→verify), after 20+ tool calls, or on topic switch. Preserve: goal, decisions, blockers, constraints. |
| 38 | **Data-Local-First** | Large fetches (≥3 API calls, >6h span) → pull to local file first, then analyze. |
| 39 | **Report-Local-First** | Output >30 lines → write to file, send ≤20 line summary to user. |
