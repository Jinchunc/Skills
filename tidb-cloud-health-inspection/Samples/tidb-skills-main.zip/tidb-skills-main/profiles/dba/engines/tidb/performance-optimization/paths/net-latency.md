# PATH-NET-LATENCY (S1.13 Network Latency Anomaly) <!-- Reason for change: unified as S1.x performance troubleshooting sub-number -->

> Entry condition: gRPC latency increase / cross-AZ latency increase / high TCP retransmissions

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm Network Latency Deviates from Baseline

```
metrics:
  tidb_side{tidb_cluster_id="{cluster_id}"}: histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  tikv_side{tidb_cluster_id="{cluster_id}"}: histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  delta: tidb_side{tidb_cluster_id="{cluster_id}"} - tikv_side{tidb_cluster_id="{cluster_id}"} (network + queuing latency)

condition: delta > tikv_side{tidb_cluster_id="{cluster_id}"} (network accounts for > 50%) or delta > 5ms
```

### Step 2: Identify Latency Layer

**Branch a: TiDB <-> TiKV Latency**
- Check if deployed across AZ / Region
- gRPC connection count: `tikv_grpc_connections{tidb_cluster_id="{cluster_id}"}`
- gRPC reconnect frequency (unstable connections → network quality)

**Branch b: TiDB <-> PD Latency**
- TSO wait high: `tidb_tikvclient_ts_future_wait_seconds{tidb_cluster_id="{cluster_id}"}` P99
- PD leader switch/instability → [MODULE-PD](../modules/pd-diagnosis.md)

**Branch c: Client <-> TiDB Latency**
- Connection pool configuration, TiProxy/Load Balancer
- Not observable in Clinic → suggest client-side investigation

### Step 3: Packet Loss/Retransmission

```
metrics (fail-open, Clinic may not support):
  tcp_retrans: node_netstat_Tcp_RetransSegs{tidb_cluster_id="{cluster_id}"}

High retransmission → DIAGNOSIS "Network quality issue"
```

### Step 4: gRPC Error Check

```
metrics:
  grpc_error: tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}
  kv_backoff: tidb_tikvclient_backoff_total{tidb_cluster_id="{cluster_id}", type=~".*rpc.*"}

High error rate → DIAGNOSIS "gRPC communication anomaly" + breakdown by error type
```

---

## Data Source Call Templates

### TiDB Side KV Request Latency
```
query: histogram_quantile(0.99, sum(rate(tidb_tikvclient_request_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))
```

### TiKV Side gRPC Latency
```
query: histogram_quantile(0.99, sum(rate(tikv_grpc_msg_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le, type))
```

### TSO Wait
```
query: histogram_quantile(0.99, sum(rate(tidb_tikvclient_ts_future_wait_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### gRPC Errors
```
query: sum(rate(tikv_grpc_req_fail_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```
