### Web Access Routing

Use cheapest sufficient tool: **L0** WebFetch/WebSearch → **L1** Playwright MCP → **L2** Playwright authenticated.

- Static page, rough summary → WebFetch. Precise content or JS rendering → Playwright MCP.
- Requires login → Playwright authenticated (`--extension` / `--cdp-endpoint` / `--user-data-dir`).
- Failure at any tier → escalate to next (max once per tier). GitHub → `gh` CLI.
- MUST NOT submit forms, store found credentials, or bypass CAPTCHA. Authenticated browsing limited to user-authorized domains.
