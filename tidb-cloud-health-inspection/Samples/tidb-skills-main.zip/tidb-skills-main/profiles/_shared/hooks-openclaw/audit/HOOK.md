---
name: audit
description: Logs all agent operations (tool calls, messages) to daily JSONL files for compliance and debugging.
scope: all-profiles
---

## Purpose

Provides an audit trail for all agent activity. Every tool call and message is logged with timestamp, event type, and sanitized metadata.

## Configuration

| Env Var | Default | Description |
|---------|---------|-------------|
| `AUDIT_DIR` | `/data/audit` | Directory for audit log files |

## Output Format

Daily JSONL files: `audit-YYYY-MM-DD.jsonl`

Each line is a JSON object:
```json
{"ts":"2026-03-26T10:00:00Z","event":"tool_call","tool":"Read","user":"..."}
{"ts":"2026-03-26T10:00:01Z","event":"tool_result","tool":"Read","ok":true,"duration_ms":42}
{"ts":"2026-03-26T10:00:02Z","event":"message_out","preview":"The file contains..."}
```

## Events

| Event | Trigger | Fields |
|-------|---------|--------|
| `tool_call` | Before tool execution | tool, user |
| `tool_result` | After tool execution | tool, ok, duration_ms |
| `message_in` | User message received | user, preview (100 chars) |
| `message_out` | Agent message sent | preview (100 chars) |

## Security

- Message previews are truncated to 100 characters
- No credentials or full message bodies are logged
- Works with redact hook — audit sees pre-redaction content for debugging
