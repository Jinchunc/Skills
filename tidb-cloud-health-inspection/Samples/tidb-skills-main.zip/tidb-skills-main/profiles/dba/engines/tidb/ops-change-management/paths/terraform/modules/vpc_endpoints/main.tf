locals {
  interface_services = {
    for service in var.interface_services :
    replace(service, ".", "_") => {
      service_name = "com.amazonaws.${var.aws_region}.${service}"
      tag_suffix   = replace(service, ".", "-")
    }
  }

  allowed_security_groups_by_index = {
    for idx, security_group_id in var.allowed_security_group_ids :
    tostring(idx) => security_group_id
  }
}

resource "aws_security_group" "vpc_endpoints" {
  name        = "${var.name}-vpc-endpoints"
  description = "HTTPS to AWS interface VPC endpoints from EKS"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, { Name = "${var.name}-vpc-endpoints" })
}

resource "aws_vpc_security_group_ingress_rule" "endpoints_https" {
  for_each = local.allowed_security_groups_by_index

  security_group_id            = aws_security_group.vpc_endpoints.id
  description                  = "HTTPS from cluster/worker security group"
  referenced_security_group_id = each.value
  ip_protocol                  = "tcp"
  from_port                    = 443
  to_port                      = 443
}

resource "aws_vpc_security_group_egress_rule" "endpoints_all_out" {
  security_group_id = aws_security_group.vpc_endpoints.id
  description       = "Allow return traffic from AWS APIs"
  ip_protocol       = "-1"
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_vpc_endpoint" "s3" {
  vpc_id            = var.vpc_id
  service_name      = "com.amazonaws.${var.aws_region}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = var.private_route_table_ids

  tags = merge(var.tags, { Name = "${var.name}-s3" })
}

resource "aws_vpc_endpoint" "interface" {
  for_each = local.interface_services

  vpc_id              = var.vpc_id
  service_name        = each.value.service_name
  vpc_endpoint_type   = "Interface"
  subnet_ids          = var.interface_subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true

  tags = merge(var.tags, { Name = "${var.name}-${each.value.tag_suffix}" })
}
