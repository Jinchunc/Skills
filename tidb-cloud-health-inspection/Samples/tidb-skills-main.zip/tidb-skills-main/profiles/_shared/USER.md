# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:**
- **What to call them:**
- **Pronouns:** _(optional)_
- **Timezone:**
- **Notes:**

## Preferences

_(What matters to them? Code quality? Shipping speed? Both? How do they want you to behave? Any boundaries or working style preferences? Write it down here.)_

## Context

_(What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember -- you're learning about a person, not building a dossier. Respect the difference.
