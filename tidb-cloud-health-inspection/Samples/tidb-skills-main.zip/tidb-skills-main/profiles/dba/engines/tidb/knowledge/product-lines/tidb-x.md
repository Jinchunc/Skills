# TiDB X — Common Architecture

> TiDB X (Starter / Essential / Premium) shared resource model. Read this before any TiDB X diagnostic, fleet enumeration, or metric interpretation work.

---

## Two-Layer Topology

TiDB X uses a two-layer resource architecture. Logical clusters (keyspaces) run on top of shared physical resource pools.

| Layer | ID Pattern | What It Is | Diagnostic Meaning |
|-------|-----------|------------|-------------------|
| **Logical cluster (keyspace)** | `10...` | The actual user cluster — what customers call "my cluster". Essential/Premium logical clusters are isolated by keyspace inside the pool. | **This is your target.** All business metrics (QPS, RU, P99) belong here. |
| **Physical pool (dataplane)** | `20...` | Shared resource pool hosting multiple logical clusters (multi-tenant). One pool can host many Essential/Premium cluster IDs. | **Exclude from metrics.** Its gRPC/storage metrics aggregate all hosted keyspaces + other tenants. |

A physical pool (`20...`) hosts multiple logical clusters (`10...`) in a many-to-one relationship.

---

## Metric Layering

| Metric Layer | Source | What It Measures | When to Use |
|-------------|--------|-----------------|-------------|
| **SQL layer** | TiDB Server (`tidb_server_*`) | Business QPS, RU/s, P99 latency | Primary cluster health indicator. Always correct for logical clusters. |
| **TiKV backend** | TiKV gRPC (`tikv_grpc_*`) | Physical pool gRPC request rate, includes amplification + other tenants | **DO NOT use as cluster QPS.** This is backend noise, not business throughput. |
| **Storage** | TiKV disk usage | Physical bytes on disk (× replica factor, multi-tenant) | **DO NOT sum across clusters.** Use per-cluster allocation, not physical-pool total. |

---

## Cluster Enumeration — Correct Method

**Authority source:** Clinic API `/clinic/api/v1/dashboard/clusters` — returns deployType, cluster name, parentID, active status.

Steps:
1. Call Clinic API → get full org cluster list
2. Filter: `deployType` in `{essential, premium, starter}` AND `active=true` → these are your **logical clusters (keyspaces)**
3. Exclude: `deployType=nextgen-host` → these are physical resource pools, NOT clusters
4. Use `cluster_name` + `cluster_id` (keyspace ID `10...`) as the cluster identifier
5. Note `parentID` for resource-pool mapping (informational only, for RCU/throttling checks)

**DO NOT enumerate via GS o11y applicationID** — that list mixes logical clusters, physical pools, and deleted records without labels.

---

## Common Pitfalls

| Wrong | Why Wrong | Correct |
|-------|-----------|---------|
| Treating `20...` IDs as independent clusters | They are physical pools hosting multiple keyspaces | Only enumerate `10...` IDs |
| Summing TiKV disk usage across clusters | Includes replica factor and other tenants | Use per-cluster allocation |
| Reporting "TiKV layer QPS" as cluster throughput | TiKV gRPC includes backend amplification | Use SQL-layer QPS only |
| Filling RU/s for RawKV/TxnKV clusters | RU only meters SQL-layer traffic; ~4 RU/s is Resource Manager baseline noise | Mark as N/A for non-SQL clusters |
| Using `tidb_cluster_id` label to filter Serverless logs | `cluster_id` is pool-level for Starter/Essential | Filter by `keyspaceID` in log content |

---

## Tier-Specific Guides

| Tier | Doc | Focus |
|------|-----|-------|
| Premium | [premium.md](premium.md) | Multi-tenant resource pools, autoscaler, Performance Insight, RCU/resource control |
| Essential | [essential.md](essential.md) | Keyspace-isolated shared pool, IOPS quota, RCU throttling, limited observability |
| Starter | [starter.md](starter.md) | Serverless dev/test tier, smallest quota, highest metric gaps |
| Dedicated | [dedicated.md](dedicated.md) | Single-tenant Gardener shoots, full topology, full observability |
