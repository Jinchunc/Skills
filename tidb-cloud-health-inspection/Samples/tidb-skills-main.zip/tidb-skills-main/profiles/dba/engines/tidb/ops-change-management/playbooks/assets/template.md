# RCA {ST ticket number}|{TCOC ticket number}

> [!IMPORTANT]
>
> This document is drafted by AI. Please verify the correctness before submitting.

| Author | Reviewer | Last Updated |
|--------|----------|--------------|
| @      |          |              |

## Summary

* **Summary**: {issue summary}
* **ST Link**: <https://tidb.atlassian.net/browse/{ST ticket number}>
* **TCOC Link**: <https://tidb.atlassian.net/browse/{TCOC ticket number}>
* **Severity**: {severity}
* **Impact Time Range**: {trigger timestamp} ~ {recovery timestamp}
* **Impact Scope**: {impact scope}
* **User Impact Summary**: {user impact summary}
* **MTTD (Detection)**: {approximated duration(trigger timestamp → detection timestamp)}
* **MTTA (Analysis)**: {approximated duration(trigger timestamp → diagnosis timestamp)}
* **MTTR (Recovery)**: {approximated duration(trigger timestamp → recovery timestamp)}

---

## Timeline

### Trigger

{ ... trigger timeline ... }

### Detection

{ ... detection timeline ... }

### Diagnosis

{ ... diagnosis timeline ... }

### Mitigation

{ ... mitigation timeline ... }

### Recovery

{ ... recovery timeline ... }

### Portmortem / Follow-up

{ ... postmortem timeline ... }

## Root Cause Analysis

### Reproduction Steps

{ ... reproduction steps ... }

### Analysis

{ ... analysis steps ... }

### Conclusion

{ ... conclusion ... }

### Other

---

## Solution

* **Mitigation**: {mitigation summary}
* **Workaround**: {optional: alternative mitigation summary}
* **Long-Term Fix**: {solution summary}
