# Domain 5: 运维变更 (Ops Change Management)

> Status: **Partial**
> Tier: B (Engine-weak)

## Core

基础设施与配置变更管理。扩缩容、参数调优、版本升级。

## Scenarios

- 扩缩容评估与执行
- 参数调优建议与影响评估
- 版本升级路径规划
- 配置变更影响评估
- 回滚方案生成
- 变更窗口推荐

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | `engines/tidb/ops-change-management` (config-change-review) | Partial |
| MySQL | — | Not yet built |
| PostgreSQL | — | Not yet built |
| MongoDB | — | Not yet built |

## Shared Skills

- `skills/migration-planner` — 迁移规划（纯迁移/同步拓扑建设属于 data-migration-sync 域）

## Key Checks (to build)

- 变更影响范围评估
- 回滚方案完整性
- 变更窗口推荐（业务低峰）
- 升级路径兼容性验证

## Routing Note

- 基础设施变更（扩缩容/参数/升级/回滚编排） → 本域
- DDL 影响评估（锁表/回填） → 域6 (sql-schema-management)
