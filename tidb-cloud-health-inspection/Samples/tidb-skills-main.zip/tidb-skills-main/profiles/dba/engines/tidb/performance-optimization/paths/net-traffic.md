# PATH-NET-TRAFFIC (S1.12 Network Traffic Anomaly) <!-- Reason for change: unified as S1.x performance troubleshooting sub-number -->

> Entry condition: Inter-component network traffic deviates from baseline (gRPC bandwidth surge)

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range

---

## Decision Tree

### Step 1: Confirm Traffic Deviates from Baseline

```
metrics:
  grpc_sent: sum(rate(tikv_grpc_msg_bytes_sent_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
  grpc_recv: sum(rate(tikv_grpc_msg_bytes_received_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)

condition: current traffic > baseline x 2 or absolute value is anomalous
```

### Step 2: Identify Traffic Source

**Branch a: Read Traffic Surge**
- Check large range scan SQL: → [MODULE-SQL](../modules/sql-diagnosis.md) (query total_keys Top SQL)
- Coprocessor scan volume: `tikv_coprocessor_scan_keys_total{tidb_cluster_id="{cluster_id}"}`
- Full table scan/missing index → MODULE-SQL

**Branch b: Write Traffic Surge**
- Batch writes/large transactions
- Compaction output: `tikv_engine_compaction_flow_bytes{tidb_cluster_id="{cluster_id}"}`
- Caused by compaction → [MODULE-TIKV](../modules/tikv-fast-tune.md) S3_COMPACTION_FLOW

**Branch c: Uneven Traffic Across Instances**
- Some instance has much higher traffic than others → [PATH-HOTSPOT](hotspot.md)

### Step 3: Is It Triggering a Bottleneck

```
metrics:
  grpc_total_sent: sum(rate(tikv_grpc_msg_bytes_sent_total{tidb_cluster_id="{cluster_id}"}[2m]))
  grpc_total_recv: sum(rate(tikv_grpc_msg_bytes_received_total{tidb_cluster_id="{cluster_id}"}[2m]))

condition:
  Single instance gRPC sent+recv > 1Gbps (125MB/s) → network bandwidth risk
  Not hitting limit but > baseline x 2 → identify root cause SQL/task
```

---

## Data Source Call Templates

### gRPC Byte Traffic
```
query: sum(rate(tikv_grpc_msg_bytes_sent_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
query: sum(rate(tikv_grpc_msg_bytes_received_total{tidb_cluster_id="{cluster_id}"}[2m])) by (instance)
```

### Coprocessor Scan Volume
```
query: sum(rate(tikv_coprocessor_scan_keys_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

---

## Remediation References

When root cause is SQL-driven traffic (Branch A: read traffic from full scans), load the relevant tuning reference:
- Explain patterns (identifying full scans): [../references/sql-optimization.md](../references/sql-optimization.md)
- Full remediation routing table: [../modules/sql-diagnosis.md — Remediation section](../modules/sql-diagnosis.md#remediation--tuning-references)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
