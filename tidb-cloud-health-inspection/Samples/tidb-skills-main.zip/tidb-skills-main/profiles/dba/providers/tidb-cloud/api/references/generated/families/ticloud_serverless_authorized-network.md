# Serverless Authorized Network

Base command: `ticloud serverless authorized-network`

Manage TiDB Cloud Serverless cluster authorized networks

## Direct Subcommands

- `ticloud serverless authorized-network create` - Create an authorized network
- `ticloud serverless authorized-network delete` - Delete an authorized network (dangerous)
- `ticloud serverless authorized-network list` - List all authorized networks (human-output)
- `ticloud serverless authorized-network update` - Update an authorized network (sensitive)

## Confirmation Required

- `ticloud serverless authorized-network delete`
