# PATH-CONN-FAIL (S3.2 Connection Failure)

> Entry condition: Cannot connect to database / connection refused / too many connections / TLS error

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Error message

---

## Decision Tree

### Branch a: Connection Refused

- Is the TiDB instance alive: `process_start_time_seconds{tidb_cluster_id="{cluster_id}", job="tidb"}`
- Has the TiDB X instance scaled to zero -> [MODULE-RCU](../../knowledge/rcu-check.md)
- Port unreachable -> Suggest user check network/firewall

### Branch b: Too Many Connections

```
metrics:
  connections: tidb_server_connections{tidb_cluster_id="{cluster_id}"} by (instance)

checks:
  - Current connections vs max-connections config (default 0 = unlimited; if configured, an instance with connections >= max-connections -> new connections rejected)
  - Are connections balanced: max(connections) / avg(connections) > 2 -> LB issue
```

-> [MODULE-TIDB](../../performance-optimization/modules/tidb-diagnosis.md) (Node 1 Load Balancing)

### Branch c: TLS / Auth Error

- Certificate expired/mismatched -> Check certificate validity period
- Wrong username/password -> Not a performance issue

### Branch d: Slow Connection Establishment

- TiDB CPU (SSL handshake is CPU intensive)
- DNS resolution delay
- Network latency -> [PATH-NET-LATENCY](../../performance-optimization/paths/net-latency.md)

-> DIAGNOSIS -> END

---

## Data Source Call Templates

### TiDB Connection Count
```
query: tidb_server_connections{tidb_cluster_id="{cluster_id}"} by (instance)
```

### TiDB Process Alive
```
query: process_start_time_seconds{job="tidb", tidb_cluster_id="{cluster_id}"}
```
