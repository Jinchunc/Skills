# Serverless Core

Base command: `ticloud serverless`

Manage TiDB Cloud Serverless clusters

## Direct Subcommands

- `ticloud serverless audit-log` - Manage TiDB Cloud Serverless database audit logging
- `ticloud serverless authorized-network` - Manage TiDB Cloud Serverless cluster authorized networks
- `ticloud serverless backup` - Manage serverless cluster backups
- `ticloud serverless branch` - Manage TiDB Cloud Serverless branches
- `ticloud serverless capacity` - Set capacity for a TiDB Cloud Serverless cluster
- `ticloud serverless changefeed` - Manage TiDB Cloud Serverless changefeeds
- `ticloud serverless create` - Create a TiDB Cloud Serverless cluster
- `ticloud serverless delete` - Delete a TiDB Cloud Serverless cluster (dangerous)
- `ticloud serverless describe` - Describe a TiDB Cloud Serverless cluster
- `ticloud serverless export` - Manage TiDB Cloud Serverless exports
- `ticloud serverless import` - Manage TiDB Cloud Serverless data imports
- `ticloud serverless list` - List all TiDB Cloud Serverless clusters (human-output)
- `ticloud serverless migration` - Manage TiDB Cloud Serverless migrations
- `ticloud serverless private-link-connection` - Manage private link connections for dataflow
- `ticloud serverless region` - List all available regions for TiDB Cloud Serverless (human-output)
- `ticloud serverless restore` - Restore a serverless cluster (sensitive)
- `ticloud serverless shell` - Connect to a TiDB Cloud Serverless cluster
- `ticloud serverless spending-limit` - Set spending limit for a TiDB Cloud Serverless cluster
- `ticloud serverless sql-user` - Manage cluster SQL users
- `ticloud serverless update` - Update a TiDB Cloud Serverless cluster (sensitive)

## Confirmation Required

- `ticloud serverless delete`
