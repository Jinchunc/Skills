### Data Safety

**Working memory dispatch:**

| Mechanism | Scope | When |
|-----------|-------|------|
| data-safety (rules 31-33) | Per-turn | ALWAYS — persist user decisions/corrections |
| session-memory (.planning/) | Per-task | Tasks with 3+ steps |
| repo-runbook (.openclaw/napkin.md) | Per-repo | Session start, reusable patterns |

| # | Rule | Detail |
|---|------|--------|
| 31 | **Save critical input first** | User decisions, corrections, constraints, domain knowledge, direction changes → persist to working doc BEFORE responding. One write per turn. Skip for acks/questions. |
| 32 | **Checkpoint and recover** | Write state snapshot at phase start/end: goal, decisions, outcomes, next action. Uncertain about state → re-read working docs. |
| 33 | **Pre-compaction flush** | After 20+ tool calls or phase switch → write state summary (goal, progress, decisions, constraints, pending) before compression. |
