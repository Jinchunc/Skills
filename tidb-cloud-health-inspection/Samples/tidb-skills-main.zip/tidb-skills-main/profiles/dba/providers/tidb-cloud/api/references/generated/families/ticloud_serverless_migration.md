# Serverless Migration

Base command: `ticloud serverless migration`

Manage TiDB Cloud Serverless migrations

## Direct Subcommands

- `ticloud serverless migration create` - Create a migration
- `ticloud serverless migration delete` - Delete a migration (dangerous)
- `ticloud serverless migration describe` - Describe a migration
- `ticloud serverless migration list` - List migrations (human-output)
- `ticloud serverless migration pause` - Pause a migration (sensitive)
- `ticloud serverless migration resume` - Resume a paused migration (sensitive)
- `ticloud serverless migration template` - Show migration JSON templates

## Confirmation Required

- `ticloud serverless migration delete`
