#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Usage:
  aws_provision.sh [--plan|--apply]

Creates the cluster security group, EC2 cluster nodes, control-host MinIO ingress
rule, and MinIO EBS volume. Defaults to --plan and does not mutate AWS unless
--apply is passed.
USAGE
}

action="${1:---plan}"
case "$action" in
  --plan) apply=0 ;;
  --apply) apply=1 ;;
  --help) usage; exit 0 ;;
  *) usage; exit 1 ;;
esac

need_cmd aws
require_env \
  PROFILE REGION AZ VPC_ID SUBNET_ID AMI KEY_NAME CLUSTER_NAME OWNER \
  EXPIRES_AT COST_CEILING_USD CONTROL_SG CONTROL_INSTANCE_ID OPERATOR_CIDR \
  PD_COUNT PD_TYPE PD_ROOT_GB TIDB_COUNT TIDB_TYPE TIDB_ROOT_GB \
  TIKV_COUNT TIKV_TYPE TIKV_ROOT_GB MONITOR_COUNT MONITOR_TYPE \
  MONITOR_ROOT_GB MINIO_SIZE_GB MINIO_IOPS MINIO_THROUGHPUT_MBPS

STATE_FILE="${STATE_FILE:-./tidbx-aws-multinode.state.env}"
CREATED_BY="${CREATED_BY:-${USER:-agent}}"
PRESSURE_COUNT="${PRESSURE_COUNT:-0}"
PRESSURE_TYPE="${PRESSURE_TYPE:-}"
PRESSURE_ROOT_GB="${PRESSURE_ROOT_GB:-}"

if [ "$apply" -eq 0 ]; then
  cat <<EOF
PLAN ONLY: no AWS resources will be created.
To apply, rerun: STATE_FILE="$STATE_FILE" $0 --apply

Will create:
  security group: $CLUSTER_NAME-sg in $VPC_ID
  nodes:
    pd=${PD_COUNT}x${PD_TYPE}/${PD_ROOT_GB}GiB
    tidb=${TIDB_COUNT}x${TIDB_TYPE}/${TIDB_ROOT_GB}GiB
    tikv=${TIKV_COUNT}x${TIKV_TYPE}/${TIKV_ROOT_GB}GiB
    monitor=${MONITOR_COUNT}x${MONITOR_TYPE}/${MONITOR_ROOT_GB}GiB
    pressure=${PRESSURE_COUNT}x${PRESSURE_TYPE:-none}/${PRESSURE_ROOT_GB:-none}GiB
  control-host ingress: $CONTROL_SG allows cluster SG to MinIO ports 9000-9001
  MinIO volume: gp3 ${MINIO_SIZE_GB}GiB/${MINIO_IOPS}IOPS/${MINIO_THROUGHPUT_MBPS}MBps attached to $CONTROL_INSTANCE_ID
State file:
  $STATE_FILE
EOF
  exit 0
fi

tag_spec() {
  local resource_type="$1"
  local name="$2"
  local extra_tags="${3:-}"
  printf 'ResourceType=%s,Tags=[{Key=Name,Value=%s},{Key=Owner,Value=%s},{Key=Purpose,Value=tidbx-aws-multinode-test},{Key=ClusterName,Value=%s},{Key=CreatedBy,Value=%s},{Key=ExpiresAt,Value=%s},{Key=CostCeilingUSD,Value=%s}%s]' \
    "$resource_type" "$name" "$OWNER" "$CLUSTER_NAME" "$CREATED_BY" "$EXPIRES_AT" "$COST_CEILING_USD" "$extra_tags"
}

launch_node() {
  local role="$1"
  local idx="$2"
  local instance_type="$3"
  local root_gb="$4"
  local name="$CLUSTER_NAME-$OWNER-$role-$idx"
  local extra=",{Key=Role,Value=$role},{Key=Index,Value=$idx}"

  aws --profile "$PROFILE" --region "$REGION" ec2 run-instances \
    --image-id "$AMI" \
    --instance-type "$instance_type" \
    --key-name "$KEY_NAME" \
    --subnet-id "$SUBNET_ID" \
    --security-group-ids "$SG" \
    --associate-public-ip-address \
    --block-device-mappings "[{\"DeviceName\":\"/dev/xvda\",\"Ebs\":{\"VolumeSize\":$root_gb,\"VolumeType\":\"gp3\",\"DeleteOnTermination\":true}}]" \
    --tag-specifications "$(tag_spec instance "$name" "$extra")" \
    --query 'Instances[0].InstanceId' --output text
}

append_group() {
  local role="$1"
  local count="$2"
  local instance_type="$3"
  local root_gb="$4"
  local id
  local i

  for i in $(seq 1 "$count"); do
    id="$(launch_node "$role" "$i" "$instance_type" "$root_gb")"
    all_instance_ids+=("$id")
    group_ids+=("$id")
  done
}

all_instance_ids=()
group_ids=()

SG="$(aws --profile "$PROFILE" --region "$REGION" ec2 create-security-group \
  --group-name "$CLUSTER_NAME-sg" \
  --description "$CLUSTER_NAME TiDB X test cluster" \
  --vpc-id "$VPC_ID" \
  --tag-specifications "$(tag_spec security-group "$CLUSTER_NAME-sg")" \
  --query GroupId --output text)"
write_state "$STATE_FILE" SG "$SG"
write_state "$STATE_FILE" CLUSTER_SG "$SG"

aws --profile "$PROFILE" --region "$REGION" ec2 authorize-security-group-ingress \
  --group-id "$SG" --source-group "$SG" --protocol -1 --port -1
aws --profile "$PROFILE" --region "$REGION" ec2 authorize-security-group-ingress \
  --group-id "$SG" --source-group "$CONTROL_SG" --protocol -1 --port -1
aws --profile "$PROFILE" --region "$REGION" ec2 authorize-security-group-ingress \
  --group-id "$SG" --ip-permissions \
  "IpProtocol=tcp,FromPort=22,ToPort=22,IpRanges=[{CidrIp=$OPERATOR_CIDR,Description=operator-ssh}]" \
  "IpProtocol=tcp,FromPort=4000,ToPort=4000,IpRanges=[{CidrIp=$OPERATOR_CIDR,Description=operator-sql}]" \
  "IpProtocol=tcp,FromPort=3000,ToPort=3000,IpRanges=[{CidrIp=$OPERATOR_CIDR,Description=operator-grafana}]" \
  "IpProtocol=tcp,FromPort=9090,ToPort=9090,IpRanges=[{CidrIp=$OPERATOR_CIDR,Description=operator-prometheus}]"
aws --profile "$PROFILE" --region "$REGION" ec2 authorize-security-group-ingress \
  --group-id "$CONTROL_SG" \
  --ip-permissions "IpProtocol=tcp,FromPort=9000,ToPort=9001,UserIdGroupPairs=[{GroupId=$SG,Description=tidbx-cluster-to-minio}]"

group_ids=()
append_group pd "$PD_COUNT" "$PD_TYPE" "$PD_ROOT_GB"
write_state "$STATE_FILE" PD_IDS "${group_ids[*]}"
group_ids=()
append_group tidb "$TIDB_COUNT" "$TIDB_TYPE" "$TIDB_ROOT_GB"
write_state "$STATE_FILE" TIDB_IDS "${group_ids[*]}"
group_ids=()
append_group tikv "$TIKV_COUNT" "$TIKV_TYPE" "$TIKV_ROOT_GB"
write_state "$STATE_FILE" TIKV_IDS "${group_ids[*]}"
group_ids=()
append_group monitor "$MONITOR_COUNT" "$MONITOR_TYPE" "$MONITOR_ROOT_GB"
write_state "$STATE_FILE" MONITOR_IDS "${group_ids[*]}"

if [ "$PRESSURE_COUNT" -gt 0 ]; then
  require_env PRESSURE_TYPE PRESSURE_ROOT_GB
  group_ids=()
  append_group pressure "$PRESSURE_COUNT" "$PRESSURE_TYPE" "$PRESSURE_ROOT_GB"
  write_state "$STATE_FILE" PRESSURE_IDS "${group_ids[*]}"
fi

write_state "$STATE_FILE" ALL_INSTANCE_IDS "${all_instance_ids[*]}"

aws --profile "$PROFILE" --region "$REGION" ec2 wait instance-status-ok \
  --instance-ids "${all_instance_ids[@]}"
aws --profile "$PROFILE" --region "$REGION" ec2 describe-instances \
  --instance-ids "${all_instance_ids[@]}" \
  --query 'Reservations[].Instances[].{Name:Tags[?Key==`Name`]|[0].Value,InstanceId:InstanceId,PrivateIp:PrivateIpAddress,PublicIp:PublicIpAddress,State:State.Name}' \
  --output table

MINIO_VOLUME_ID="$(aws --profile "$PROFILE" --region "$REGION" ec2 create-volume \
  --volume-type gp3 \
  --size "$MINIO_SIZE_GB" \
  --iops "$MINIO_IOPS" \
  --throughput "$MINIO_THROUGHPUT_MBPS" \
  --availability-zone "$AZ" \
  --tag-specifications "$(tag_spec volume "$CLUSTER_NAME-$OWNER-minio")" \
  --query VolumeId --output text)"
write_state "$STATE_FILE" MINIO_VOLUME_ID "$MINIO_VOLUME_ID"

aws --profile "$PROFILE" --region "$REGION" ec2 wait volume-available \
  --volume-ids "$MINIO_VOLUME_ID"
aws --profile "$PROFILE" --region "$REGION" ec2 attach-volume \
  --volume-id "$MINIO_VOLUME_ID" \
  --instance-id "$CONTROL_INSTANCE_ID" \
  --device /dev/sdf
aws --profile "$PROFILE" --region "$REGION" ec2 wait volume-in-use \
  --volume-ids "$MINIO_VOLUME_ID"

log "Provisioning complete. State file: $STATE_FILE"
