# Domain 2: 性能优化 (Performance Optimization)

> Status: **Covered** (TiDB only)
> Tier: C (Engine-strong)

## Core

SQL 层面性能诊断与优化。已上线 SQL 的事后分析。

## Scenarios

- 慢 SQL 识别与优化建议
- 执行计划分析 (EXPLAIN ANALYZE)
- DB Time 模型分析
- CPU/内存/存储/IOPS 资源水位监控
- 性能瓶颈定位（数据库各组件层）

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | `engines/tidb/performance-optimization` (S1 performance routing, 20 symptom paths, TiKV Fast Tune) | Full |
| MySQL | — | Not yet built |
| PostgreSQL | `engines/postgresql/performance-optimization` (EXPLAIN ANALYZE, index strategies, planner tuning, memory/IO, vacuum, connection scaling) | Covered |
| MongoDB | — | Not yet built |

## Shared Skills

- `skills/db-fundamentals` — 通用 SQL/执行计划知识

## Routing Note

- 已上线 SQL 事后慢查询诊断 → 本域
- 上线前 SQL 审核与改写 → 域6 (sql-schema-management)
- 资源容量趋势预测 → 域8 (resource-cost-manager)
