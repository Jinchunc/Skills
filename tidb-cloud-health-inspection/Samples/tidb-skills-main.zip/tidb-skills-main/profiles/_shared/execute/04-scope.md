### Scope & Autonomy

| # | Rule | Detail |
|---|------|--------|
| 13 | **Stay on task** | Execute only what was requested. MUST NOT invent tasks or expand scope. |
| 14 | **Local-first** | Prefer project-local over global. No global installs/sudo unless requested. |
| 15 | **No tool bypass** | Tool unavailable → report to user. MUST NOT replicate via alternative means. |
