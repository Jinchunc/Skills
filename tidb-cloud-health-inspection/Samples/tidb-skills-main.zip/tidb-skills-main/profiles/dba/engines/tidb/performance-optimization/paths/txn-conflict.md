# PATH-TXN-CONFLICT (S1.16 Transaction Conflict) <!-- Modification reason: Unified as S1.x performance investigation sub-number -->

> Entry condition: Write conflict / Lock wait timeout / deadlock

---

## Prerequisites

1. **MODULE-CLUSTER-ID**
2. Time range, error message

> **Field corrections:** SELECT without FOR UPDATE never acquires pessimistic locks (#6). Cross-database transactions with matching block durations suggest a single JPA @Transactional (#7). See [field-corrections.md](../../knowledge/field-corrections.md).

---

## Decision Tree

### Step 1: Confirm Conflict Type and Scale

```
metrics:
  lock_resolve: sum(rate(tidb_tikvclient_lock_resolver_actions_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
  conflict:     sum(rate(tidb_tikvclient_txn_conflict_counter_total{tidb_cluster_id="{cluster_id}"}[2m]))
  lock_wait:    histogram_quantile(0.99, sum(rate(tikv_lock_manager_waiter_lifetime_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
  deadlock:     sum(rate(tikv_lock_manager_detect_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[2m]))
  txn_duration: histogram_quantile(0.99, sum(rate(tidb_tikvclient_txn_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))

Classification:
  conflict rate > 0 + optimistic transaction → Step 2a (write_conflict)
  lock_wait_p99 > 1s (pessimistic-txn.wait-for-lock-timeout default 1s) → Step 2b (lock_wait_timeout)
  deadlock rate > 0 → Step 2c (deadlock)
  txn_duration_p99 > 60s → Long transaction exists, may block GC (GcResolveLockMaxBackoff=100s)
```

### Step 2a: Write Conflict (Optimistic Transaction)

```
metrics:
  conflict_count: tidb_tikvclient_txn_conflict_counter_total{tidb_cluster_id="{cluster_id}"}

Find conflicting SQL:
  → MODULE-SQL: slow_query_logs where backoff_types contains txnLock

High-frequency conflict → DIAGNOSIS:
  - Consider switching to pessimistic transaction: SET tidb_txn_mode{tidb_cluster_id="{cluster_id}"} = 'pessimistic' (suggest user to execute)
  - Reduce transaction scope
  - Application-level retry logic
```

### Step 2b: Lock Wait Timeout (Pessimistic Transaction)

```
Find lock-holding transaction (generate SQL for user to execute):
  SELECT * FROM information_schema.DATA_LOCK_WAITS LIMIT 20;

Check for long transactions:
  txn_duration_p99 > 60s = long transaction exists (each pessimistic lock retry waits ~1s, 7 RPCs ≈ 7s+ latency)

Check for hotspot key:
  Same key updated with high concurrency → PATH-HOTSPOT

→ DIAGNOSIS: Optimize long transactions / reduce lock scope / adjust lock-wait-timeout
```

### Step 2c: Deadlock

```
Find deadlock cycle (generate SQL for user to execute):
  SELECT * FROM information_schema.DEADLOCKS LIMIT 20;

Analyze the involved SQL and tables
→ DIAGNOSIS: Unify lock ordering / reduce transaction granularity
```

---

## Data Source Call Templates

### Lock Resolver Actions
```
query: sum(rate(tidb_tikvclient_lock_resolver_actions_total{tidb_cluster_id="{cluster_id}"}[2m])) by (type)
```

### Transaction Conflict Count
```
query: sum(rate(tidb_tikvclient_txn_conflict_counter_total{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Lock Wait Duration P99
```
query: histogram_quantile(0.99, sum(rate(tikv_lock_manager_waiter_lifetime_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Deadlock Detection Frequency
```
query: sum(rate(tikv_lock_manager_detect_duration_seconds_count{tidb_cluster_id="{cluster_id}"}[2m]))
```

### Transaction Duration P99
```
query: histogram_quantile(0.99, sum(rate(tidb_tikvclient_txn_duration_seconds_bucket{tidb_cluster_id="{cluster_id}"}[2m])) by (le))
```

### Slow Queries with txnLock Backoff
```sql
SELECT digest, digest_text, query_time, backoff_types, backoff_time
FROM slow_query_logs
WHERE backoff_types LIKE '%txnLock%' AND time BETWEEN '{start}' AND '{end}'
ORDER BY query_time DESC LIMIT 10
```

---

## Remediation References

When root cause is SQL/transaction-level conflict, load the relevant tuning reference:
- Full remediation routing table: [../modules/sql-diagnosis.md — Remediation section](../modules/sql-diagnosis.md#remediation--tuning-references)
- Session variables (transaction mode, lock timeout): [../references/session-variables.md](../references/session-variables.md)
- Similar case search: [../../knowledge/oncall-experiences/](../../knowledge/oncall-experiences/)
