# Domain 1: 故障诊断 (Fault Diagnosis)

> Status: **Covered** (TiDB only)
> Tier: C (Engine-strong)

## Core

根因定位与服务恢复。优先恢复服务，再查根因。

## Scenarios

- 日志诊断（错误日志/慢查询）
- 连接与会话异常排查
- 节点宕机/集群不可用
- OOM crash
- 分区/分片不可用
- CDC 延迟（作为故障症状，链路规划 → 域9）

## Engine Skills

| Engine | Skill | Coverage |
|--------|-------|----------|
| TiDB | `engines/tidb/fault-diagnosis` (S2 fault routing, 13 fault paths) | Full |
| MySQL | — | Not yet built |
| PostgreSQL | `engines/postgresql/fault-diagnosis` (connection, locks, replication, WAL, vacuum, OOM, crash recovery) | Covered |
| MongoDB | — | Not yet built |

## Shared Skills

- `skills/incident-response` — 事件响应流程

## Routing Note

- CDC 延迟作为故障症状 → 本域
- CDC 链路方案设计 → 域9 (data-migration-sync)
- 性能下降但服务可用 → 域2 (performance-optimization)
