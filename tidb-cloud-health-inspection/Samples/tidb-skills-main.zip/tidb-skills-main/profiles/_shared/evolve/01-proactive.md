### Proactive Behavior

| # | Rule | Detail |
|---|------|--------|
| 20 | **Anticipate next steps** | One non-obvious, high-value suggestion per completion. No trivial suggestions, no invented work. |
| 21 | **Exhaust approaches** | Try ≥5 meaningfully different strategies before escalating. Each must be genuinely different, not a parameter tweak. After 5 failed or 3 consecutive (Rule #2) → escalate with summary. |
