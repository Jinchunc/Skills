# Optimizer Controls

## 1. Optimizer Hints

TiDB supports query-level optimizer hints using the `/*+ HINT() */` syntax placed immediately after `SELECT`, `UPDATE`, or `DELETE`.

## Syntax

```sql
SELECT /*+ HINT_NAME(arguments) */ ...
```

Multiple hints can be combined:

```sql
SELECT /*+ HASH_JOIN(t1, t2) NO_DECORRELATE() */ ...
```

## Hint Catalog

### Join strategy hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `HASH_JOIN(t1, t2)` | Force hash join between named tables | Large table joins without useful indexes; both sides are large |
| `INL_JOIN(t)` | Force index nested loop join, `t` is the inner (probed) side | Inner table has a good index on the join key and is large; outer side is small |
| `INL_HASH_JOIN(t)` | Index join with hash join on the inner side | Similar to INL_JOIN but inner side needs hash matching |
| `MERGE_JOIN(t1, t2)` | Force sort-merge join | Both sides are already sorted on join key or can be cheaply sorted |
| `SHUFFLE_JOIN(t1, t2)` | Force shuffle hash join (MPP) | TiFlash queries where data needs redistributing across nodes |
| `BROADCAST_JOIN(t1, t2)` | Force broadcast join (MPP) | TiFlash queries where one side is small enough to broadcast |

### Join order hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `LEADING(t1, t2, t3)` | Force join order; tables joined left to right | Optimizer picks a bad join order due to cardinality misestimation |
| `STRAIGHT_JOIN()` | Join tables in the order written in FROM clause | Quick override when you know the right order |

### Subquery hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `NO_DECORRELATE()` | Keep correlated subquery as-is; do not flatten into a join | Subquery is well-indexed, outer query is selective. See `sql-optimization.md` |
| `SEMI_JOIN_REWRITE()` | Rewrite semi-join to inner join with deduplication | When semi-join execution is slow and inner side has few duplicates |

### Index hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `USE_INDEX(t, idx)` | Force use of a specific index | Optimizer picks wrong index or full table scan |
| `IGNORE_INDEX(t, idx)` | Prevent use of a specific index | A specific index produces a bad plan |
| `USE_INDEX_MERGE(t, idx1, idx2)` | Force index merge (combine multiple indexes) | Query filters on columns from different indexes |
| `ORDER_INDEX(t, idx)` | Force ordered scan on index | Need sorted results and the index provides the order |
| `NO_ORDER_INDEX(t, idx)` | Prevent ordered scan on index | Optimizer incorrectly prefers an ordered scan |

### Read strategy hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `READ_FROM_STORAGE(TIKV[t])` | Force reading from TiKV (row store) | OLTP point lookups; avoid accidental TiFlash reads |
| `READ_FROM_STORAGE(TIFLASH[t])` | Force reading from TiFlash (columnar) | Analytical scans on large tables with TiFlash replicas |
| `USE_TOJA(TRUE)` | Enable outer join to anti/semi-join transformation | Specific outer join patterns that can be simplified |
| `USE_TOJA(FALSE)` | Disable the transformation | Transformation produces a worse plan |

### Aggregation hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `HASH_AGG()` | Force hash aggregation | Large GROUP BY with many distinct values |
| `STREAM_AGG()` | Force stream aggregation | Data is already sorted on GROUP BY columns |
| `MPP_1PHASE_AGG()` | Force single-phase MPP aggregation | TiFlash; low cardinality GROUP BY |
| `MPP_2PHASE_AGG()` | Force two-phase MPP aggregation | TiFlash; high cardinality GROUP BY |

### Other hints

| Hint | Effect | When to use |
|------|--------|-------------|
| `MEMORY_QUOTA(N)` | Set per-query memory limit (e.g., `MEMORY_QUOTA(1 GB)`) | Prevent a single query from using too much memory |
| `MAX_EXECUTION_TIME(N)` | Set per-query timeout in milliseconds | Safety net for queries that might run too long |
| `RESOURCE_GROUP(name)` | Assign query to a resource group | Workload isolation |

## General guidance

- **Start without hints.** Fix stats and indexes first. Only add hints when the optimizer consistently picks a wrong plan.
- **Be specific.** Specify table names in hints to avoid ambiguity, especially in multi-join queries.
- **Document why.** Add a SQL comment explaining the reason for the hint so future maintainers don't remove it blindly.
- **Re-evaluate after upgrades.** Optimizer improvements in new TiDB versions may make existing hints unnecessary or counterproductive.

---

## 2. Optimizer Cost Factors

TiDB provides a set of `tidb_opt_*_cost_factor` variables that act as multipliers on the cost model. Each variable controls the cost of a specific physical operator. By adjusting these multipliers you can **encourage** or **discourage** the optimizer from choosing particular operators without using hard-coded hints.

These cost factors were delivered to allow the EXPLAIN EXPLORE feature of TiDB to iterate through alternative cost factors and explore other viable query plans that may not have been chosen as the winning plan initially.

## How cost factors work

- Every cost factor **defaults to 1.0** (neutral — no adjustment).
- The factor is a **multiplier** on the operator's calculated cost:
  - **Lower than 1.0** (e.g., 0.5) → makes the operator **cheaper** → **encourages** the optimizer to choose it.
  - **Higher than 1.0** (e.g., 10 or 100) → makes the operator **more expensive** → **discourages** the optimizer from choosing it.
- The optimizer still uses cost-based selection — the factor biases the cost, it doesn't force or disable the operator entirely.

## Setting cost factors

Cost factors can be set at three scopes:

### Global (all new connections)

```sql
SET GLOBAL tidb_opt_hash_join_cost_factor = 10;
```

Use for cluster-wide tuning when a workload systematically benefits from avoiding (or favoring) a particular operator.

### Session (current connection only)

```sql
SET @@session.tidb_opt_table_full_scan_cost_factor = 100;
```

Use for a specific workload or batch job within a single connection.

### Per-query via SET_VAR hint

```sql
SELECT /*+ SET_VAR(tidb_opt_hash_join_cost_factor=100) */ *
FROM orders o JOIN customers c ON o.cust_id = c.id;
```

Use for surgical, per-query tuning — the most precise approach. The variable is set only for the duration of that single statement.

## Complete cost factor catalog

### Scan operators

| Variable | Operator affected | Use case |
|----------|-------------------|----------|
| `tidb_opt_table_full_scan_cost_factor` | TableFullScan | Increase to discourage full table scans; the optimizer will prefer index scans when available |
| `tidb_opt_table_range_scan_cost_factor` | TableRangeScan | Adjust cost of range scans on the primary key / clustered index |
| `tidb_opt_table_rowid_scan_cost_factor` | TableRowIDScan | Adjust cost of scanning by row ID (typically after an index lookup) |
| `tidb_opt_index_scan_cost_factor` | IndexScan (single index range scan) | Lower to encourage index scans; increase to push toward full scans or other indexes |
| `tidb_opt_table_tiflash_scan_cost_factor` | TiFlash table scan | Lower to encourage TiFlash reads for analytical queries; increase to prefer TiKV |

### Reader operators (TiDB ↔ storage layer)

| Variable | Operator affected | Use case |
|----------|-------------------|----------|
| `tidb_opt_table_reader_cost_factor` | TableReader (reads full rows from TiKV) | Adjust the cost of reading full table data from TiKV |
| `tidb_opt_index_reader_cost_factor` | IndexReader (reads from index only, no table lookup) | Adjust the cost of covering index reads |
| `tidb_opt_index_lookup_cost_factor` | IndexLookUp (index scan + table lookup) | Increase to discourage index lookups when the table lookup is expensive; lower to encourage them |
| `tidb_opt_index_merge_cost_factor` | IndexMerge (combines multiple indexes) | Lower to encourage index merge for OR conditions; increase if index merge is causing overhead |

### Join operators

| Variable | Operator affected | Use case |
|----------|-------------------|----------|
| `tidb_opt_hash_join_cost_factor` | HashJoin | Increase to discourage hash joins (e.g., when memory is constrained); lower to encourage them |
| `tidb_opt_index_join_cost_factor` | IndexJoin (index nested loop join) | Lower to encourage index joins when the inner side has a good index; increase if index join probes are expensive |
| `tidb_opt_merge_join_cost_factor` | MergeJoin | Lower to encourage merge joins when data is pre-sorted; increase to prefer hash or index joins |

### Aggregation operators

| Variable | Operator affected | Use case |
|----------|-------------------|----------|
| `tidb_opt_hash_agg_cost_factor` | HashAgg | Increase to discourage hash aggregation; lower to encourage it |
| `tidb_opt_stream_agg_cost_factor` | StreamAgg | Lower to encourage stream aggregation when data is sorted on the GROUP BY key |

### Other operators

| Variable | Operator affected | Use case |
|----------|-------------------|----------|
| `tidb_opt_sort_cost_factor` | Sort | Increase to discourage explicit sort operators (optimizer may prefer index-ordered reads instead) |
| `tidb_opt_topn_cost_factor` | TopN (sort + limit combined) | Adjust cost of TopN operations |
| `tidb_opt_limit_cost_factor` | Limit | Adjust cost of Limit operators |

## Practical examples

### Discourage full table scans, prefer index access

```sql
-- Session-wide: make full table scans 100x more expensive
SET @@session.tidb_opt_table_full_scan_cost_factor = 100;

-- Per-query alternative:
SELECT /*+ SET_VAR(tidb_opt_table_full_scan_cost_factor=100) */ *
FROM orders WHERE status = 'pending';
```

### Discourage hash join, encourage index join

When the inner table has a good index on the join key but the optimizer keeps choosing hash join:

```sql
SELECT /*+ SET_VAR(tidb_opt_hash_join_cost_factor=100) SET_VAR(tidb_opt_index_join_cost_factor=0.5) */ *
FROM orders o JOIN customers c ON o.cust_id = c.id
WHERE o.created_at > '2024-01-01';
```

### Encourage TiFlash for analytical queries

```sql
SELECT /*+ SET_VAR(tidb_opt_table_tiflash_scan_cost_factor=0.1) */
  region, SUM(amount)
FROM orders
GROUP BY region;
```

### Discourage sort operators (prefer index-ordered reads)

```sql
SET @@session.tidb_opt_sort_cost_factor = 50;

SELECT * FROM orders ORDER BY created_at DESC LIMIT 20;
-- Optimizer will now strongly prefer an index on created_at over a full scan + sort
```

### Combine multiple factors to reshape a complex query plan

```sql
-- Discourage full scans and hash joins; encourage index lookups
SELECT /*+
  SET_VAR(tidb_opt_table_full_scan_cost_factor=100)
  SET_VAR(tidb_opt_hash_join_cost_factor=50)
  SET_VAR(tidb_opt_index_lookup_cost_factor=0.5)
*/ *
FROM orders o
JOIN items i ON i.order_id = o.id
JOIN products p ON p.id = i.product_id
WHERE o.status = 'active';
```

## Cost factors vs hints

| Approach | Precision | Effect |
|----------|-----------|--------|
| **Hints** (e.g., `HASH_JOIN(t1, t2)`) | Forces a specific operator | Hard override — optimizer has no choice |
| **Cost factors** | Biases the cost model | Soft influence — optimizer still picks the cheapest plan, but costs are weighted differently |

**When to prefer cost factors over hints:**
- You want to **nudge** the optimizer without completely overriding it.
- The query has many joins or operators, and hinting each one is impractical.
- You want a **session-wide or global** policy (e.g., "always discourage full scans") rather than per-query tuning.
- You have a pure OLTP application and want to discourage OLAP style operations (table full scans, hash joins etc).
- You're unsure which specific operator is the problem — adjusting cost factors lets the optimizer re-evaluate the whole plan.

**When to prefer hints:**
- You know exactly which operator and which tables should use a specific strategy.
- You need to force a certain query join order or index choice
- Cost factor adjustments still don't produce the desired plan.

**What if the cost factor doesn't discourage the operator?:**
- It's possible that the desired operator isn't valid for this plan - for example, discouraging hash join won't impact a query that doesn't involve a join.
- There are logical rewrites in the optimizer that may disable some plan choices. An example is for correlated subqueries, if you're not seeing a desired index join it may be because the optimizer decorrelated the subquery, and the solution is either the NO_DECORRELATE() hint or for subqueries in the select list you can use the session/global variable tidb_opt_enable_no_decorrelate_in_select. 

## Diagnostic workflow

1. Run `EXPLAIN ANALYZE` on the slow query.
2. Identify the problematic operator (e.g., an unnecessary TableFullScan or HashJoin with a huge build side).
3. Increase the cost factor for the unwanted operator and/or decrease the factor for the preferred alternative.
4. Re-run `EXPLAIN ANALYZE` and compare execution time and plan shape.
5. If the plan improves, decide the right scope (per-query SET_VAR, session, or global).

## Cautions

- **Don't set extreme values globally without testing.** A global `tidb_opt_table_full_scan_cost_factor = 1000` will affect every query in the cluster, including those where a full scan is genuinely the best plan.
- **Prefer per-query SET_VAR for targeted tuning.** It's the safest scope — no side effects on other queries.
- **Cost factors don't disable operators.** Even at very high values, the optimizer may still choose the operator if there is no alternative. Use hints to truly force a choice.
- **Re-evaluate after stats refresh.** A bad plan caused by stale stats may resolve itself after `ANALYZE TABLE`, making the cost factor adjustment unnecessary.
- **Document non-default settings.** If you set cost factors at session or global scope, document the reason so future maintainers understand the intent.

---

## 3. Optimizer Fix Controls

TiDB provides a fine-grained compatibility control mechanism for the optimizer through the `tidb_opt_fix_control` system variable. Each fix control corresponds to a specific GitHub issue and adjusts a particular optimizer behavior. This feature was introduced to solve three problems: avoiding variable proliferation, handling behavioral incompatibility across scenarios, and maintaining plan stability during upgrades.

Fix controls let you selectively enable or disable specific optimizer behavior changes — especially useful when an upgrade introduces a regression for a particular workload.

## How fix controls work

- Each fix control is identified by a **GitHub issue number** (e.g., `44262` → [github.com/pingcap/tidb/issues/44262](https://github.com/pingcap/tidb/issues/44262)).
- The value is either a **boolean** (`ON`/`OFF`) or an **integer**, depending on the fix.
- Multiple fix controls are set as a single comma-separated string.
- When a fix control is set to its default value, TiDB behaves as if it were not specified.
- Duplicate fix control numbers in the same string produce a warning; only the last value takes effect.

## Setting fix controls

Fix controls can be set at three scopes:

### Global (all new connections)

```sql
SET GLOBAL tidb_opt_fix_control = '44262:ON,44855:ON';
```

Use for cluster-wide tuning when a behavior change should apply to all sessions.

### Session (current connection only)

```sql
SET SESSION tidb_opt_fix_control = '44262:ON,52869:ON';
```

Use when testing a fix control or applying it to a specific workload.

### Per-query via SET_VAR hint

```sql
SELECT /*+ SET_VAR(tidb_opt_fix_control='52869:ON') */ *
FROM orders o JOIN customers c ON o.cust_id = c.id;
```

Use for surgical, per-query tuning — the most precise approach. The variable is set only for the duration of that single statement.

> **Note:** There was a historical bug (Issue #50507, fixed in v7.5+) where `SET_VAR(tidb_opt_fix_control=...)` was incompatible with SQL bindings. This has been resolved.

## Complete fix control catalog

### Plan cache controls

| Fix | Default | Values | Since | Purpose |
|-----|---------|--------|-------|---------|
| `33031` | `OFF` | `ON`, `OFF` | v8.0.0+ | Controls whether plan cache is allowed for partitioned tables (both prepared and non-prepared statement caching) |
| `44823` | `200` | `[0, 2147483647]` | v7.3.0+ | Sets the parameter count limit for plan cache to save memory. `0` removes the limit entirely |
| `44830` | `OFF` | `ON`, `OFF` | v6.5.7, v7.3.0+ | Controls whether plan cache caches execution plans with `PointGet` operators generated from `_tidb_rowid` |
| `45798` | `ON` | `ON`, `OFF` | v7.5.0+ | Controls whether plan cache caches plans that access generated columns |

### Partition and statistics controls

| Fix | Default | Values | Since | Purpose |
|-----|---------|--------|-------|---------|
| `44262` | `OFF` | `ON`, `OFF` | v6.5.3, v7.2.0+ | Controls whether dynamic pruning mode can access partitioned tables when GlobalStats are missing. When `ON`, the optimizer falls back to dynamic pruning even without global statistics |

### Index and scan path controls

| Fix | Default | Values | Since | Purpose |
|-----|---------|--------|-------|---------|
| `44389` | `OFF` | `ON`, `OFF` | v6.5.3, v7.2.0+ | Controls whether to build more comprehensive scan ranges for `IndexRangeScan` with complex OR filters. Can improve plans for queries with `OR`-connected conditions on indexed columns |
| `45132` | `1000` | `[0, 2147483647]` | v7.4.0+ | Sets the heuristic threshold for access path selection. When candidate access paths exceed this threshold, a heuristic strategy prunes less promising paths. `0` disables the heuristic |
| `52592` | `OFF` | `ON`, `OFF` | v8.4.0+ | Disables `Point Get` and `Batch Point Get` operators, forcing the Coprocessor path. Useful for wide tables or tables with large JSON values where Point Get causes excessive memory usage |
| `52869` | `OFF` | `ON`, `OFF` | v8.1.0+ | Removes the limitation that prevents automatic index merge when a single index scan path is available. When `ON`, the optimizer can choose index merge even when a normal index lookup path exists |
| `54337` | `OFF` | `ON`, `OFF` | v8.3.0+ | Enables general range intersection for complex conjunctive (AND) conditions. Can produce tighter scan ranges but may increase optimization time for queries with 10+ conjuncts |

### Join and row estimation controls

| Fix | Default | Values | Since | Purpose |
|-----|---------|--------|-------|---------|
| `44855` | `OFF` | `ON`, `OFF` | v6.5.4, v7.3.0+ | Improves row count estimation for `IndexJoin` scenarios with `Selection` operators on the Probe side. Fixes overestimation that could lead the optimizer to choose suboptimal join strategies |
| `47400` | `ON` | `ON`, `OFF` | v8.4.0+ | Controls the minimum `estRows` limit. When `ON`, the minimum estimated rows for any operator is 1 (Oracle/DB2 compatible behavior). When `OFF`, `estRows` can be less than 1 |

### Optimizer exploration controls

| Fix | Default | Values | Since | Purpose |
|-----|---------|--------|-------|---------|
| `46177` | `ON` (v8.5.0+), `OFF` (before) | `ON`, `OFF` | v6.5.6, v7.1.3, v7.5.0+ | Controls whether the optimizer explores enforced plans (e.g., plans that enforce a specific sort order) after finding unenforced plans. When `ON`, the optimizer may find better plans at the cost of slightly longer optimization time |

### Expression optimization controls

| Fix | Default | Values | Since | Purpose |
|-----|---------|--------|-------|---------|
| `56318` | `ON` | `ON`, `OFF` | TiDB Cloud Starter only | Controls whether to avoid double calculation of heavy expressions in `ORDER BY` statements. When `ON`, the optimizer rewrites the plan to prevent redundant expression evaluation |

## Practical examples

### Enable improved IndexJoin estimation and index merge

```sql
-- Session-wide: enable better IndexJoin estimation and allow automatic index merge
SET SESSION tidb_opt_fix_control = '44855:ON,52869:ON';
```

### Enable comprehensive OR filter scan ranges

When a query has complex OR conditions on indexed columns and the optimizer isn't building optimal scan ranges:

```sql
SELECT /*+ SET_VAR(tidb_opt_fix_control='44389:ON') */ *
FROM orders
WHERE (status = 'pending' AND region = 'US')
   OR (status = 'active' AND region = 'EU');
```

### Disable Point Get for wide tables

When Point Get causes excessive memory usage on tables with large JSON or BLOB columns:

```sql
SET SESSION tidb_opt_fix_control = '52592:ON';

SELECT * FROM wide_table WHERE id = 12345;
-- Forces Coprocessor path instead of Point Get
```

### Preserve plan stability during upgrade

When upgrading to a new TiDB version and a specific optimizer change causes regression:

```sql
-- Disable the enforced plan exploration that was turned ON by default in v8.5.0
SET GLOBAL tidb_opt_fix_control = '46177:OFF';
```

### Combine multiple fix controls

```sql
-- Enable improved estimation, index merge, and comprehensive scan ranges
SET SESSION tidb_opt_fix_control = '44855:ON,52869:ON,44389:ON,54337:ON';

EXPLAIN ANALYZE
SELECT *
FROM orders o
JOIN items i ON i.order_id = o.id
WHERE (o.status = 'active' OR o.status = 'pending')
  AND o.created_at > '2024-01-01';
```

## Fix controls vs other tuning mechanisms

| Mechanism | Scope | Effect |
|-----------|-------|--------|
| **Optimizer hints** (e.g., `HASH_JOIN`) | Per-query, per-operator | Forces a specific operator or strategy |
| **Cost factors** (`tidb_opt_*_cost_factor`) | Per-query / session / global | Biases the cost model — soft influence |
| **Fix controls** (`tidb_opt_fix_control`) | Per-query / session / global | Toggles specific optimizer behavior changes on/off |
| **Session variables** (e.g., `tidb_opt_prefer_range_scan`) | Session / global | Enables/disables broad optimizer strategies |

**When to use fix controls:**
- An optimizer behavior change introduced in a new version causes a regression in your workload.
- You want to selectively adopt specific optimizer improvements without taking all changes from an upgrade.
- You need to fine-tune estimation or plan exploration behavior beyond what cost factors and hints provide.
- You want to maintain plan stability during upgrades by disabling specific behavior changes.

**When to prefer other mechanisms:**
- Use **hints** when you know exactly which operator to force for a specific query.
- Use **cost factors** when you want to generally bias the optimizer toward or away from certain operators.
- Use **session variables** for broad behavioral switches (e.g., `tidb_opt_prefer_range_scan`).

## Diagnostic workflow

1. Identify the regression: compare `EXPLAIN ANALYZE` output before and after the change (upgrade, config change, etc.).
2. Check the TiDB release notes for optimizer behavior changes introduced in the new version.
3. Match the behavior change to a fix control number from the catalog above.
4. Set the fix control to the previous default at session scope and re-run `EXPLAIN ANALYZE`.
5. If the plan improves, decide the right scope (per-query SET_VAR, session, or global).
6. Document which fix controls are set and why, so they can be re-evaluated in future upgrades.

## Cautions

- **Always test fix controls in a non-production environment first.** Changing optimizer behavior can have unexpected effects on other queries.
- **Prefer per-query SET_VAR for targeted tuning.** It's the safest scope — no side effects on other queries.
- **Fix controls are version-specific.** A fix control number that doesn't exist in your TiDB version will be silently ignored. Always verify the "Since" version.
- **Re-evaluate after upgrades.** Fix controls you set to work around a regression may no longer be necessary (or may conflict with new improvements) in a later version.
- **Document non-default settings.** If you set fix controls at session or global scope, document the reason and the GitHub issue number so future maintainers can understand the intent and re-evaluate.
- **Fix controls don't compose with cost factors.** They control different aspects of the optimizer — fix controls toggle behavior changes, while cost factors adjust the cost model. Both can be used simultaneously.
